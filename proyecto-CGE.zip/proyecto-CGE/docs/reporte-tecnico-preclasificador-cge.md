# Reporte técnico: aprendizajes del modelo pre clasificador de expedientes de CGE

**Fecha:** 18 de noviembre de 2026 (agrega las revisiones de El Salvador, Panamá, República Dominicana y Costa Rica)
**Versión de la herramienta:** pre alfa
**Alcance:** reunión de levantamiento con CGE, revisiones grabadas de casos de Guatemala, Honduras, El Salvador, Panamá, República Dominicana y Costa Rica, checklists por país, archivo JSON del FEIC y construcción de la herramienta pre alfa.
**Nota de privacidad:** este reporte no contiene nombres de clientes ni de personas, documentos de identidad, NIT, números de expediente ni montos de casos reales. Los ejemplos numéricos son ficticios. Los montos de política (IVA, cargos fijos, traspasos) sí se incluyen porque no identifican a nadie.

---

## 1. Resumen

1. La revisión de CGE depende de reglas que no están todas escritas: la analista usa un checklist propio modificado y aplica criterios de práctica que en algunos puntos contradicen el checklist oficial.
2. El mayor costo del proceso es el reproceso: casos de otros países llegan a dar entre 4 y 8 vueltas con Comercial, porque cada corrección rompe otra cosa.
3. Las mismas fórmulas de cálculo cuadran en Guatemala y en Honduras; lo único que cambia por país son los montos fijos y el IVA.
4. Se detectaron dos alarmas falsas generadas por cálculos manuales de la analista; con las fórmulas escritas, la herramienta las habría evitado.
5. La lectura con IA comete errores que se propagan: un dato ancla mal leído produce varias correcciones falsas en cadena. La herramienta debe tratar el dato ancla con desconfianza cuando todos los demás documentos coinciden entre sí y no con él.
6. La herramienta debe respetar los nombres de los documentos tal como vienen y la clasificación hecha por la persona; la IA solo sugiere.
7. El Salvador confirma la fórmula común con un tercer país, pero agrega un componente propio: el impuesto a la primera matrícula (IPM), que se resta del total del bien antes de calcular y va en un flujo aparte.
8. República Dominicana confirma la fórmula común con ITBIS de 18 % y muestra dos variantes que la herramienta aún no modela: gastos iniciales financiados en un flujo aparte y seguro que no se financia.
9. Costa Rica cotiza el bien sin impuesto (monto exacto) y solo aplica el 13 % a seguro, GPS y cargo del dispositivo; sus gastos iniciales siempre son financiados.
10. Panamá rompe una parte de la fórmula común: trabaja sobre el total del bien con impuesto incluido y calcula la opción de compra sobre ese total. Además apareció un "bono cliente" con gastos iniciales financiados que ni la revisora pudo cuadrar.

---

## 2. Fuentes analizadas

| Fuente | Qué aportó |
|---|---|
| Reunión de levantamiento con CGE | Flujo de trabajo, tablero de tickets en Hive, orden de escaneo, manual de criterios, volumen y principales problemas |
| Revisión grabada de un caso de Guatemala (persona jurídica nueva, Leasing Financiero Usado) | Orden de revisión, cruces, criterios de la analista, fórmulas de la cotización y del flujo |
| Revisión grabada de un caso de Honduras (persona jurídica nueva, tres negocios) | Diferencias por país, ciclo de correcciones, reporte diario de revisión de CGE, fórmulas con impuesto de 15 % |
| Checklists por país (Guatemala, El Salvador, Honduras, Costa Rica, Panamá, Nicaragua, regional y República Dominicana) | Requisitos por producto, documentos por país, tabla de equivalencias |
| Revisión grabada de un caso de El Salvador (persona jurídica nueva, sociedad anónima de capital variable, Leasing Financiero en dólares), en seis partes; la primera sin transcripción original, transcrita automáticamente | Orden y requisitos de El Salvador, tiempos por documento, IPM y placas, montos fijos en dólares, cierre del ticket y revisión del reingreso |
| Revisión grabada de un caso de Panamá (persona jurídica de una sola accionista, Leasing Financiero en dólares), en dos partes; la revisora ya trabaja en otra área | Requisitos y equivalencias de Panamá, formatos del Conoce a tu cliente por país, formulario de debida diligencia, cálculos con ITBMS, dudas sin resolver sobre el bono cliente |
| Revisión grabada de un caso de República Dominicana (sociedad de responsabilidad limitada, Leasing Financiero en dólares de un equipo de cocina compuesto por seis artículos), en cinco partes | Requisitos y criterios de República Dominicana acordados con Legal, burós y cédulas, bien compuesto con anexo, propuesta en lugar de cotización, flujo con gastos financiados |
| Revisión grabada de un caso de Costa Rica (sociedad anónima, Leasing Financiero en dólares de un vehículo). Se entregaron los videos 1 y 3; el 3 está dañado y no abre, y el 2 no se entregó. La transcripción cubre la sesión completa (1 hora 35 minutos) salvo dos pausas de unos 5 y 3 minutos | Requisitos de Costa Rica, Credid y SUGEF, cálculos sin impuesto en el bien, gastos de inscripción, vendors agrupados |
| Archivo JSON del FEIC de persona jurídica | Estructura de datos exacta del FEIC, incluidas las marcas de PEP y CPE |

---

## 3. Proceso observado en CGE

### 3.1 Flujo del ticket

1. Comercial sube los documentos a SharePoint, por país y muchas veces con nombres libres y sin orden.
2. La analista descarga, arma la carpeta del cliente (cliente, año, mes, MADRE y negocios), renombra cada archivo con el número del orden de escaneo y une archivos que van juntos (por ejemplo, los informes de buró).
3. Revisa el expediente madre del 1 al 13; los documentos fuente (patentes, escritura, nombramiento, documento de identidad, registro tributario, recibo) validan al FEIC.
4. Una vez validados el FEIC y el Conoce a tu cliente, los usa como referencia para revisar el negocio.
5. Revisa el negocio y deja los cálculos al final.
6. Registra cada error como subtarea del ticket en Hive y devuelve a Comercial, o pasa el ticket a Recepción FIMS (cotizadores manuales) o Recepción FLOW (cotización web).

### 3.2 Volumen y tiempos declarados

- Una analista atendió 108 negocios en un mes.
- Persona jurídica con un negocio: alrededor de 2 horas y 30 minutos en Guatemala; entre 1.5 y 2 horas en Honduras.
- Cada negocio adicional: entre 20 y 25 minutos.
- Creación de cliente nuevo en el sistema: alrededor de 20 minutos.
- Tres de las seis analistas estaban en inducción durante el levantamiento.
- El Salvador: preparar la carpeta (asignación, descarga y orden) toma unos 10 minutos; el caso completo, entre 1.5 y 2 horas. Por documento del expediente madre: información financiera ~10 minutos, declaraciones ~3, Conoce a tu cliente ~8, estados de cuenta entre 5 y 8.
- República Dominicana: una revisora con experiencia revisa un caso pequeño completo en alrededor de 1 hora; una persona nueva, entre 1.5 y 2 horas. Los casos grandes se alargan por la búsqueda de socios entre muchos documentos, y la revisora lo dijo así: "se necesita la parametrización de dónde sacar cada dato".
- Respuesta de Comercial a una devolución: en promedio al día siguiente; en el peor caso, una semana; si el cliente no entrega un documento, semanas. Comercial devuelve todo junto cuando tiene todo, así que un documento lento retrasa el caso completo.

### 3.3 Reprocesos identificados

| Reproceso | Causa | Estrategia en la herramienta |
|---|---|---|
| Ordenar, renombrar y unir archivos | Comercial sube sin orden | Clasificación por nombre, número de orden y lectura con IA |
| Varias vueltas por documentos faltantes | Expedientes incompletos (en Honduras llegan 5 de 10 documentos) | Inventario contra el checklist al cargar; todo lo faltante sale en la primera devolución |
| Correcciones que rompen otras cosas | Comercial corrige lo pedido y cambia otros datos; en El Salvador la analista compara a mano cada reingreso contra la versión anterior | Pendiente: comparar cada reingreso contra la versión anterior (corregido, pendiente, nuevo) |
| Alarmas falsas de cálculo | Fórmulas no documentadas, cálculo manual | Fórmulas escritas y verificadas; montos por país |
| Lectura de escrituras extensas | Escrituras de hasta 90 páginas con accionistas dispersos | Historia accionaria con lectura por lotes de todas las páginas |

---

## 4. Documentos y relaciones

### 4.1 Documento que manda en cada dato

| Dato | Documento ancla en Guatemala | Se compara contra |
|---|---|---|
| Razón social (idéntica, incluida la puntuación de abreviaturas) | Patente de sociedad | FEIC, Conoce a tu cliente, solicitud, cotización, estados financieros, declaraciones |
| Representante legal, número de identidad, estado civil | DPI | FEIC, Conoce a tu cliente, nombramiento, solicitud, checklist de seguro |
| NIT de empresa y representante, contador | RTU | FEIC, solicitud, declaraciones, estados financieros |
| Dirección | Recibo | FEIC, Conoce a tu cliente, solicitud |
| Vencimiento del nombramiento | Nombramiento | FEIC, Conoce a tu cliente, solicitud |
| Escritura (número, fecha, notario) y registro | Escritura y patente de sociedad | FEIC |
| Accionistas | Última escritura | FEIC (solo 10 % o más), Conoce a tu cliente, solicitud |
| Bien (marca, línea, año) | Tarjeta de circulación en usado; cotización vendor en nuevo | Conoce a tu cliente, cotización, flujo, avalúo |
| Porcentajes, plazo, TIR, asesor | Hoja de negociación | Conoce a tu cliente, cotización, flujo |
| Precio, vendor, ejecutivo | Cotización vendor | FEIC, Conoce a tu cliente, solicitud, cotización |
| Número de cotización | Cotización Arrend | Flujo (vienen del mismo sistema) |

### 4.2 Diferencias por país

| Tema | Guatemala | Honduras |
|---|---|---|
| FEIC | Sí, con archivo JSON | No existe |
| Carta de buró | Sí | No; solo informes |
| Patentes | De comercio y de sociedad | Permiso de operaciones |
| Nombramiento | Documento aparte | Dentro de la escritura, con cuadros de inscripción y matrícula |
| Registro tributario | RTU | RTN (el del representante es su identidad más un dígito) |
| Declaraciones | 3 meses de IVA e ISR trimestral | Una anual |
| Impuesto | 12 % | 15 % |
| Seguro | Normalmente con Arrend | El seguro endosado es común: sin checklist de seguro ni cuota |
| Cruce de dirección | Contra el recibo | Contra el recibo en la práctica; el checklist indica el permiso de operaciones |

El Salvador, según la revisión grabada:

| Tema | El Salvador |
|---|---|
| Orden del expediente madre (persona jurídica) | 1 información financiera; 1.2 declaraciones; 2 y 4 no aplican; 3 Formulario Conoce a tu cliente; 5 estados de cuenta; 6 carta de buró e Infored - Equifax; 7 DUI; 8 matrícula; 9 escritura; 9.1 carta accionaria y 9.2 anexo de beneficiarios (si aplican); 10 credencial; 11 NIT; 12 recibo |
| FEIC | No existe |
| Matrícula | Equivale a las patentes; se renueva cada año y debe ser la del año vigente |
| Credencial | Equivale al nombramiento: cargo, personas y plazo contado desde la inscripción (por ejemplo, 5 años) |
| NIT | Las sociedades lo presentan; en personas individuales ya viene homologado en el DUI |
| Declaraciones | Mensuales, 3 periodos; plazo de un mes y 15 días para el mes anterior |
| Buró | Carta de autorización con firma del representante; Infored y Equifax de empresa, representante y socios con más de 10 % |
| Dirección | Contra el recibo, en todos los documentos (oficina, planta, ubicación del bien y dirección fiscal) |
| Escritura | Hojas sin numerar: se verifica la continuidad del texto entre hojas; testimonio y registro de comercio adjuntos; modificaciones en orden cronológico |
| Socios | La carta accionaria es la fuente preferida; si no hay, se buscan en el capital social de la escritura |
| Formato | Todo en mayúsculas; mezcla de mayúsculas y minúsculas se manda a corregir |
| Moneda e impuesto | Dólares; IVA de 13 % |
| Negocio | 1 hoja; 2 solicitud; 3 checklist de seguro; 3.1 licencia; 4 mejora de seguro; 5 cotización Arrend; 6 flujo; 7 cotización vendor; capacidad de pago, ponderación y saldos promedio son opcionales: si no vienen, no se piden |

Panamá, según la revisión grabada:

| Tema | Panamá |
|---|---|
| Expediente madre (persona jurídica) | Información financiera, declaraciones, Conoce a tu cliente, estados de cuenta, carta de buró y APC, cédula, aviso de operaciones, pacto social, carta accionaria y anexo 5 (si aplican), certificación de personería jurídica o poder general (equivale al nombramiento), RUC |
| Información financiera | Dos años cerrados más el interino; si la empresa es más reciente, no se piden años en que no existía; un interino auditado no existe, así que se acepta con estado de cuenta y balance general |
| Declaraciones | Anuales; uno o dos años cerrados; se valida RUC, dígito verificador y razón social |
| Aviso de operaciones | Lo emite el Ministerio de Comercio e Industrias; trae dos números distintos: el RUC (corto) y el número de aviso de operaciones (largo). RUC más dígito verificador equivalen al NIT. Sustituye al recibo para la dirección |
| Pacto social | Equivale a la escritura y debe ser el de constitución; las enmiendas son las modificaciones. La fecha de constitución de todos los formularios sale del pacto social (lo parametrizó la gerencia de Panamá por correo) |
| Representación | Del documento más reciente (actas de junta); si no indica plazo, es indefinida |
| Cédula | Solo el frente |
| Accionistas | Entre 70 % y 85 % de las sociedades tienen un solo dueño |
| Buró | Carta de buró (regional, excepto Honduras, por tema legal) y APC de empresa, representante y accionistas; si el representante no es accionista, no se le pide APC |
| Negocio | Igual que los demás países más el formulario de debida diligencia (uno por negocio; también del aval si es de Panamá) |
| Cotizador | Web: cotización y flujo. Manual (Excel): exige además la "propuesta Arrend", igual que en Costa Rica |
| Moneda e impuesto | Balboas o dólares, a la par (sin tipo de cambio); ITBMS de 7 % |

República Dominicana, según la revisión grabada (país más nuevo de la cartera; los criterios se acordaron con Legal y abogados del país):

| Tema | República Dominicana |
|---|---|
| Expediente madre | Información financiera, declaraciones (DGII), Conoce a tu cliente, estados de cuenta, carta de buró y TransUnion (sociedad, representante y socios), cédula o pasaporte, registro mercantil, estatutos sociales, carta accionaria y anexo de beneficiarios (si aplican), asamblea extraordinaria (si aplica), RNC |
| Registro mercantil | Documento central: denominación social, RNC, fecha de asamblea constitutiva, órganos de gestión (representante), socios y dirección. Debe estar vigente, completo y emitido por la Cámara de Comercio; excepcionalmente lo emite un abogado según la zona de operación, con respaldo de Legal |
| Representación | No hay nombramiento aparte; aunque el registro diga un plazo, se toma como indefinida (dura lo que la sociedad). Solo puede ingresar como representante quien está autorizado para firmar en el registro mercantil |
| Estatutos sociales | No se exige el de constitución; los datos salen del registro mercantil. Igual se leen completos, porque pueden decir que el representante ya no lo es |
| Asamblea general y contratos de compraventa de cuotas | Equivalen a modificaciones: registran socios, poderes, representante y traspasos; llevan firmas de todos los involucrados y el sello o la estampilla del registro mercantil. Se leen para reconstruir cómo estaba y cómo quedó la composición |
| RNC | Equivale al NIT y ya viene en el registro mercantil; el del representante es su número de cédula (homologado) |
| Información financiera | Casi siempre auditada: el comentario del auditor y su sello o firma en la primera página la identifican. Interino sin mes fijo, pero al menos hasta junio, porque la ley exige que pase cierto tiempo; la fecha del encabezado debe ser la misma en todos los estados del periodo |
| Declaraciones | Riesgos autorizó no exigirlas en ciertos casos con interinos avanzados |
| Conoce a tu cliente | Siempre ingresa sin visita: la visita se hace después de aprobado, con visto bueno o memo de Riesgos que deja pendientes las fotos |
| Estados de cuenta | Los bancos cortan a mitad de mes (del 15 al 15 o del 20 al 20); se acepta si cubre el periodo completo, contado desde el mes de ingreso del expediente |
| Buró | Solo TransUnion (sin Infornet): solo moras, no demandas. Vigencia del mes anterior o del mes en curso. Se cuentan entidades financieras; telecomunicaciones no; almacenes según el caso. Con un 4 o 5 en el comportamiento histórico se pide finiquito o boleta de pago al día |
| Cédula | Completa, legible y vigente; excepción: las cédulas emitidas en 2023 y 2024 con problema de renovación del registro civil se aceptan vencidas, por comunicado oficial |
| Recibo | 2 meses o menos; si no trae dirección (por ejemplo, de internet), no se devuelve y la dirección sale del registro mercantil |
| Negocio | Solo Leasing Financiero y Leasing Operativo, siempre en dólares. En lugar de la cotización Arrend se usa una propuesta, firmada por el representante, que dice el tipo de financiamiento, el plazo, la forma de pago (30 días después de entregar el bien), lo que incluye la renta y la opción de compra |
| Moneda e impuesto | Dólares; ITBIS de 18 % |

Costa Rica, según la revisión grabada:

| Tema | Costa Rica |
|---|---|
| Orden del expediente madre (persona jurídica) | 1 información financiera; 1.2 declaraciones; 3 Conoce a tu cliente (informe de visita); 5 estados de cuenta; 6 carta de buró y Credid; 7 cédula; 8 patente, permiso de salud o permiso sanitario; 9 personería jurídica; 10 autorización SUGEF |
| Información financiera | Dos cerrados más el parcial (hasta medio año o septiembre); se aceptan firmas digitales; el balance de comprobación funciona como integraciones y es obligatorio en el último periodo |
| Declaraciones | Impuesto sobre las utilidades, anual; basta el último periodo completo |
| Dirección | No hay recibo; se usa la dirección descriptiva que pone el cliente en el informe de visita, y debe repetirse igual en todos los documentos. El domicilio de la personería jurídica no se usa |
| Personería jurídica | Equivale al RTU y a la escritura: cédula jurídica, razón social, estado inscrito, tomo y asiento, plazo de la entidad, capital y administración (gerente nombrado por todo el plazo) |
| Socios | Salen de una declaración jurada (participantes y capital social) |
| Buró | Autorización y Credid de empresa, representante y socios: juicios civiles y moras; telecomunicaciones y servicios se ignoran |
| SUGEF | Autorización que el cliente siempre firma; debe marcar el tipo de persona correcto (jurídica para la sociedad) |
| Negocio | Hoja de negociación, solicitud de crédito, datos generales, checklist de seguro, mejora de seguro (si aplica), cotización Arrend, propuesta Arrend (ya no obligatoria, pero si viene con errores se devuelve), flujo y proforma. Cliente nuevo: siempre datos generales y solicitud firmados |
| Hoja de negociación | El deudor mancomunado nunca va vacío: "No aplica" si no hay aval; gastos iniciales siempre financiados, con porcentaje y monto |
| Proforma | Se trabaja siempre en dólares; si viene en colones con tipo de cambio, se toma el total en dólares. La prima no se suma al total a financiar (si la suman, se devuelve). Sin placas, el bien es nuevo. Importa si es 4x2 o 4x4 y el combustible, porque definen el correlativo y el tipo en el checklist de seguro (4x2 camioneta sport; 4x4 camioneta agrícola) |
| Moneda e impuesto | Dólares. El bien se cotiza sin impuesto (monto exacto) porque el IVA varía; el 13 % se aplica a seguro, GPS y cargo del dispositivo |
| Volumen | Entran más personas individuales que empresas; las sociedades anónimas adjuntan muchos respaldos |

Clientes ALD y AMS (corporativos, flotillas, multinacionales, leasing operativo): tienen un checklist regional propio sin información financiera, estados de cuenta, declaraciones ni beneficiarios finales; si cotizan en bolsa, tampoco FEIC.

Formatos del Conoce a tu cliente: El Salvador, Honduras y Panamá comparten un formato; Guatemala usa uno propio (el de los otros países es el formato antiguo de Guatemala y allí ya no se recibe); República Dominicana usa uno parecido a la solicitud de crédito.

Otros países, según los checklists: Costa Rica usa Credid o el reporte de la superintendencia, y geolocalización en lugar de recibo; Panamá: APC con calificación máxima 3.

### 4.3 Documentos que no forman parte del checklist

- Todo archivo cuyo nombre dice "Respaldo" es un documento adicional: se puede ver y buscar, pero no cuenta para el checklist ni genera hallazgos automáticos.
- Un mismo documento puede llegar en varias partes (estados financieros por año, informes de buró por separado, estados de cuenta por mes); son partes, no versiones.
- Si llega una versión firmada y otra sin firmar, se usa la firmada o la más reciente y se listan las diferencias.

---

## 5. Reglas y criterios

### 5.1 Criterios de la analista que se volvieron reglas

| Regla | Nivel |
|---|---|
| Mora de 61 días o más en TransUnion sin finiquito o constancia de pago | Crítico |
| Demanda ejecutiva o sumaria en Infornet sin desistimiento | Crítico |
| APC de Panamá con calificación mayor a 3 | Crítico |
| Documento de identidad vencido el día del ingreso, aunque sea por un día | Crítico |
| Conoce a tu cliente sin firma del supervisor | Crítico |
| Informes de buró solo de socios con 10 % o más | Regular |
| FEIC con vigencia de un año y con su archivo JSON | Regular |
| En el estado civil manda el documento de identidad | Regular |
| Abreviaturas societarias sin puntos ("SA" en lugar de "S.A.") | Regular |
| Monto solicitado distinto al precio, aunque sea por un centavo | Regular |
| Firma del representante comparada contra el documento de identidad | Revisión humana, nunca automática |

### 5.2 Conflictos entre checklist y práctica

1. Conoce a tu cliente: el checklist exige firma del asesor y del supervisor; en la práctica se acepta solo con la del supervisor. Decisión: se aplica el checklist y la práctica queda como criterio flexible desactivado.
2. Honduras: el checklist cruza la dirección contra el permiso de operaciones; la práctica la cruza contra el recibo.
3. Cliente de cartera: Riesgos lo define como cliente con un año o más desde su primer negocio, aunque no haya tenido otros (confirmado en Honduras y Panamá). En Guatemala, el checklist exime de declaraciones solo a clientes de cartera con más de 2 años: son dos umbrales distintos y deben confirmarse.
4. Reingresos: el manual indica que solo regresa el documento corregido; en la práctica vuelve el caso completo.
5. El checklist de usados de Guatemala menciona, para el visto bueno, a una persona que ya no ocupa el puesto.

### 5.3 Decisiones de gobierno de reglas

- La revisión se apega al checklist oficial.
- Los criterios flexibles del analista se registran aparte y solo se activan con aprobación de los jefes de CGE.
- Agregar cruces nuevos no requiere aprobación: es parte del trabajo diario.
- Una excepción aprobada no se convierte en regla; las reglas cambian solo cuando cambia el checklist o el manual de criterios.

---

## 6. Cálculos

### 6.1 Fórmulas comunes a todos los países

| Concepto | Fórmula |
|---|---|
| Renta inicial con IVA | valor del bien sin IVA × % renta inicial × (1 + IVA) |
| Gastos iniciales con IVA | valor del bien sin IVA × % gastos + cargo de dispositivo y GPS × (1 + IVA) + bono vendor |
| Pago inicial | renta inicial + gastos iniciales + traspaso inicial (solo usado en Guatemala) |
| Opción de compra con traspaso | valor del bien sin IVA × % opción de compra + gasto de traspaso |
| Cuota mensual | (renta + seguro + GPS) × (1 + IVA) |
| Renta inicial del flujo | renta inicial con IVA ÷ (1 + IVA) |
| Desembolso del flujo | valor del bien sin IVA − renta inicial sin IVA |

Las fórmulas se verificaron contra una cotización real de Guatemala (vehículo usado) y una de Honduras (vehículo nuevo). Todos los montos cuadraron; la única diferencia fue de un centavo por redondeo, por lo que se usa una tolerancia de 0.02.

Ejemplo ficticio con IVA de 12 %, valor del bien sin IVA de 100,000.00 y renta inicial de 10 %: la renta inicial con IVA es 100,000.00 × 0.10 × 1.12 = 11,200.00.

### 6.2 Montos por país

| País | IVA | Cargo de dispositivo y GPS sin IVA | Cuota mensual de GPS | Traspaso con la opción de compra |
|---|---|---|---|---|
| Guatemala | 12 % | 1,386.00 | 139.00 | 1,835.00 (en la tabla regional figura en la columna de motos) |
| Honduras | 15 % | 4,950.00 | 486.00 | 2,875.00 |
| El Salvador | 13 % | 180 dólares (dispositivo 145 + instalación 35) | 18 dólares | 113 dólares |
| Costa Rica | 13 % | Por confirmar | Por confirmar | Sin costo fijo |
| Panamá | 7 % | Por confirmar | 18 dólares (19.26 con ITBMS) | 171.20 dólares con ITBMS |
| República Dominicana | 18 % | No aplicó en el caso (bien sin GPS) | Por confirmar | No se mencionó |
| Costa Rica | 13 % solo sobre seguro, GPS y cargo | 180 dólares | 18 dólares (20.34 con impuesto) | No se mencionó |

La fuente de los montos es el "Reporte diario de revisión CGE" que usa la analista, más lo explicado en las revisiones grabadas. Todos están pendientes de confirmación formal. En la tabla de IVA por país de ese reporte, las monedas de Costa Rica y Panamá aparecen intercambiadas.

### 6.3 El Salvador: impuesto a la primera matrícula (IPM) y placas

1. Cada vendor maneja distinto el IPM y las placas: algunos los desglosan juntos en un rubro, otros desglosan solo el IPM y dejan las placas dentro del valor del bien. Una instrucción de 2025 listaba qué vendor hacía qué, pero varios cambiaron; hoy se confirma con el asesor y suele indicarse en las notas de la hoja de negociación.
2. Valor a financiar con IVA = total del bien con IVA de la cotización vendor − IPM. Valor del bien sin IVA = valor a financiar con IVA ÷ 1.13. A partir de ahí aplican las fórmulas comunes.
3. El flujo se valida en tres partes: el bien (costo sin IVA, TIR, renta inicial sin IVA y opción de compra sin traspaso), el IPM (solo el monto; no lleva rendimiento, renta inicial ni opción de compra) y el consolidado, que es la suma de ambos.
4. En la cotización, el "valor del bien sin IVA" incluye el IPM. Por eso el total del bien dividido entre ese valor no da 1.13; la herramienta debe restar el IPM antes de verificar el IVA del bien.

Ejemplo ficticio: total del bien con IVA 22,600.00 e IPM 600.00. Valor a financiar con IVA: 22,000.00. Valor sin IVA: 22,000.00 ÷ 1.13 = 19,469.03. Con renta inicial de 20 %: 19,469.03 × 0.20 × 1.13 = 4,400.00.

Todas las cifras de la cotización y del flujo del caso de El Salvador cuadraron con las fórmulas comunes y los montos de este reporte.

### 6.4 Panamá: total con impuesto incluido

1. Panamá trabaja sobre el total del bien de la proforma, con ITBMS incluido, sin desglosarlo. Por eso la renta inicial es total × %, sin agregar impuesto. Es coherente con la fórmula común si el valor sin impuesto se toma como total ÷ 1.07.
2. La opción de compra se calcula sobre el total con impuesto (total × % + traspaso de 171.20, que ya trae ITBMS). En Honduras y El Salvador se calcula sobre el valor sin impuesto. La herramienta necesita una base de opción de compra por país.
3. Seguro y GPS ya vienen con ITBMS en la cotización (el GPS de 18 dólares aparece como 19.26). La cuota mensual es renta + seguro + GPS, sin volver a agregar impuesto.
4. En el flujo, la renta inicial va sin impuesto (÷ 1.07) y el traspaso también; la opción de compra no se divide.
5. El caso traía un "bono cliente" y gastos iniciales financiados que se suman a las rentas. La revisora no pudo cuadrar los gastos iniciales y explicó que el bono parece una estrategia comercial temporal; quedó como consulta para el encargado de revisión.

Ejemplo ficticio: total 20,000.00, renta inicial 5 % y opción de compra 5 %. Renta inicial: 1,000.00. Opción de compra: 1,000.00 + 171.20 = 1,171.20. Renta inicial en el flujo: 1,000.00 ÷ 1.07 = 934.58.

### 6.5 República Dominicana: gastos financiados, seguro aparte y bien compuesto

1. Renta inicial con ITBIS = precio con ITBIS × %, que es lo mismo que la fórmula común. Desembolso = precio con ITBIS − renta inicial.
2. Opción de compra = precio sin ITBIS × %, como en Honduras y El Salvador.
3. Gastos iniciales financiados: precio sin ITBIS × % va en un flujo aparte de "gastos administrativos" que no lleva renta inicial, ni opción de compra, ni se le quita impuesto; su cuota se suma a la del bien en el flujo consolidado. El pago inicial queda solo con la renta inicial.
4. El seguro no se financia: su cuota sale del correo de Seguros cuando es mejorado y se suma aparte a la renta del bien. En el caso, la renta total tenía una diferencia de alrededor de 1.00 frente a la suma, que la revisora atribuyó a otro cobro sin poder precisarlo.
5. Valor residual = (opción de compra + seguro) × 1.18 cuando no hay GPS.
6. Si la TIR de la hoja de negociación no coincide con la del flujo, se corrige la hoja: el flujo lo genera el sistema.
7. Bien compuesto: cuando se financian varios artículos, la hoja dice "ver anexo". El anexo detalla marca, modelo, unidades, precio unitario y total de cada artículo, se cruza contra la cotización vendor de cada uno, la suma debe dar el monto a financiar y el cliente debe firmarlo.

Ejemplo ficticio: precio con ITBIS 11,800.00, renta inicial 30 %, gastos iniciales financiados 2 %, opción de compra 5 %. Precio sin ITBIS: 10,000.00. Renta inicial con ITBIS: 3,540.00. Gastos financiados: 200.00. Opción de compra: 500.00.

### 6.6 Costa Rica: bien sin impuesto y gastos de inscripción

1. El valor del bien es el total de la proforma, que incluye los gastos de inscripción (en el caso, un monto fijo sumado al bien). No se le agrega ni quita impuesto.
2. Renta inicial = valor del bien × %. Opción de compra = valor del bien × %, sin traspaso.
3. Gastos iniciales, siempre financiados = valor del bien × % + 180 × 1.13 (dispositivo e instalación de GPS). Van en un flujo aparte, sin renta inicial, y su cuota se suma a la del bien.
4. Seguro (de la mejora de seguro) y GPS van sin impuesto en el flujo y con 13 % en la cotización. Cuota mensual = renta consolidada + seguro × 1.13 + 18 × 1.13.

Ejemplo ficticio: valor del bien 20,000.00, renta inicial 20 %, gastos 1.5 %, opción de compra 15 %. Renta inicial: 4,000.00. Gastos iniciales: 300.00 + 203.40 = 503.40. Opción de compra: 3,000.00.

### 6.7 Alarmas falsas humanas

1. Guatemala: la analista no logró cuadrar el desembolso del Conoce a tu cliente. La diferencia se explica porque, en un usado de 2024 o anterior, la renta inicial lleva IVA agregado. Con la fórmula escrita, el desembolso cuadra al centavo.
2. Honduras: la analista reportó una diferencia de centavos en la opción de compra; su suma partió de un monto mal digitado en la calculadora. La fórmula da exactamente lo que dice el documento.

Aprendizaje: cuando un monto no cuadra, se recalcula con la fórmula escrita antes de devolver el caso.

### 6.8 Señales de dato mal leído

- Si el IVA que resulta del total y el valor del bien no es 0 ni el IVA del país, se revisan esos dos montos o el país del perfil.
- Si todas las diferencias de cálculo guardan la misma proporción (por ejemplo, 1.13 ÷ 1.12), el país del perfil está mal.
- En El Salvador, un IVA del bien mayor a 13 % suele indicar que el IPM está incluido en el valor del bien.

---

## 7. Aprendizajes de lectura con IA

Formulados como estrategias.

1. **Cuando un documento es largo,** se leen todas sus páginas por lotes; leer solo las primeras deja la información incompleta y la IA la completa con suposiciones.
2. **Cuando la IA responde "No" a una pregunta de presencia** (sello, firma, emisión en agencia), no se muestra ubicación: es una conclusión sobre todo el documento y cualquier recuadro sería inventado.
3. **Cuando la IA devuelve una ubicación fuera de la página o sin tamaño,** se descarta; si se sale apenas del borde, se ajusta a la hoja.
4. **Cuando el PDF trae texto,** la ubicación se toma del texto del propio PDF y es exacta; la ubicación que da la IA en escaneados es aproximada y nunca es prueba.
5. **Cuando un campo no se puede leer,** se marca como ilegible, se resalta en rojo y no se inventa el valor.
6. **Cuando el nombre del archivo identifica el documento,** manda el nombre; la IA solo sugiere otro tipo y la persona decide.
7. **Cuando un archivo dice "Respaldo",** se clasifica como documento adicional y no se lee como parte del checklist.
8. **Cuando un precio viene escrito con el símbolo de moneda y punto** (por ejemplo "Q."), se toma el número a partir del primer dígito; de lo contrario el punto se interpreta como decimal.
9. **Cuando existe el archivo JSON del FEIC,** sus datos se usan como fuente exacta, sin pasar por la IA; trae además las marcas de PEP y CPE.
10. **Cuando el FEIC o su JSON marcan PEP o CPE,** la herramienta se detiene y el caso pasa a revisión manual.
11. **Cuando se comparan textos,** las diferencias solo de espacios o de mayúsculas no son error; las de puntuación en abreviaturas sí. "S.A." con puntos equivale a "Sociedad Anónima".
12. **Cuando se comparan accionistas,** se comparan los nombres como lista sin importar el orden; contra el FEIC solo se comparan los de 10 % o más.
13. **Cuando la última escritura registrada tiene más de 5 años,** se pide confirmar que no existan modificaciones posteriores.
14. **Cuando el dato ancla no coincide con ningún otro documento y los demás coinciden entre sí,** lo más probable es que el ancla esté mal leída. Ver el error E12.
15. **Cuando un nombre de persona se lee de un documento de identidad,** se leen nombres y apellidos por separado; componer el nombre completo es un paso propio y debe respetar el orden del documento.
16. **Cuando el nombre de una persona en el buró no coincide con su documento** (por ejemplo, apellido de soltera contra apellido de casada), se identifica por el número del documento, no por el nombre.
17. **Cuando un informe indica "página X de Y" y faltan páginas,** se pide el informe completo; la última página puede traer moras o demandas.
18. **Cuando falta el buró de un socio con más de 10 % y no hay documento de identidad de los socios,** no se puede asignar cada informe a su dueño: se pide el faltante y la identificación de cada informe.
19. **Cuando una escritura no trae las hojas numeradas,** la completitud se verifica por continuidad del texto entre el final de una hoja y el inicio de la siguiente.
20. **Cuando un buró responde que la empresa "no existe",** se compara el número consultado contra el registro tributario: en Panamá el APC salió vacío porque se consultó con un RUC al que le faltaba un dígito.
21. **Cuando un documento trae dos números parecidos** (en Panamá, el RUC y el número de aviso de operaciones), cada campo del formulario debe tomar el que corresponde.
22. **Cuando un mismo dato de contacto difiere entre documentos** (teléfono o correo), no es error: se registran ambos.
23. **Cuando la proforma no indica el año del bien,** se devuelve; el tipo de bien (pick up, sedán) no es obligatorio si hay marca, modelo y año.
24. **Cuando no está claro quién es el vendor,** se consulta con la persona que ingresa a FIMS, que tiene la lista de vendors.
25. **Cuando el representante es extranjero y Arrend no tiene acceso al buró de su país,** se pide el buró del socio mayoritario.
26. **Cuando un banco corta los estados de cuenta a mitad de mes,** el mes se da por cerrado si el periodo cubre 30 o 31 días; no se pide hasta fin de mes.
27. **Cuando un error está en un documento emitido por un tercero** (banco, registro, empresa de servicios), no se le atribuye a Comercial salvo la vigencia; los errores que sí se devuelven están en los documentos que Comercial llena.
28. **Cuando el número de teléfono o el correo difiere entre la solicitud y el Conoce a tu cliente,** se registran todos en FIMS: si se omite uno, no llegan facturas ni notificaciones al cliente.
29. **Cuando la factura va a nombre de otra empresa (beneficiario fiscal),** esa empresa debe ser del mismo país; un aval sí puede ser de otro país.
30. **Cuando aparece un dato que el equipo nunca había visto,** se consulta con Legal y la respuesta queda como precedente para las siguientes revisiones.
31. **Cuando la persona de la selfie no es el asesor que figura como visitante,** se devuelve, salvo una nota que explique quién visitó y por qué.
32. **Cuando los estados de cuenta mezclan dos cuentas,** se ordenan por cuenta (los tres meses de una y luego los de la otra) y se verifica el mismo número de cuenta en cada serie.
33. **Cuando un grupo comercial tiene varias razones sociales** y la proforma solo trae el logotipo, el vendor se deduce por el tipo de bien y se confirma con el asesor; el nombre registrado en FIMS puede no ser el de la proforma.
34. **Cuando la edad declarada no coincide con la fecha de nacimiento,** se revisa si el cumpleaños cayó entre la visita y la revisión antes de devolver.

---

## 8. Registro de errores

| Id | Qué ocurrió | Cómo se detectó | Cómo se corrigió | Estado |
|---|---|---|---|---|
| E01 | La lectura con IA cambiaba el tipo de un archivo ya clasificado por su nombre | El usuario vio documentos con tipos que no correspondían | La IA solo sugiere; la persona decide con un botón | Definitivo |
| E02 | La herramienta usaba nombres de documentos inventados ("Identificación del representante", "Registro tributario", "Conoce a su cliente") | Reclamo del usuario | Nombres oficiales de la matriz de orden de escaneo, por país; el nombre del archivo es el título | Definitivo; falta confirmar la lista con CGE |
| E03 | Archivos de respaldo clasificados como documentos del checklist | Captura del usuario | Regla: el nombre "Respaldo" los separa como documentos adicionales | Definitivo |
| E04 | Precios escritos con "Q." se leían como decimales y todos los cálculos daban montos mínimos | Captura con resultados absurdos | El número se toma desde el primer dígito | Definitivo |
| E05 | El recuadro de un campo Sí/No con respuesta "No" caía fuera de la hoja | Captura del usuario | Validación de ubicaciones y sin recuadro para respuestas "No" | Definitivo |
| E06 | La lectura enviaba solo las primeras 4 páginas como imagen; los accionistas de la escritura salían incompletos | Nota de la propia lectura | Historia accionaria y transcripción leen todas las páginas por lotes | Parcial: la lectura general de campos sigue con las primeras páginas |
| E07 | Casos de un país revisados con el perfil de otro (faltantes falsos, IVA equivocado) | Proporción constante en las diferencias de cálculo | Detección del país por tipo de documento y por dirección, con aviso y botón para cambiar | Parcial: las señales por dirección son limitadas |
| E08 | Expediente cargado dos veces; documentos y hallazgos duplicados | Lista con documentos repetidos | Comparación por contenido y consulta antes de cargar idénticos | Definitivo |
| E09 | Diferencias solo de espacios marcadas como correcciones | Lista de correcciones con direcciones casi idénticas | Las diferencias de espacios se muestran como iguales | Definitivo |
| E10 | "S.A." contra "Sociedad Anónima" y diferencias de mayúsculas marcadas como error | Revisión del JSON del FEIC | Equivalencias de abreviaturas con puntos; mayúsculas no son error | Definitivo |
| E11 | El FEIC declara solo accionistas de 10 % o más y salía como discrepancia contra la escritura | Prueba con el expediente de prueba | Cruce separado que solo compara accionistas de 10 % o más | Definitivo |
| E12 | El nombre del representante se leyó del DPI con los nombres en orden invertido; como el DPI es el ancla, todos los demás documentos salieron como "No coincide" | Captura del usuario con la vista previa del DPI | Anotado, no ajustado: el usuario pidió no republicar para no perder el expediente cargado | Pendiente |
| E13 | La lista de correcciones se partía en bloques por un límite total de caracteres | Pedido del usuario | Un solo bloque con límite por línea, ajustable | Definitivo |
| E14 | Las líneas para Comercial incluían fórmulas | Revisión de la lista | La fórmula pasó al detalle de Hallazgos; la línea dice el valor actual y el esperado | Definitivo |
| E15 | Barra horizontal en el panel derecho | Pedido del usuario | Letra media unidad más chica, columnas fijas y formularios en una columna | Definitivo; verificación visual pendiente |
| E16 | Botón de transcripción ilegible dentro de la hoja blanca | Captura del usuario | Colores propios del botón dentro de la hoja | Definitivo |
| E17 | Se movió el apartado equivocado (correcciones en lugar de hallazgos del analista) | Reclamo del usuario | Hallazgo del analista como botón en el lugar marcado; correcciones de vuelta como pestaña | Definitivo |
| E18 | El formulario de cruces permitía añadir el ancla dos veces sin explicar por qué no se activaba el botón | Captura del usuario | Mensaje claro, salto automático a otro documento y sugerencias de campos parecidos | Definitivo |
| E19 | La lista de documentos volvía al inicio con cada clic | Pedido del usuario | Se conserva la posición de cada panel | Definitivo |
| E20 | El IVA calculado del bien dio un valor imposible sin alerta | Captura del usuario | Alerta de revisión cuando no es 0 ni el IVA del país | Definitivo |
| E21 | En El Salvador el IVA del bien daba 16.8 % y las correcciones de cálculo salían falsas | Revisión grabada de El Salvador: el valor sin IVA de la cotización incluye el IPM | Anotado: agregar el IPM como dato del cálculo, restarlo del total antes de verificar el IVA del bien y validar el flujo del IPM por separado; cargar los montos de El Salvador (180, 18 y 113 dólares) | Pendiente; no se ajusta mientras el foco sea Guatemala |
| E22 | La primera parte de la grabación de El Salvador no tenía transcripción | Conteo de archivos: seis videos y cinco transcripciones | Transcripción generada automáticamente con un modelo de voz a texto; calidad menor en nombres propios | Definitivo |
| E23 | La fórmula común calcula la opción de compra sobre el valor sin impuesto; en Panamá se calcula sobre el total con ITBMS, y seguro y GPS ya traen impuesto | Revisión grabada de Panamá | Anotado: base de opción de compra y tratamiento del impuesto de seguro y GPS configurables por país | Pendiente; no se ajusta mientras el foco sea Guatemala |
| E24 | La calculadora no modela gastos iniciales financiados en flujo aparte, seguro no financiado, valor residual ni bienes compuestos por varios artículos | Revisión grabada de República Dominicana | Anotado: flujo de gastos administrativos, seguro como cuota aparte, cálculo del valor residual y cruce del anexo artículo por artículo | Pendiente; no se ajusta mientras el foco sea Guatemala |
| E25 | La calculadora asume impuesto en el valor del bien; en Costa Rica el bien va sin impuesto, incluye gastos de inscripción y el 13 % solo aplica a seguro, GPS y cargo del dispositivo | Revisión grabada de Costa Rica | Anotado: impuesto del bien configurable por país y gastos de inscripción como dato del cálculo | Pendiente; no se ajusta mientras el foco sea Guatemala |

### 8.1 Diseño propuesto para corregir E12

1. Extraer del documento de identidad los nombres y los apellidos como campos separados.
2. Comparar nombres de personas como conjunto de palabras: si son las mismas palabras en otro orden, el resultado es "mismo nombre, orden distinto" con nivel Revisión, no Regular.
3. Regla de consenso: si el ancla difiere de todos los documentos y estos coinciden entre sí, se emite un solo hallazgo de Revisión ("posible lectura errónea del ancla") en lugar de una corrección por documento.
4. La ventana flotante con el recorte de la página, que permitió detectar este error, se mantiene en todos los cruces.
5. Permitir que la analista corrija a mano un valor leído, con registro del valor original para la medición. Mientras no exista, las correcciones falsas se marcan como "Falsa alarma" en Hallazgos.

### 8.2 Aprendizaje operativo de E12

Cada vez que la herramienta se actualiza se pierden los documentos cargados. Hace falta guardar el expediente en el navegador para que una actualización no obligue a cargarlo y leerlo de nuevo; mientras eso no exista, las correcciones a la herramienta se acumulan y se publican cuando el usuario termina de revisar un caso.

---

## 9. Riesgos de delegar la revisión a la IA y sus controles

| Riesgo | Control |
|---|---|
| Lectura errónea que genera alarmas falsas o deja pasar errores | Confianza y página por campo; ubicación visible; lo ilegible nunca se da por bueno |
| Un ancla mal leída contamina todos los cruces | Pendiente: regla de consenso (sección 8.1) |
| Comparación de firmas | Siempre revisión humana |
| Criterios de juicio (vistos buenos, notas, excepciones) | Se muestran como Revisión con el motivo; decide la persona |
| Reglas desactualizadas | Cada regla tiene id, fuente y versión; los conflictos van a Riesgos |
| Confianza excesiva en el estado sugerido | Cada hallazgo exige decisión humana y queda registrada |
| Datos de clientes enviados al proveedor de la IA | Punto de gobernanza abierto: sin política de retención ni confirmación formal de Sistemas y Riesgos |
| Uso de IA fuera de control | En la máquina de la analista ya está activo el asistente de IA de Acrobat |

---

## 10. Estado de la herramienta pre alfa

| Componente | Estado |
|---|---|
| Inventario contra el checklist (Guatemala y Honduras) | Funcional |
| Clasificación por nombre, número de orden y sugerencia de IA; respaldos | Funcional |
| Lectura de campos con IA, confianza y ubicación en la página | Funcional |
| Visor con zoom, mano, lupa, desplazamiento con clic derecho, resaltar, subrayar, señalar y descarga con marcas | Funcional; verificación visual pendiente |
| Buscador en el documento y vista de transcripción | Funcional |
| Cruces con ventana flotante y cruces agregados por CGE | Funcional |
| Calculadora editable con datos, fórmulas, cálculos agregados y ventanas de origen | Funcional |
| Historia accionaria por lotes con línea de tiempo y alertas | Funcional; falta validar con una escritura real |
| Hallazgos del analista vinculados a marcas | Funcional |
| Correcciones para el ticket en un solo bloque | Funcional |
| Trazabilidad exportable (decisiones, cambios, hallazgos agregados, marcas) | Funcional |
| Checklists de El Salvador, Costa Rica, Panamá y República Dominicana | Pendiente |
| Comparación de reingresos contra la versión anterior | Pendiente |
| Almacenamiento compartido de cruces y campos agregados | Pendiente, para cuando la usen varias analistas |
| Conservar el expediente cargado entre actualizaciones | Pendiente |

---

## 11. Pendientes

### 11.1 Consultas para CGE

1. Archivo completo del reporte diario de revisión de CGE, incluidas las hojas de gastos de GPS y de traspaso.
2. Checklist vigente por país, incluida la versión ajustada por las analistas.
3. Límite de caracteres de un ticket de Hive.
4. Monto de traspaso de vehículos en Guatemala (la tabla muestra uno para vehículos y otro para motos).
5. Monedas de Costa Rica y Panamá en la tabla de IVA por país.
6. Cargo de dispositivo y GPS y cuota mensual de GPS en los demás países, y cada cuánto cambian.
7. Aplicación de las fórmulas a vehículos nuevos en Guatemala.
8. Firma del asesor en el Conoce a tu cliente.
9. Documento contra el que se cruza la dirección en Honduras.
10. Plazo para ser cliente de cartera en cada país.
11. Procedimiento vigente de reingresos.
12. Persona que da hoy el visto bueno de vehículos usados en Guatemala.
13. Lista oficial de nombres de documentos por país (matriz de orden de escaneo actual).

14. Montos de cargo de dispositivo y GPS por país distintos de Guatemala, Honduras y El Salvador.
15. Lista vigente de cómo cada vendor de El Salvador maneja el IPM y las placas.

16. Panamá: qué es el "bono cliente", cómo se calculan los gastos iniciales financiados y si es temporal.
17. Panamá: si se pide comprobante cuando el APC muestra una hipoteca con atraso.
18. Umbral de cliente de cartera: un año para la definición contra dos años para eximir declaraciones en Guatemala.

19. República Dominicana: qué cobro explica la diferencia de alrededor de 1.00 en la renta total, y si se cobra cuota de endoso cuando el seguro es endosado.
20. Matriz de parametrización: de qué documento sale cada dato por país. Lo pidieron las propias analistas y es la base del entregable de criterios de CGE.

21. Costa Rica: si la propuesta Arrend es obligatoria con cotizador manual (Panamá dijo que sí; Costa Rica dijo que ya no se exige) y qué cubren los gastos de inscripción de las proformas.

### 11.2 Pendientes técnicos

1. Corregir E12 con el diseño de la sección 8.1.
2. Guardar el expediente cargado para que una actualización no lo borre.
3. Cargar el checklist de El Salvador con el archivo disponible.
4. Comparar reingresos contra la versión anterior.
5. Medición: usar las subtareas históricas de Hive y los hallazgos agregados por el analista para medir detección y alarmas falsas.
6. Corregir E21 (IPM de El Salvador) cuando se retome ese país.
7. Corregir E23 (base de cálculo de Panamá) cuando se retome ese país.
8. Corregir E24 (gastos financiados, seguro aparte, valor residual y bien compuesto) cuando se retome República Dominicana.
9. Corregir E25 (bien sin impuesto y gastos de inscripción de Costa Rica) cuando se retome ese país.
