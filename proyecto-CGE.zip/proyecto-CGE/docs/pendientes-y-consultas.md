# Pendientes y consultas

Consolidado para enviar a CGE y para el equipo del proyecto. Sin nombres de personas.

## 1. Consultas para CGE

1. Archivo completo del reporte diario de revisión de CGE, incluidas las hojas de gastos de GPS y de traspaso.
2. Checklist vigente por país, con su versión y fecha, incluida la versión ajustada por las analistas.
3. Límite de caracteres de un ticket de Hive.
4. Monto de traspaso de vehículos en Guatemala. El Excel de orden de documentación indica 1,835 quetzales tanto para vehículos como para motos; confirmar su vigencia.
5. Monedas de Costa Rica y Panamá en la tabla de IVA por país (aparecen intercambiadas).
6. Cargo de dispositivo y GPS y cuota mensual de GPS en los demás países, y cada cuánto cambian.
7. Aplicación de las fórmulas a vehículos nuevos en Guatemala.
8. Firma del asesor en el Conoce a tu cliente: ¿se exigen las dos firmas o basta una?
9. Documento contra el que se cruza la dirección en Honduras (recibo o permiso de operaciones).
10. Plazo para ser cliente de cartera en cada país (un año para la definición contra dos años para eximir declaraciones en Guatemala).
11. Procedimiento vigente de reingresos.
12. Persona que da hoy el visto bueno de vehículos usados en Guatemala.
13. Lista oficial de nombres de documentos por país (matriz de orden de escaneo actual).
14. Lista vigente de cómo cada vendor de El Salvador maneja el impuesto a la primera matrícula y las placas.
15. Panamá: qué es el "bono cliente", cómo se calculan los gastos iniciales financiados y si es temporal; si se pide comprobante de una hipoteca atrasada en el APC.
16. República Dominicana: qué cobro explica la diferencia de alrededor de 1.00 en la renta total y si se cobra cuota de endoso con seguro endosado.
17. Costa Rica: si la propuesta Arrend es obligatoria con cotizador manual y qué cubren los gastos de inscripción de las proformas.
18. Guatemala: mínimo de fotos en el Conoce a tu cliente (3 o 5); si el aval debe traer Conoce a tu cliente; desde qué año de modelo el precio del vehículo trae IVA y cómo se confirma que un híbrido está exento.
19. Matriz de parametrización: de qué documento sale cada dato, por país. Lo pidieron las propias analistas y es la base del entregable de criterios de CGE.
20. Aprobación de la lista de documentos "no necesarios" de `modulos-y-documentos.md`.

## 2. Decisiones pendientes del dueño del proyecto

1. **Rango de "Ilegible":** se escribió "mayor o igual a 50", que se solapa con Bajo (50 a 84). Se interpretó como menos de 50.
2. **Clasificación del expediente:** se derivó de la de sus documentos (algún documento no pasa, el expediente no pasa). Confirmar.
3. **PEP y CPE:** siguen deteniendo el caso. Falta definir si también deben avisar y proceder, como las resoluciones del Comité.
4. **Numeración de módulos:** CGE usa del 1 al 7; Riesgos usa 1, 2, 5, 6 y 7. Definir si se alinean.
5. **Reglas marcadas como propuesta (fuente PP)** en `reglas_y_severidad.md`: confirmar con CGE antes de tratarlas como firmes.
6. **Instrucciones del proyecto en claude.ai:** pegar el contenido actualizado de `docs/instrucciones-proyecto-claude-ai.md`, porque las vigentes todavía dicen que la herramienta solo indica y que no procesa las resoluciones del Comité.
7. **Estado de la regla de datos reales:** hay un permiso temporal de citar datos reales dentro de la conversación de trabajo; revisarlo antes de usar datos reales fuera de ella.

## 3. Pendientes técnicos

1. Corregir E12 con el diseño de la sección 8.1.
2. Guardar el expediente cargado para que una actualización no lo borre.
3. Cargar el checklist de El Salvador con el archivo disponible.
4. Comparar reingresos contra la versión anterior.
5. Medición: usar las subtareas históricas de Hive y los hallazgos agregados por el analista para medir detección y alarmas falsas.
6. Corregir E21 (IPM de El Salvador) cuando se retome ese país.
7. Corregir E23 (base de cálculo de Panamá) cuando se retome ese país.
8. Corregir E24 (gastos financiados, seguro aparte, valor residual y bien compuesto) cuando se retome República Dominicana.
9. Corregir E25 (bien sin impuesto y gastos de inscripción de Costa Rica) cuando se retome ese país.
10. Llevar a la herramienta web la clasificación Pasa, No pasa y Revisión y la escala de confianza de cinco niveles.
11. Extraer `SH-ESC` como habilidad propia con el contrato de `contrato_subhabilidades.md`.
12. Correr los 18 casos de `casos_prueba.md` contra la habilidad y registrar el resultado.

## 4. Pendientes para el proyecto de Riesgos (`digitador-arrend`)

No modifiques esa habilidad desde este repositorio. Estos puntos afectan a los montos y socios que vacía:

1. La exención del impuesto en el vehículo híbrido.
2. El impuesto escalonado del vehículo eléctrico (Green Fleet).
3. La regla del anexo 5: si un accionista es una empresa, la estructura vigente sale de ese anexo.
4. El impuesto a la primera matrícula y las placas de El Salvador quedan fuera del valor del bien.
5. El bono vendor de Honduras forma parte de los gastos iniciales.
6. El "bono cliente" de Panamá, antes de vaciar gastos iniciales.
7. Los gastos financiados y el seguro fuera del financiamiento de República Dominicana cambian la renta que se vacía.

## 5. Gobernanza (puntos abiertos)

1. El contenido de los expedientes viaja al proveedor de la inteligencia artificial.
2. No hay política de retención de sesiones.
3. Falta la confirmación formal de Sistemas y Riesgos.

Al trabajar con Claude Code sobre expedientes reales aplica el mismo punto 1: el contenido que Claude Code lee se envía al proveedor.
