# Hoja de ruta

Estado al 20 de noviembre de 2026. Sin nombres de personas: los responsables van
por rol.

## 1. Acuerdos de la revisión del prototipo (17 de noviembre)

| Tema | Acuerdo | Responsable |
|---|---|---|
| Alcance | Solo Guatemala, que concentra cerca del 75 % de los casos | Todos |
| Primer módulo | Lectura de escrituras: accionistas, cambios de socios y de nombre, datos de la sociedad y del representante | Analista de datos |
| Entrada | CGE entrega los puntos a buscar y de qué documento tomarlos | Encargado y jefatura de CGE |
| Salida | Hoja por expediente que clasifica cada término, documento y expediente | Analista de datos |
| Método | Sesiones presenciales en CGE, una o dos por día, con el analista nuevo | Analista de datos y CGE |
| Accesos | Escáner Ventas, Claude Code (requiere autorización de gerencia general) y accesos del analista nuevo | Gerencia de la Oficina de Proyectos |
| Capacidad | Pasar lo de Riesgos al analista nuevo y definir tiempo compartido | Gerencia de la Oficina de Proyectos y jefatura de BI |

## 2. Lo que ya existe

| Entregable | Dónde |
|---|---|
| Habilidad central del clasificador (orquestador) | `plugins/clasificador-arrend/` |
| Reglas de Guatemala con id, catálogo de datos, escala de confianza, formatos, casos de prueba | `plugins/.../references/` |
| Reportes técnicos y de aprendizaje por país | `docs/reportes-por-pais/` |
| Reporte técnico y registro de errores | `docs/reporte-tecnico-preclasificador-cge.md` |
| Documentos y módulos necesarios e innecesarios | `docs/reportes-por-pais/modulos-y-documentos.md` |
| Bodega de revisiones de entrenamiento (8 a 10) | `docs/bodega-revisiones-entrenamiento.md` |
| Prototipo web pre alfa | `herramienta/preclasificador-cge.html` |
| Checklists extraídos a texto | `fuentes/checklists/` |

## 3. Camino propuesto

**Paso 1. Insumos y accesos (esta semana).**
- Recibir de CGE la lista de criterios para escrituras: qué dato, de qué documento y cuándo es No pasa o Revisión.
- Cerrar accesos y seguir el trámite de Claude Code.
- Primeras sesiones presenciales con escrituras reales de Guatemala.

**Paso 2. Módulo de escrituras (semanas 1 y 2).**
- Corregir lo que más pesa en confianza: nombres en otro orden y regla del dato ancla (E12), estructura vigente desde el anexo 5 cuando los accionistas son empresas, y no perder el expediente cargado al actualizar.
- Convertir `SH-ESC` en habilidad propia usando el contrato de `contrato_subhabilidades.md`.
- Llevar a la herramienta la clasificación Pasa, No pasa y Revisión y la escala de confianza de cinco niveles.

**Paso 3. Entrenamiento por lotes (semanas 2 a 5).**
- Lote de 15 escrituras con la respuesta de la analista como referencia. Se mide acierto de la estructura vigente, falsas alarmas y tiempo ahorrado.
- Calibrar los rangos de confianza con las decisiones de CGE. Meta propuesta: estructura vigente correcta en 95 % de unos 70 casos (tomada de la experiencia de Riesgos; no es un compromiso acordado).

**Paso 4. Uso en paralelo y validación.** CGE usa la hoja en casos reales sin dejar su revisión; con la meta alcanzada, pasa a producción para escrituras de Guatemala.

**Paso 5. Resto de módulos, sin compromiso de entrega.** Inventario, cruces, cálculos y correcciones siguen avanzando. Orden propuesto: SH-LEC, SH-CRU, SH-REI (el reingreso es lo que más se repite), luego buró, información financiera, cálculos y negocio.

## 4. Alcance y límites

**Dentro:** Guatemala, persona jurídica; escritura, modificaciones, anexo 5 y carta accionaria; clasificación y confianza por término; cruce de accionistas, razón social y representante contra FEIC, Conoce a tu cliente y solicitud.

**Fuera, por ahora:** otros países; los demás documentos como entrega comprometida; integración con Hive o FIMS; comparación de firmas como decisión.

| Límite | Efecto | Estrategia |
|---|---|---|
| Un solo recurso compartido con Riesgos | El avance depende de una persona | Pasar Riesgos al analista nuevo; bloques fijos de tiempo para CGE |
| Accesos pendientes | Sin casos reales no hay entrenamiento | Fecha y responsable por acceso; entrenar con los casos que CGE comparta |
| La herramienta pierde lo cargado al actualizarse | Cada corrección obliga a cargar de nuevo | Guardar el expediente en el navegador |
| Escrituras largas, manuscritas o sin numeración | Lectura aproximada | Todas las páginas por lotes, página de respaldo por dato, Revisión en lo dudoso |
| Criterio cualitativo de CGE | La IA decide en blanco y negro | Criterios escritos, criterios flexibles aprobados por la jefatura y estado Revisión |
| Gobernanza abierta | La plataforma puede cambiar | Mantener reglas y criterios separados de la herramienta |

## 5. Propuesta para presentar a CGE

1. La hoja de resultado por expediente (clasificación de cada término, documento y expediente, con confianza y fuente).
2. El plan de entrenamiento por lotes, con metas.
3. Las dependencias, con dueño y fecha.
