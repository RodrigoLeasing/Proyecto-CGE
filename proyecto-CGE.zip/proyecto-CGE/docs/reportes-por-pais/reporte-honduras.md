# Honduras: reporte técnico y de aprendizaje

**Fecha:** 19 de noviembre de 2026
**Uso:** base de conocimiento del modelo pre clasificador de expedientes de CGE.
**Privacidad:** sin datos de clientes ni de personas; ejemplos numéricos ficticios.

---

## 1. Resumen

1. **No hay FEIC ni carta de buró.** El Conoce a tu cliente y la solicitud de crédito cargan con todos los datos del cliente, y por eso concentran los errores.
2. **Es el país con más reprocesos observados.** Un caso dio 4 vueltas: en cada una Comercial corrigió lo pedido y rompió otra cosa.
3. **Las escrituras son largas y dispersas.** Hasta 90 páginas, con accionistas repartidos entre varias modificaciones; manda la última.
4. **El nombramiento vive dentro de la escritura** y se valida con los cuadros de inscripción y matrícula al final.
5. **El impuesto es de 15 %** y el precio de la proforma lo trae incluido.

---

## 2. Fuentes

| Fuente | Qué aportó |
|---|---|
| Revisión 2: persona jurídica nueva, tres negocios de camiones con plataforma | Requisitos, criterios, ciclo de correcciones, fórmulas con 15 % |
| Excel de orden de documentación y checklist RI-HN-FO-01A a 01K | Documentos por tipo de cliente y producto |
| Reporte diario de revisión de CGE | Montos fijos y traspaso |

Un solo caso grabado: las frecuencias de error de este reporte son provisionales.

---

## 3. Documentos del expediente

| Persona jurídica | Persona individual | Empresa individual |
|---|---|---|
| 1 Información financiera | 2 DNI | 1.2 Declaraciones de impuestos |
| 1.2 Declaraciones de impuestos | 3 Constancia de ingresos | 2 DNI |
| 3 Formulario Conoce a tu cliente | 4 Estados de cuenta | 3 Certificación de ingresos |
| 5 Estados de cuenta | 5 Infornet - TransUnion | 4 Estados de cuenta |
| 6 Infornet - TransUnion (sociedad, representante y socios) | 6 RTN | 5 Infornet - TransUnion |
| 7 DNI / pasaporte del R.L. | 7 Recibo de servicios | 6 Permiso de operaciones |
| 8 Permiso de operaciones | 8 Formulario Conoce a tu cliente | 7 RTN |
| 9 Escritura, con el nombramiento; carta accionaria y anexo de beneficiarios si aplican | | 8 Recibo de servicios |
| RTN de la empresa y R.L. | | 9 Formulario Conoce a tu cliente |
| Recibo | | |

**Negocio de Leasing Financiero:** 1 hoja de negociación; 2 solicitud de crédito para firmar; 3 checklist de seguro; 3.1 licencia (si aplica); 4 cotizador o mejora de seguro (si aplica); 5 cotización Arrend; 6 flujo; 7 cotización vendor, proforma o carta proforma.

No existe checklist de Leasing Inmobiliario para Honduras.

---

## 4. Catálogo de datos: qué documento manda

| Dato | Documento que manda | Se cruza contra |
|---|---|---|
| Razón social, con su puntuación exacta ("S. de R.L.", "S.A. de C.V.") | Permiso de operaciones y escritura | Conoce a tu cliente, solicitud, cotización, estados financieros |
| Dirección | Recibo (2 meses o menos); el checklist menciona el permiso de operaciones | Todos los formularios; la dirección de planta puede variar por sucursales |
| Representante y número de identidad | DNI | Conoce a tu cliente, solicitud |
| RTN de la empresa y del representante | RTN (el del representante es su identidad más un dígito) | Solicitud |
| Cargo y plazo de la representación; inscripción, presentación y matrícula | Escritura que contiene el nombramiento | Conoce a tu cliente, solicitud |
| Accionistas | Última escritura | Conoce a tu cliente, solicitud |
| Capital autorizado y pagado; número y fecha de escrituras | Escritura de constitución y cada modificación | Solicitud |
| Bien completo (camión más carrocería) y precio con impuesto | Proforma | Hoja, Conoce a tu cliente, solicitud, cotización, flujo |
| Condiciones, bono vendor y notas | Hoja de negociación | Conoce a tu cliente, cotización, flujo |

---

## 5. Orden de revisión

**Orden real:** información financiera, declaraciones, Conoce a tu cliente (contra permiso, recibo, DNI y escritura), estados de cuenta, buró, DNI, permiso, RTN, escrituras y recibo; después cada negocio y los cálculos.

**Orden recomendado para la herramienta:**
1. Inventario, porque es común que lleguen 5 de 10 documentos.
2. Escrituras en orden cronológico, con la historia accionaria y el nombramiento vigente.
3. Permiso de operaciones, DNI, RTN y recibo como anclas.
4. Conoce a tu cliente y solicitud contra las anclas.
5. Buró, información financiera, declaración anual y estados de cuenta.
6. Proforma, hoja con sus notas, cotización y flujo, por cada negocio.
7. Comparación contra la versión anterior en cada reingreso.

---

## 6. Estrategias, criterios en vivo, reglas y excepciones

- **Escrituras:** se leen por fechas y la última manda. El revisor busca entre todas la que coincide con el número y la fecha declarados; si ninguna coincide, se pide.
- **Auditados:** en Honduras a veces sellan todas las páginas o ninguna; ambas formas valen si el dictamen dice que fueron auditados.
- **Contador:** CGE no valida que sea el correcto; lo ve Riesgos.
- **Varios representantes:** toda la documentación debe ser del que firma.
- **Negocios repetidos:** con varios negocios del mismo cliente, los errores del madre se repiten en cada ticket.
- **Seguro endosado:** sin checklist de seguro ni cuota; puede venir una nota que lo explique.
- **Correcciones:** se envían en el ticket y también por correo; el revisor llegó a llamar a la asesora y aun así volvieron otros cambios.
- **Uso de IA por la analista:** probó una IA para sacar accionistas y le devolvió los de una escritura anterior; dejó de usarla.

**Criterios que decide la persona de CGE:** parecido de firmas, cuál representante firma, qué escritura es la vigente cuando hay dudas y si un cargo distinto entre documentos es el mismo cargo.

---

## 7. Reglas, conflictos y precedentes

| Regla | Nivel |
|---|---|
| Falta el permiso de operaciones, el DNI o un informe de buró | Crítico |
| Mora mayor a 60 días sin respaldo | Crítico |
| Falta el RTN del representante | Regular |
| Accionistas distintos a los de la última escritura | Regular |
| Cargo del representante distinto entre documentos | Regular |
| Conoce a tu cliente sin hora de visita o con la empresa como entrevistado | Regular |
| Bien descrito sin la carrocería o con un solo vendor cuando son dos | Regular |
| Monto solicitado distinto al precio, aunque sea por un centavo | Regular |
| Páginas duplicadas en un informe de buró | Regular |
| Escritura borrosa | Regular |

**Conflicto:** el checklist cruza la dirección contra el permiso de operaciones; la práctica la cruza contra el recibo.

**Precedente:** cliente de cartera es el que cumple un año con Arrend.

---

## 8. Cálculos

| Concepto | Fórmula |
|---|---|
| Valor sin impuesto | Precio de la proforma ÷ 1.15 |
| Renta inicial con impuesto | Valor sin impuesto × % × 1.15 |
| Gastos iniciales con impuesto | Valor sin impuesto × % + 4,950.00 × 1.15 (L5,692.50) + bono vendor |
| Pago inicial | Renta inicial + gastos iniciales |
| Opción de compra | Valor sin impuesto × % + traspaso de L2,875 |
| Cuota mensual | (Renta + seguro + GPS de L486) × 1.15 |
| Desembolso del flujo | Valor sin impuesto − renta inicial sin impuesto |

Ejemplo ficticio: precio 115,000.00, renta inicial 10 %, gastos 1.5 %, bono vendor 2,500.00. Valor sin impuesto: 100,000.00. Renta inicial: 11,500.00. Gastos iniciales: 1,500.00 + 5,692.50 + 2,500.00 = 9,692.50.

---

## 9. Errores

| Frecuencia | Error | Cómo se detecta |
|---|---|---|
| Común | Documentación incompleta | Inventario |
| Común | Renta inicial o plazo del Conoce a tu cliente distintos a la hoja | Cruce |
| Común | Dígitos equivocados en el documento del representante | Cruce contra el DNI |
| Común | Proforma sin datos del vendor | Lectura |
| Común | Correcciones que rompen datos ya correctos | Comparación de versiones |
| Posible | Accionista declarado con 100 % cuando la escritura muestra varios | Historia accionaria |
| Posible | Número de presentación o matrícula distinto | Cruce contra la escritura |
| Posible | Plazo de la cotización con meses de más | Cruce contra la hoja |
| Raro | Precio de la proforma mal sumado con el impuesto | Recalcular |
| Raro | Diferencia de centavos reportada por un cálculo manual equivocado | Recalcular con la fórmula |

---

## 10. Relación con `digitador-arrend`

- El digitador registra RTN, DNI, Infornet y TransUnion de Honduras, lempiras con tipo de cambio del día e impuesto de 15 %, y no pide estado patrimonial: coincide con CGE.
- El tipo de cambio es dato de Riesgos; CGE solo verifica que la moneda sea la misma en todos los documentos.
- Pendiente para Riesgos: el bono vendor forma parte de los gastos iniciales y debe considerarse al vaciar montos.

---

## 11. Qué automatizar y qué dejar a la persona

| Automatizar | Dejar a la persona |
|---|---|
| Inventario y páginas duplicadas | Cuál representante firma |
| Historia accionaria en orden cronológico | Confirmar la escritura vigente |
| Cruces de formularios contra las anclas | Firmas |
| Recalcular con 15 % y bono vendor | Explicaciones del asesor |
| Comparación de reingresos | Decidir si se llama al asesor |

---

## 12. Dudas abiertas para CGE

1. ¿La dirección se cruza contra el recibo o contra el permiso de operaciones?
2. ¿Cuándo es obligatoria la nota de seguro endosado?
3. ¿El bono vendor siempre va en los gastos iniciales?
4. ¿El traspaso de vehículos es L2,875 o 115 dólares, y de qué depende?
5. ¿Se necesita un segundo caso de Honduras con persona individual para completar el entrenamiento?
