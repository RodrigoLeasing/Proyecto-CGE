# Costa Rica: reporte técnico y de aprendizaje

**Fecha:** 19 de noviembre de 2026
**Uso:** base de conocimiento del modelo pre clasificador de expedientes de CGE.
**Privacidad:** sin datos de clientes ni de personas; ejemplos numéricos ficticios.

---

## 1. Resumen

1. **No hay recibo ni dirección formal.** Manda la dirección descriptiva del informe de visita y debe repetirse igual en todos los documentos.
2. **La personería jurídica reúne lo que en Guatemala dan el RTU, la escritura y el nombramiento.**
3. **El bien se cotiza sin impuesto.** El 13 % solo se aplica a seguro, GPS y cargo del dispositivo.
4. **Los gastos iniciales siempre van financiados,** en un flujo aparte.
5. **Es el país donde más pesa el ojo del analista:** en un solo caso se detectaron cuatro errores que la revisión original dejó pasar, uno de ellos por reconocer al asesor en la foto.

---

## 2. Fuentes

| Fuente | Qué aportó |
|---|---|
| Revisión 5: sociedad anónima, Leasing Financiero de un vehículo en dólares | Requisitos, Credid, autorización SUGEF, cálculos, vendors agrupados |
| Excel de orden de documentación y checklist RI-CR-FO-01A a 01K | Documentos por tipo de cliente y producto |

El checklist de Costa Rica recibido tiene notas de edición sin aplicar en varias hojas; debe confirmarse su versión final. Un solo caso grabado.

---

## 3. Documentos del expediente

| Persona jurídica | Persona individual | Empresa individual |
|---|---|---|
| 1 Información financiera | 2 Cédula | 1.2 Declaraciones (Hacienda) |
| 1.2 Declaraciones de impuestos según régimen | 3 Constancia de ingresos u orden patronal | 2 Cédula |
| 3 Formulario Conoce a tu cliente (informe de visita) | 4 Estados de cuenta (cuando aplique) | 3 Certificación de ingresos u orden patronal |
| 5 Estados de cuenta | 5 Carta de buró y Credid | 4 Estados de cuenta |
| 6 Carta de buró Credid (sociedad, representante y socios) | 6 SUGEF | 5 Carta de buró y Credid |
| 7 Cédula / pasaporte del R.L. | 8 Formulario Conoce a tu cliente | 6 Permiso de salud, patente de comercio o permiso sanitario |
| 8 Permiso de salud, patente o permiso sanitario | | 9 Formulario Conoce a tu cliente |
| 9 Personería jurídica | | 10 SUGEF |
| 10 SUGEF | | |

**Negocio de Leasing Financiero:** 1 hoja de negociación; 2 solicitud de crédito; 2.1 datos generales (persona jurídica); 3 checklist de seguro; 3.1 licencia; 4 mejora de seguro; 5 cotización Arrend; propuesta Arrend (ya no obligatoria; si viene con errores, se devuelve); 6 flujo; 7 proforma. Cliente nuevo: solicitud y datos generales siempre firmados.

---

## 4. Catálogo de datos: qué documento manda

| Dato | Documento que manda | Se cruza contra |
|---|---|---|
| Razón social y cédula jurídica (los guiones no importan) | Personería jurídica o patente | Todos los formularios, estados financieros, Credid, SUGEF |
| Fecha de inicio de operaciones y vencimiento de la entidad | Plazo de la entidad en la personería | Conoce a tu cliente, solicitud |
| Representante, cargo y vigencia | Cédula vigente y nombramientos de la personería | Conoce a tu cliente, solicitud, datos generales, autorización Credid |
| Socios y porcentajes | Declaración jurada (participantes y capital social) | Conoce a tu cliente, solicitud |
| Dirección | Informe de visita | Solicitud, datos generales, checklist de seguro |
| Bien, 4x2 o 4x4, combustible, año | Proforma | Hoja, solicitud, checklist de seguro, cotización, flujo |
| Total a financiar | Total de la proforma en dólares, sin sumar la prima | Solicitud, datos generales, cotización, flujo |
| Condiciones | Hoja de negociación | Conoce a tu cliente, cotización, flujo, propuesta |
| Asesor | Hoja de negociación | Conoce a tu cliente (nombre, firma y selfie) |

---

## 5. Orden de revisión

**Orden real:** el del checklist, del 1 al 10; el Conoce a tu cliente se valida abriendo la hoja y la proforma para las condiciones. Para el negocio, la analista conserva formulario, cédula y personería.

**Orden recomendado para la herramienta:**
1. Inventario y separación de respaldos (las sociedades anónimas adjuntan muchos).
2. Anclas: personería jurídica, cédula, patente y declaración jurada.
3. Conoce a tu cliente contra las anclas y contra la hoja.
4. Autorización y Credid; autorización SUGEF.
5. Información financiera, declaración y estados de cuenta ordenados por cuenta.
6. Proforma, hoja, cotización, flujos y consolidado.
7. Solicitud, datos generales y checklist de seguro.

---

## 6. Estrategias, criterios en vivo, reglas y excepciones

- **Información financiera:** dos cerrados y el parcial (a medio año o a septiembre); se aceptan firmas digitales; el balance de comprobación hace de integraciones y es obligatorio en el último periodo.
- **Declaración:** impuesto sobre las utilidades, anual; basta el último periodo completo, aunque sea extenso.
- **Edad:** si el cumpleaños cayó entre la visita y la revisión, puede pasar; de lo contrario se corrige.
- **Estados de cuenta:** mismo número de cuenta en cada serie; si vienen dos cuentas mezcladas, se ordenan por cuenta.
- **Credid:** juicios civiles y moras; telecomunicaciones y servicios se ignoran aunque estén en mora.
- **SUGEF:** siempre firmada; el tipo de persona debe ser jurídica cuando se consulta a la sociedad.
- **Proforma:** si no trae placas, el bien es nuevo; si viene en colones con tipo de cambio, se toma el total en dólares; la prima no se suma.
- **4x2 y 4x4:** definen el correlativo y el tipo en el checklist de seguro (camioneta sport o camioneta agrícola).
- **Deudor mancomunado:** nunca vacío; "No aplica" si no hay aval.

**Criterios que decide la persona de CGE, no la herramienta:**
1. **Identidad del asesor.** La selfie debe ser del asesor que figura como visitante. Las analistas con experiencia reconocen a los asesores de cada país; una IA no puede asegurarlo con una foto.
2. **Certificación del vendor.** Un grupo comercial tiene varias razones sociales, la proforma puede traer solo un logotipo y el nombre en FIMS puede ser otro; se deduce por el tipo de bien y se confirma con el asesor.
3. Parecido de firmas.

---

## 7. Reglas, conflictos y precedentes

| Regla | Nivel |
|---|---|
| Juicio civil o mora financiera sin respaldo | Crítico |
| Falta la personería jurídica o la autorización SUGEF firmada | Crítico |
| Socios del Conoce a tu cliente distintos a la declaración jurada | Regular |
| Condiciones del Conoce a tu cliente distintas a la hoja | Regular |
| Selfie de una persona distinta al asesor, sin nota | Regular |
| Tipo de persona equivocado en la autorización SUGEF | Regular |
| Prima sumada al total a financiar | Regular |
| Dirección distinta entre documentos | Regular |
| Propuesta Arrend adjunta con errores | Regular |

**Conflicto:** en Panamá se dijo que la propuesta Arrend es obligatoria con cotizador manual en Costa Rica; en Costa Rica se dijo que ya no se exige.

---

## 8. Cálculos

| Concepto | Fórmula |
|---|---|
| Valor del bien | Total de la proforma, con los gastos de inscripción incluidos; sin agregar ni quitar impuesto |
| Renta inicial | Valor del bien × % |
| Opción de compra | Valor del bien × %; sin costo fijo de traspaso |
| Gastos iniciales (financiados) | Valor del bien × % + 180 × 1.13 |
| Seguro y GPS | En el flujo sin impuesto; en la cotización × 1.13 (GPS de 18 dólares: 20.34) |
| Cuota mensual | Renta del bien + cuota de gastos + seguro × 1.13 + GPS × 1.13 |
| Flujos | Bien, gastos (sin renta inicial) y consolidado |

El cobro de dispositivo y GPS con impuesto figura en la guía de CGE como 105,768 colones.

Ejemplo ficticio: valor del bien 20,000.00, renta inicial 20 %, gastos 1.5 %, opción de compra 15 %. Renta inicial: 4,000.00. Gastos iniciales: 300.00 + 203.40 = 503.40. Opción de compra: 3,000.00.

---

## 9. Errores

| Frecuencia | Error | Cómo se detecta |
|---|---|---|
| Común | Plazo u otra condición del Conoce a tu cliente distinta a la hoja | Cruce |
| Común | Socios declarados que no coinciden con la declaración jurada | Cruce y suma de participaciones |
| Común | Estados de cuenta de varias cuentas mezclados | Número de cuenta |
| Posible | Selfie de otro asesor | Revisión humana |
| Posible | Tipo de persona equivocado en SUGEF | Lectura de la casilla |
| Posible | Prima sumada al monto a financiar | Recalcular |
| Posible | Vendor distinto al registrado en FIMS | Consulta |
| Raro | Edad desfasada por un cumpleaños reciente | Fecha de la visita |
| Raro | Documento de socios borroso | Lectura |

---

## 10. Relación con `digitador-arrend`

- El digitador distingue el reporte CIC de la SUGEF del formulario de consentimiento: advierte que el archivo "SUGEF" suele ser solo el consentimiento. Coincide con CGE, que valida la autorización firmada.
- El digitador revisa en Credid el estado tributario ante Hacienda; CGE revisa juicios y moras. Son lecturas complementarias del mismo informe.
- El digitador tiene un flujo específico para persona individual asalariada (orden patronal, colones a dólares): Costa Rica recibe más personas individuales que empresas, así que ese flujo es el más relevante para la siguiente etapa.

---

## 11. Qué automatizar y qué dejar a la persona

| Automatizar | Dejar a la persona |
|---|---|
| Separar respaldos y ordenar estados de cuenta por cuenta | Identidad del asesor en la selfie |
| Cruces contra personería y declaración jurada | Certificación del vendor |
| Verificar la casilla de tipo de persona en SUGEF | Parecido de firmas |
| Recalcular sin impuesto en el bien | Tolerancia de edad por cumpleaños |
| Detectar la prima sumada | Direcciones descriptivas ambiguas |

---

## 12. Dudas abiertas para CGE

1. ¿Cuál es la versión final del checklist de Costa Rica?
2. ¿La propuesta Arrend es obligatoria en algún caso?
3. ¿Qué cubren los gastos de inscripción de las proformas?
4. ¿Hay costo de traspaso en algún caso?
5. ¿Existe una lista de asesores por país con foto, para apoyar la verificación de la selfie?
6. ¿Existe una lista de grupos comerciales con sus razones sociales y el nombre con que están en FIMS?
