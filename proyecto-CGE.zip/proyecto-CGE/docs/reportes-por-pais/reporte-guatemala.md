# Guatemala: reporte técnico y de aprendizaje

**Fecha:** 19 de noviembre de 2026
**Uso:** base de conocimiento del modelo pre clasificador de expedientes de CGE.
**Privacidad:** sin nombres de clientes ni de personas, sin documentos de identidad, NIT ni montos de casos reales. Los ejemplos numéricos son ficticios; los montos de política sí se incluyen.

---

## 1. Resumen

Guatemala concentra cerca del 75 % de los casos y es el único país con FEIC. Cinco aprendizajes mandan sobre el resto:

1. **El FEIC es el documento ancla.** Cuando viene correcto, el revisor lo usa como fuente para todo lo demás y el caso avanza rápido; cuando trae errores, cada formulario se valida contra los documentos fuente y el tiempo se duplica.
2. **La estructura accionaria vigente no siempre sale de la escritura.** Si los accionistas son personas, sale de la escritura y sus modificaciones; si son empresas, sale del anexo 5 de beneficiarios finales.
3. **El reingreso se revisa completo.** El revisor compara toda la documentación contra la versión anterior, no solo las correcciones pedidas, porque Comercial suele cambiar datos que no se le pidieron.
4. **El impuesto depende del bien.** Usado de 2024 o anterior: sin IVA en el precio. Híbrido: exento. Blindaje y accesorios: con IVA. Eléctrico (Green Fleet): IVA escalonado por año.
5. **Las notas de la hoja de negociación deciden si el caso se puede revisar sin escalar.** Cuando no explican cómo se calculó algo, el revisor tiene que llamar al encargado.

---

## 2. Fuentes

| Fuente | Qué aportó |
|---|---|
| Revisión 1: persona jurídica nueva, Leasing Financiero Usado | Orden de revisión, cruces del FEIC, criterios de buró, fórmulas del usado |
| Revisión 8 (entrenamiento): persona jurídica nueva con aval, crédito puente de maquinaria | Revisión del aval, estrategia de documentos abiertos, validación de escritura sin numeración |
| Revisión 9 (entrenamiento): reingreso de Green Fleet, camioneta híbrida con blindaje | Revisión de reingresos, exención del híbrido, bien compuesto, escalamiento al encargado |
| Fragmento de la revisión 10: reingreso de crédito puente para Junta Directiva | Tolerancia de centavos, flujo de Junta Directiva, accesorios |
| Reunión de revisión del prototipo | Regla del anexo 5, foco en escrituras |
| Excel de orden de documentación, checklists RI-GT-FO-01A a 01K y JSON del FEIC | Documentos por tipo de cliente y producto, nomenclaturas, montos fijos |

---

## 3. Documentos del expediente

### 3.1 Expediente madre

| Persona jurídica | Persona individual en relación de dependencia | Empresa individual |
|---|---|---|
| 1 Información financiera | 1 FEIC | 1 FEIC |
| 1.2 Declaraciones de impuestos | 1.1 Estado patrimonial | 1.1 Estado patrimonial |
| 2 FEIC (con su archivo JSON) | 2 DPI | 1.2 Declaraciones de impuestos |
| 3 Formulario Conoce a tu cliente | 3 Constancia de ingresos | 2 DPI |
| 5 Estados de cuenta | 4 Estados de cuenta | 3 Certificación de ingresos |
| 6 Carta de buró e Infornet - TransUnion (sociedad, representante y socios) | 5 Carta de buró e Infornet - TransUnion | 3.1 Información financiera (si aplica) |
| 7 DPI / pasaporte del R.L. | 6 RTU | 4 Estados de cuenta |
| 8 Patente de comercio | 7 Recibo de servicios | 5 Carta de buró e Infornet - TransUnion |
| 9 Patente de sociedad | 8 Formulario Conoce a tu cliente | 6 Patente de comercio |
| 10 Escritura; 10.1 Carta accionaria; 10.2 Anexo de beneficiarios | | 7 RTU |
| 11 Nombramiento | | 8 Recibo de servicios |
| 12 RTU de la empresa y R.L. | | 9 Formulario Conoce a tu cliente |
| 13 Recibo | | |

Clientes corporativos (multinacionales e ingenios): se omiten información financiera, declaraciones, estados de cuenta y buró; si cotizan en bolsa, también el FEIC.

### 3.2 Negocio

| Leasing Financiero | Agrega el Leasing Financiero Usado | Leasing Operativo |
|---|---|---|
| 1 Hoja de negociación | 7 Cotización vendor, avalúo, factura o memo de activo | 1 Hoja de negociación; 1.1 Solicitud de crédito |
| 2 Solicitud de crédito para firmar (firmada en clientes nuevos) | 8 Visto bueno del vehículo (no aplica con memo de venta) | 2 Checklist de seguro; 3 Mejora de seguro |
| 3 Checklist de seguro; 3.1 Licencia (si aplica) | Tarjeta de circulación o título | 4 Propuesta Arrend |
| 4 Mejora de seguro (si aplica) | Consulta de multas e impuesto de circulación (no aplica si el activo es de Arrend) | 5 Flujo firmado por asesor y gerente de operativo |
| 5 Cotización Arrend; 6 Flujo | | 6 Cotización vendor; 6.1 Visto bueno de combustible |
| 7 Cotización vendor | | |
| 8 y 9 Análisis individual (solo persona individual) | | |

Otros productos con orden propio: Arrendautos (prendario), crédito express, fiduciario, crédito puente, inmobiliario, leaseback y cambio de beneficio fiscal.

Nomenclatura que trae el FEIC: LFNLQ y LFNLD (leasing financiero en quetzales o dólares), LOPQ y LOPD (operativo), LBKQ y LBKD (leaseback), LFMBQ y LFMBD (inmobiliario), PNLQ y PNLD (prendario), FNLQ y FNLD (fiduciario). El código debe coincidir con el producto y la moneda del negocio.

---

## 4. Catálogo de datos: qué documento manda

| Dato | Documento que manda | Se cruza contra | Cómo se compara |
|---|---|---|---|
| Razón social | Patente de sociedad | FEIC, Conoce a tu cliente, solicitud, cotización, estados financieros, declaraciones, estados de cuenta, buró | Idéntica; "S.A." con puntos equivale a "Sociedad Anónima"; "SA" sin puntos se corrige |
| Nombre comercial | Patente de comercio | FEIC, Conoce a tu cliente, solicitud | Idéntico |
| NIT de la empresa, actividad económica, contador | RTU de la empresa (vigencia de 12 meses) | FEIC, solicitud, declaraciones, estados financieros | Mismos dígitos; actividad textual |
| Dirección | Recibo (emisión de 2 meses o menos) | FEIC, Conoce a tu cliente, solicitud, checklist de seguro | Idéntica, hasta los paréntesis |
| Representante: nombre, número, nacimiento, estado civil, nacionalidad | DPI vigente | FEIC, Conoce a tu cliente, nombramiento, solicitud, carta de buró | Nombre idéntico; estado civil según el DPI |
| NIT del representante | RTU del representante | FEIC | Mismos dígitos |
| Cargo, plazo y vencimiento de la representación; registro, folio y libro | Nombramiento | FEIC, Conoce a tu cliente, solicitud | Vencimiento = fecha inicial más el plazo |
| Número, fecha y notario de la escritura; fecha de inscripción | Escritura (primera hoja) | FEIC, solicitud | Mismos datos; mayúsculas no importan |
| Registro, folio y libro de la sociedad | Patente de sociedad | FEIC | Mismos dígitos |
| Accionistas y porcentajes | Última escritura si son personas; anexo 5 si son empresas | FEIC (solo 10 % o más), Conoce a tu cliente, solicitud | Mismos nombres; porcentaje = acciones de cada uno entre el total |
| Bien: tipo, marca, línea, año | Tarjeta de circulación (usado) o cotización vendor (nuevo) | Hoja, Conoce a tu cliente, solicitud, cotización, flujo, checklist de seguro | Idéntico; debe describir el bien completo |
| Renta inicial, plazo, TIR, opción de compra, gastos iniciales, moneda | Hoja de negociación | Conoce a tu cliente, solicitud, cotización, flujo | Mismo número; si la TIR difiere del flujo, se corrige la hoja |
| Precio | Cotización vendor | FEIC, Conoce a tu cliente, solicitud, cotización | Mismo monto |
| Vendor y ejecutivo vendor | Cotización vendor | Hoja, Conoce a tu cliente, solicitud, cotización | Idéntico |
| Asesor | Hoja de negociación | Todos los documentos del negocio y el Conoce a tu cliente | El mismo en todos; si otro hizo la visita, nota que lo explique |
| Número de cotización | Cotización Arrend | Flujo | Idéntico |

---

## 5. Orden de revisión

**Orden del checklist:** del 1 al 13 en el expediente madre y después el negocio.

**Orden real de los analistas:**
1. Preparan la carpeta: descargan de SharePoint, crean cliente, año y mes, renombran con el número de orden y unen archivos.
2. Abren y dejan a la vista los documentos fuente: patente de sociedad, DPI, RTU, escritura, nombramiento y recibo.
3. Revisan información financiera y declaraciones.
4. Revisan el FEIC contra los documentos fuente.
5. Revisan el Conoce a tu cliente con el FEIC ya validado y lo dejan abierto, porque el bien y las condiciones se validan con el negocio.
6. Revisan estados de cuenta, buró, y confirman los documentos fuente que ya usaron.
7. Si hay aval, repiten todo con el aval.
8. Revisan el negocio y dejan los cálculos al final.

**Orden recomendado para la herramienta:**

| Paso | Qué hace | Por qué |
|---|---|---|
| 0 | Lee el JSON del FEIC y verifica PEP y CPE | Si alguno es Sí, se detiene antes de leer nada más |
| 1 | Inventario contra el checklist del perfil | Todo lo faltante sale en la primera devolución |
| 2 | Lee los documentos fuente (patentes, escritura y modificaciones, anexo 5, nombramiento, DPI, RTU, recibo) | Son el ancla de todos los cruces |
| 3 | Cruza el FEIC contra los documentos fuente | Un FEIC limpio valida el resto más rápido |
| 4 | Cruza Conoce a tu cliente, solicitud y carta de buró contra las anclas | Son los formularios que Comercial llena a mano |
| 5 | Revisa buró, información financiera, declaraciones y estados de cuenta | Reglas de vigencia, periodos y firmas |
| 6 | Lee cotización vendor y hoja de negociación, y recalcula cotización y flujo | El negocio depende de un madre ya validado |
| 7 | Repite del 1 al 5 para el aval | El aval es un segundo cliente |
| 8 | En reingreso, compara contra la versión anterior | Detecta cambios no pedidos |

---

## 6. Estrategias, criterios en vivo, reglas y excepciones

### 6.1 Por momento

| Momento | Estrategia observada |
|---|---|
| Preparación | Cada analista lleva un formato propio de notas: fecha, hora, país, cliente, tipo, asesor y correcciones. Abre los PDF en el navegador porque el lector tarda |
| Durante la revisión | Deja abiertos los documentos fuente y cierra cada uno cuando ya no lo necesita; marca en cada documento lo ya validado para poder regresar |
| Uso de fuentes | Un formulario validado se vuelve fuente del siguiente; uno con errores no se usa como fuente hasta que se corrija |
| Aval con el mismo representante | Reutiliza lo ya validado (firma, contador) y avanza más rápido |
| Reingreso | Compara todo contra la versión anterior; si aparece un dato distinto, pide al asesor confirmar si es nuevo o un error |
| Duda de cálculo | Llama al encargado de revisión y, mientras espera, avanza con otras partes |
| Dato por confirmar | Lo marca aparte de las correcciones; solo se vuelve corrección si el asesor no lo respalda |

### 6.2 Por documento

- **Información financiera:** dos años cerrados al 31 de diciembre y el parcial con integraciones; todas las fechas del parcial deben ser la misma. Firma del representante y firma y sello del contador en balance y estado de resultados; en integraciones basta el contador. Auditados: la frase "hemos auditado" y el sello del auditor en el dictamen. CGE no analiza cifras.
- **Declaraciones:** IVA mensual o trimestral e ISR trimestral; hay un mes y 15 días de plazo tras el cierre del periodo.
- **FEIC:** vigencia de un año; teléfonos de 8 dígitos; correo bien escrito; si no hay modificaciones, esa sección va vacía.
- **Conoce a tu cliente:** mínimo 5 fotos más la selfie del asesor; uso particular para vehículos livianos y comercial para camiones y maquinaria; edad con tolerancia de un año por cumpleaños; nombres extranjeros se revisan letra por letra.
- **Estados de cuenta:** tres meses cerrados anteriores al ingreso; se verifica el número de cuenta, porque un banco puede tener varias.
- **Buró:** orden sociedad, representante y socios con 10 % o más; informes del mes en curso o el anterior; carta con lugar y fecha.
- **Escritura:** completa por numeración de hojas o por secuencia de cláusulas; si viene revuelta, se reconstruye por la continuidad del texto.
- **Hoja de negociación:** GPS obligatorio en vehículos; seguro "cotizador" si no hay mejora; las notas deben explicar todo cálculo fuera de lo normal.

### 6.3 Criterios que decide la persona de CGE, no la herramienta

1. Parecido de la firma con el DPI.
2. Identidad del asesor en la selfie.
3. Certificación del vendor cuando el grupo comercial tiene varias razones sociales o la cotización solo trae un logotipo.
4. Tachones o correcciones a mano en una escritura registrada.
5. Empresa que no aparece en Infornet.
6. Identificación del bien cuando la cotización viene en otro idioma o hay varias cotizaciones.
7. Lectura del motivo de un visto bueno.

---

## 7. Reglas, conflictos y precedentes

| Regla | Nivel |
|---|---|
| Falta un documento obligatorio | Crítico |
| DPI vencido el día del ingreso, aunque sea por un día | Crítico |
| Nombramiento vencido | Crítico |
| Mora de 61 días o más sin finiquito o constancia de pago | Crítico |
| Demanda ejecutiva o sumaria como demandado, sin desistimiento | Crítico |
| Conoce a tu cliente sin firma del supervisor | Crítico |
| Sociedad como accionista sin anexo 5 | Regular |
| Dato de un formulario distinto al documento que manda | Regular |
| Vehículo sin GPS y sin visto bueno del jefe de activos | Regular |
| Precio del avalúo distinto al de la cotización, sin visto bueno | Regular |
| Renta que cambia entre meses sin nota | Regular |
| Bien con accesorios o blindaje que no se describe completo | Regular |
| Firma, tachones, vendor, identidad del asesor | Revisión |

**Conflictos entre checklist y práctica:**
1. Firma del asesor en el Conoce a tu cliente: el checklist pide asesor y supervisor; hay revisores que aceptan una sola.
2. Fotos: un revisor exige 3 y otro 5.
3. Cliente de cartera: un año para la definición y más de dos para eximir declaraciones.
4. Aval sin Conoce a tu cliente: un revisor no supo si es excepción válida.

**Precedentes:**
- Demanda donde el cliente es el demandante: no se pide nada.
- Casos de Junta Directiva: no se ingresan a FIMS hasta la aprobación y vuelven a CGE para una última revisión; pueden pasar con una corrección menor pendiente, avisada por correo.
- Resoluciones del Comité: CGE no las revisa.

---

## 8. Cálculos

| Concepto | Fórmula |
|---|---|
| Valor sin IVA | Precio ÷ 1.12; si el vehículo es usado de 2024 o anterior, o híbrido, el precio ya es el valor sin IVA |
| Renta inicial con IVA | Valor sin IVA × % × 1.12 |
| Gastos iniciales con IVA | Valor sin IVA × % + 1,386.00 × 1.12 (cobro de dispositivo y GPS: Q1,552.32 con IVA) |
| Pago inicial | Renta inicial + gastos iniciales + traspaso inicial de Q1,835 en usados |
| Opción de compra | Valor sin IVA × % + traspaso de Q1,835 |
| Cuota mensual | (Renta + seguro + GPS de Q139) × 1.12 |
| Flujo | Todo sin IVA; renta inicial del flujo = renta inicial con IVA ÷ 1.12 |

- **Bien compuesto (vehículo más blindaje o accesorios):** cada parte tiene su cotización vendor y su flujo; el blindaje no lleva opción de compra; el consolidado suma ambos.
- **Green Fleet eléctrico:** IVA sobre la renta de 0 % antes de 2027, 2.4 % en 2027, 4.8 % en 2028, 7.2 % en 2029, 9.6 % en 2030, 10.8 % en 2031 y 12 % desde 2032.
- **Cotizador web con cobros de POS:** 1.25 % sobre renta, CRM, seguro y GPS cuando aplica; el CRM no se cobra en la opción de compra.
- **Crédito puente:** abono a capital más intereses más IVA; diferencias de 1 a 3 centavos se dejan pasar, desde un quetzal se corrigen.
- **Tolerancia general:** un centavo por redondeo; un centavo de diferencia entre monto solicitado y precio sí se corrige.

Ejemplo ficticio: valor sin IVA 100,000.00, renta inicial 10 %, gastos 1.7 %, opción de compra 1 %. Renta inicial: 11,200.00. Gastos iniciales: 1,700.00 + 1,552.32 = 3,252.32. Opción de compra: 1,000.00 + 1,835.00 = 2,835.00.

---

## 9. Errores

| Frecuencia | Error | Dónde | Cómo se detecta |
|---|---|---|---|
| Común | Plazo, TIR, renta inicial o gastos distintos a la hoja | Conoce a tu cliente | Cruce contra la hoja |
| Común | Número, fecha o año de la escritura equivocados | FEIC, solicitud | Cruce contra la escritura |
| Común | Razón social sin puntos o con otra puntuación | Cotización, solicitud | Comparación idéntica |
| Común | Nombres o apellidos incompletos o mal escritos | Formularios | Cruce contra el DPI |
| Común | Documentos faltantes | Expediente | Inventario |
| Común | Descripción del bien incompleta o genérica ("vehículo") | Documentos del negocio | Cruce contra la cotización vendor |
| Común | Asesor o vendor distinto entre documentos | Negocio | Cruce |
| Posible | Firma que no se parece a la del DPI | Estados financieros, carta de buró | Revisión humana |
| Posible | Contador distinto al del RTU | Estados financieros | Cruce |
| Posible | Meses de estados de cuenta o declaraciones incompletos | Madre | Conteo de periodos |
| Posible | Mora mayor a 60 días o demanda sin respaldo | Buró | Lectura del informe |
| Posible | Renta distinta en algún mes | Cotización | Comparación de cuotas |
| Raro | IVA mal calculado en la cotización de un vendor | Cotización vendor | Recalcular precio ÷ 1.12 |
| Raro | Notas de la hoja cortadas o ilegibles | Hoja | Lectura |
| Raro | Letras que se pierden en un formato nuevo | Composición accionaria | Lectura; se consulta, no se devuelve |
| Raro | Informes de buró en otro orden | Buró | Orden |
| Raro | Cotización en otro idioma o moneda sin tipo de cambio | Cotización vendor | Lectura |
| Raro | Cambio no pedido en un reingreso | Cualquier documento | Comparación contra la versión anterior |

Errores de los propios revisores vistos en las grabaciones: un desembolso que "no cuadraba" por no aplicar el IVA de la renta inicial del usado, y correcciones que una revisión anterior dejó pasar.

---

## 10. Relación con `digitador-arrend`

| Tema | CGE | Digitador de Riesgos | Qué hacer |
|---|---|---|---|
| Propósito | Valida forma, completitud y coincidencia | Vacía montos y evalúa la política de crédito | CGE entrega un expediente en el que Riesgos puede confiar |
| Fuente de las condiciones | Hoja de negociación | Cotización Arrend para los montos | No es contradicción: CGE garantiza que coincidan |
| FEIC | Cruce campo por campo | Lee el JSON como fuente ideal | Compartir el lector del JSON |
| Buró | Mora mayor a 60 días y demandas ejecutivas o sumarias | Referencias y vector de mora | Compartir la lectura del informe |
| Estados de cuenta | Periodos, titular y completitud | Saldos, meses duplicados, signo | El digitador ya detecta meses duplicados por página: CGE puede usarlo |
| Reglas comunes | Guardar cada lectura, casillas solo en imagen, detectar aval, usar la versión firmada | Las mismas | Un solo catálogo |

Pendientes para el proyecto de Riesgos: la exención del híbrido, el IVA escalonado del eléctrico y la regla del anexo 5 afectan los montos y los socios que el digitador vacía.

---

## 11. Qué automatizar y qué dejar a la persona

| Automatizar | Dejar a la persona de CGE |
|---|---|
| Inventario, vigencias y conteo de periodos | Firmas, tachones e identidad del asesor |
| Lectura del JSON del FEIC y cruces contra anclas | Certificación del vendor e identificación de bienes complejos |
| Recalcular cotización y flujo | Motivos de vistos buenos y casos de Junta Directiva |
| Historia accionaria con página de respaldo | Confirmar la estructura vigente y los beneficiarios finales |
| Lista de correcciones en el formato del ticket | Decidir qué se devuelve y qué se consulta al asesor |
| Comparación de reingresos | Excepciones y consultas a Legal o Riesgos |

---

## 12. Dudas abiertas para CGE

1. ¿El aval debe traer Conoce a tu cliente?
2. ¿Cuántas fotos son el mínimo: 3 o 5?
3. ¿Basta una firma en el Conoce a tu cliente o se exigen las dos?
4. ¿Cuál es el plazo de cliente de cartera para eximir declaraciones?
5. ¿Desde qué año de modelo el precio del vehículo ya trae IVA, y cómo se confirma que un híbrido está exento?
6. ¿Los montos fijos (1,386, 139 y 1,835) tienen fecha de revisión?
7. ¿Qué formato de notas del revisor se adopta como único?
