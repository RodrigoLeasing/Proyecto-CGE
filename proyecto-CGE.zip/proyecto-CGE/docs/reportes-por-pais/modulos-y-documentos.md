# Módulos de revisión de CGE: documentos necesarios e innecesarios

**Fecha:** 19 de noviembre de 2026
**Para qué sirve:** agrupar los documentos del expediente en módulos, como hace Riesgos en su análisis, para saber en cada módulo qué documento se necesita, cuál depende del caso y cuál no hace falta.

**Cómo leerlo:**
- **Necesario:** sin él, el módulo no se puede revisar y el caso se devuelve.
- **Según el caso:** solo se pide si se cumple la condición indicada.
- **No necesario:** no se pide. Si llega, se guarda como respaldo y no genera correcciones, salvo que contradiga a un documento necesario.

Base: Guatemala, persona jurídica. Las diferencias de los demás países van al final de cada módulo.

---

## Módulo 1. Objeto de financiamiento

Qué responde: qué se financia, a quién se le compra y en qué condiciones.

| Necesario | Según el caso | No necesario |
|---|---|---|
| Hoja de negociación | Mejora de seguro, con el correo de Seguros: si el seguro es mejorado | Capacidad de pago, ponderación y saldos promedio (El Salvador): ya no se usan |
| Solicitud de crédito (firmada en clientes nuevos) | Licencia de conducir: si aplica | Propuesta Arrend en Leasing Financiero de Costa Rica: ya no se exige |
| Checklist de seguro | Avalúo, tarjeta de circulación o título, consulta de multas e impuesto de circulación: en usados | Flujo de efectivo u otros anexos del vendor |
| Cotización Arrend | Visto bueno o memo: usados, vehículo sin GPS, precio distinto al avalúo, excepción | Imágenes o catálogos del bien |
| Flujo | Anexo del bien compuesto, firmado: varios artículos, blindaje o accesorios | Correos sin archivo adjunto |
| Cotización vendor o proforma (una por cada parte del bien) | Tipo de cambio: cotización en otra moneda | |
| | Análisis individual: solo persona individual | |
| | Nota de seguro endosado: si no hay seguro con Arrend | |

Otros países: Panamá agrega el formulario de debida diligencia; Costa Rica agrega datos generales en persona jurídica; República Dominicana usa una propuesta en lugar de la cotización Arrend; el Leasing Operativo usa propuesta Arrend en todos los países.

---

## Módulo 2. Perfil del cliente

Qué responde: quién es el cliente, dónde opera y a qué se dedica.

| Necesario | Según el caso | No necesario |
|---|---|---|
| FEIC, con su archivo JSON | Segundo recibo: si la planta está en otra dirección | Registro de la actividad u otras constancias |
| Formulario Conoce a tu cliente, con fotos, selfie del asesor y firmas | Nota de quién hizo la visita: si no fue el asesor | Folletos, perfiles comerciales o presentaciones de la empresa |
| Patente de comercio | Visto bueno de Riesgos por visita pendiente: República Dominicana | Sellos o comprobantes de pago de trámites |
| Patente de sociedad | | |
| RTU de la empresa | | |
| Recibo de servicios (2 meses o menos) | | |

Otros países: no hay FEIC fuera de Guatemala. El Salvador usa matrícula, NIT y tarjeta de IVA; Honduras, permiso de operaciones y RTN; Panamá, aviso de operaciones (sin recibo); Costa Rica, patente o permiso sanitario y personería jurídica (sin recibo) más la autorización SUGEF; República Dominicana, registro mercantil y RNC.

---

## Módulo 3. Representación y estructura accionaria

Qué responde: quién firma por la empresa, hasta cuándo y quiénes son los dueños finales.

| Necesario | Según el caso | No necesario |
|---|---|---|
| DPI o pasaporte del representante, vigente | Modificaciones de la escritura: si las hubo | DPI o cédulas de los socios |
| Nombramiento vigente | Carta accionaria: si cambiaron los accionistas | Actas que no cambian socios ni representante |
| RTU del representante | Anexo 5 de beneficiarios finales: si algún accionista es una empresa | Poderes de personas que no firman este negocio |
| Escritura de constitución, completa | | |

Otros países: El Salvador usa credencial y, para los socios, el formulario F-915 o la carta accionaria; Honduras trae el nombramiento dentro de la escritura; Panamá usa pacto social de constitución y personería jurídica o poder; Costa Rica usa personería jurídica y declaración jurada de socios; República Dominicana usa el registro mercantil, estatutos, asambleas y contratos de compraventa de cuotas.

---

## Módulo 4. Información financiera

Qué responde: si la empresa presentó sus cifras completas, firmadas y de los periodos correctos. CGE no analiza las cifras; eso lo hace Riesgos.

| Necesario | Según el caso | No necesario |
|---|---|---|
| Balance general y estado de resultados de dos años cerrados | Dictamen del auditor: si son auditados | Integraciones de los años cerrados |
| Parcial del año en curso, con integraciones | Declaraciones: se eximen en clientes de cartera según el plazo que confirme CGE | Flujo de efectivo y estados adicionales |
| Declaraciones de impuestos: tres meses de IVA e ISR trimestral | Años anteriores a la existencia de la empresa: no se piden | Información financiera del representante o de los socios |
| | | Más meses de declaraciones de los pedidos |

Otros países: Honduras, Panamá y Costa Rica presentan declaración anual; El Salvador, tres mensuales; República Dominicana puede no exigirlas si Riesgos lo autoriza. Clientes corporativos: no se pide este módulo.

---

## Módulo 5. Burós

Qué responde: si el cliente, su representante y sus socios tienen moras o demandas que respaldar.

| Necesario | Según el caso | No necesario |
|---|---|---|
| Carta de buró firmada, con lugar y fecha | Finiquito o constancia de pago: mora mayor a 60 días | Informes de socios con menos de 10 % |
| Infornet y TransUnion de la sociedad | Desistimiento: demanda ejecutiva o sumaria como demandado | Cartas de buró adicionales de los socios |
| Infornet y TransUnion del representante | Buró de otro país: socio o representante de un país donde Arrend opera | Burós de personas de países donde Arrend no opera |
| Infornet y TransUnion de cada socio con 10 % o más | Visto bueno de la Gerencia de Riesgos: si no hay respaldo | Respaldo por demandas donde el cliente es el demandante |
| | | Moras de telecomunicaciones o servicios (Costa Rica, República Dominicana) |

Otros países: El Salvador usa Infored y Equifax; Honduras no pide carta de buró; Panamá usa APC; Costa Rica, Credid; República Dominicana, solo TransUnion.

---

## Módulo 6. Estados de cuenta

Qué responde: si están los tres meses cerrados más recientes, del titular correcto y completos.

| Necesario | Según el caso | No necesario |
|---|---|---|
| Estados de cuenta de los últimos tres meses cerrados | Firma y sello del banco: si se emiten en agencia | Meses anteriores a los tres pedidos |
| | Series separadas por cuenta: si hay varias cuentas | Estados de cuenta del representante o de los socios |

Clientes corporativos: no se pide este módulo.

---

## Módulo 7. Aval o beneficiario fiscal

Qué responde: quién más responde por el negocio o a nombre de quién se factura.

| Figura | Necesario | No necesario |
|---|---|---|
| Aval | Los módulos 2 a 6 completos del aval y su solicitud de crédito de aval | Nada se omite; por confirmar si debe traer Conoce a tu cliente |
| Beneficiario fiscal | Módulos 2, 3 y 5, y el memo o solicitud de cambio si aplica | Información financiera, declaraciones, estados de cuenta y Conoce a tu cliente |

El beneficiario fiscal debe ser del mismo país; el aval puede ser de otro.

---

## Relación con los módulos de Riesgos

| Módulo de CGE | Módulo equivalente en el análisis de Riesgos |
|---|---|
| 1. Objeto de financiamiento | 1. Objeto financiamiento |
| 2. Perfil del cliente y 3. Representación y estructura accionaria | 2. Perfil del cliente |
| 4. Información financiera | 5. Estados Financieros |
| 5. Burós | 6. Burós |
| 6. Estados de cuenta | 7. Capacidad de pago |
| 7. Aval o beneficiario fiscal | Se analiza dentro del perfil y la capacidad de pago |

Los documentos son los mismos; cambia la pregunta. CGE pregunta si el documento está, es legible, está vigente y coincide con los demás. Riesgos pregunta qué dicen sus cifras.
