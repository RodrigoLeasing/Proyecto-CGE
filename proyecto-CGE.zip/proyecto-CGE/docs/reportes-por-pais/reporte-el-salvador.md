# El Salvador: reporte técnico y de aprendizaje

**Fecha:** 19 de noviembre de 2026
**Uso:** base de conocimiento del modelo pre clasificador de expedientes de CGE.
**Privacidad:** sin datos de clientes ni de personas; ejemplos numéricos ficticios.

---

## 1. Resumen

1. **El impuesto a la primera matrícula (IPM) y las placas se separan del bien.** Se restan del precio final antes de calcular y se financian en un flujo aparte.
2. **Existe un gasto inicial mínimo de 250 dólares.** Cuando aplica, la hoja debe decir el porcentaje equivalente.
3. **Los socios se validan con el formulario F-915** o con la carta accionaria; la escritura es el último recurso.
4. **La credencial es el nombramiento.** Si no indica plazo, la representación es indefinida; la fecha que vale es la del registro de comercio.
5. **Todo va en mayúsculas** y con la puntuación exacta de "S.A. de C.V.".

---

## 2. Fuentes

| Fuente | Qué aportó |
|---|---|
| Revisión 6: persona jurídica nueva, Leasing Financiero de un vehículo | Orden, tiempos por documento, IPM, fórmulas, cierre del ticket |
| Revisión 10 (entrenamiento): persona jurídica nueva con dos empresas socias y representante extranjero | F-915, anexo 5 con beneficiarios extranjeros, gasto mínimo, credencial sin plazo |
| Excel de orden de documentación y checklist RI-SV-FO-01A a 01K | Documentos por tipo de cliente y producto |

---

## 3. Documentos del expediente

| Persona jurídica | Persona individual | Empresa individual |
|---|---|---|
| 1 Información financiera | 2 DUI | 1.2 Declaraciones de impuestos |
| 1.2 Declaraciones de impuestos | 3 Constancia de ingresos | 2 DUI |
| 3 Formulario Conoce a tu cliente | 4 Estados de cuenta | 3 Certificación de ingresos |
| 5 Estados de cuenta | 5 Carta de buró e Infored - Equifax | 4 Estados de cuenta |
| 6 Carta de buró e Infored - Equifax (sociedad, representante y socios) | 6 NIT u homologación | 5 Carta de buró e Infored - Equifax |
| 7 DUI / pasaporte del R.L. | 7 Recibo de servicios | 6 Matrícula |
| 8 Matrícula | 8 Formulario Conoce a tu cliente | 7 NIT y tarjeta de IVA u homologación |
| 9 Escritura; 9.1 Carta accionaria; 9.2 Anexo de beneficiarios | | 8 Recibo de servicios |
| 10 Credencial | | 9 Formulario Conoce a tu cliente |
| 11 NIT y tarjeta de IVA de la empresa y NIT del R.L. | | |
| 12 Recibo | | |

**Negocio de Leasing Financiero:** 1 hoja de negociación; 2 solicitud de crédito para firmar; 3 checklist de seguro; 3.1 licencia; 4 cotizador o mejora de seguro; 5 cotización Arrend; 6 flujo; 7 cotización vendor. El checklist lista además capacidad de pago, ponderación y saldos promedio, que ya no se usan: si no vienen, no se piden.

---

## 4. Catálogo de datos: qué documento manda

| Dato | Documento que manda | Se cruza contra |
|---|---|---|
| Razón social | Matrícula del año vigente | Todos los formularios, estados financieros, declaraciones |
| NIT de la empresa, número de registro de contribuyente y actividad | NIT y tarjeta de IVA (no vencen) | Solicitud, carta de buró, declaraciones, checklist de seguro |
| Dirección de oficina, planta, bien y fiscal | Recibo (2 meses o menos) | Conoce a tu cliente, solicitud, checklist de seguro |
| Representante | DUI o pasaporte vigente | Conoce a tu cliente, solicitud, carta de buró |
| NIT del representante | Es el número del DUI (homologado) o su NIT | Solicitud, carta de buró |
| Cargo, administradores y vigencia; inscripción y libro; notario | Credencial con el sello del registro de comercio | Conoce a tu cliente, solicitud |
| Socios y porcentajes | F-915 o carta accionaria; si no hay, capital social de la escritura | Conoce a tu cliente, solicitud (solo 10 % o más) |
| Beneficiarios finales | Anexo 5 firmado por el representante | Buró de quienes sean de países donde Arrend opera |
| Capital, número y fecha de constitución y modificaciones, notarios | Escrituras | Solicitud |
| Vendor | Sello de la cotización vendor (quien factura) | Hoja, solicitud, cotización |
| Bien, precio final, IPM y placas | Cotización vendor | Hoja, solicitud, cotización, flujo |
| Condiciones y notas | Hoja de negociación | Conoce a tu cliente, cotización, flujo |
| Teléfonos y correos | Conoce a tu cliente | Hoja, solicitud, checklist de seguro, cotización |

---

## 5. Orden de revisión

**Orden real:** el del checklist, del 1 al 12, y después el negocio. Los revisores llevan una lista de correcciones mientras avanzan y marcan en otro color lo que deben confirmar con el asesor.

**Orden recomendado para la herramienta:**
1. Inventario.
2. Anclas: matrícula, NIT y tarjeta de IVA, recibo, DUI o pasaporte, credencial.
3. Socios: F-915 o carta accionaria, escrituras en orden cronológico y anexo 5 si hay empresas socias.
4. Conoce a tu cliente contra las anclas.
5. Buró completo, información financiera, declaraciones y estados de cuenta.
6. Cotización vendor: separar precio, IPM y placas.
7. Hoja con sus notas, cotización, flujos y consolidado.
8. Solicitud de crédito y checklist de seguro.
9. Comparación contra la versión anterior en reingresos.

**Tiempos observados:** preparar la carpeta, 10 minutos; información financiera, 10; declaraciones, 3; Conoce a tu cliente, 8; estados de cuenta, de 5 a 8; caso completo, de 1.5 a 2 horas.

---

## 6. Estrategias, criterios en vivo, reglas y excepciones

- **Firma:** pasa con un parecido cercano al 50 % frente al DUI; si no se parece, se devuelve.
- **Representante distinto entre periodos de los estados financieros:** puede ser el anterior; se resuelve con la credencial.
- **Auditados:** solo nombre, periodo y sello del auditor; notas completas y numeradas.
- **Buró incompleto:** si dice "página 6 de 7", se pide completo.
- **Apellido distinto en el buró:** se identifica a la persona por el número de DUI, no por el nombre.
- **Equifax sin información:** se acepta.
- **Socios extranjeros de países sin operación:** no se piden sus burós; sí se piden los de Guatemala u otro país con operación.
- **Demanda como demandante:** no se pide nada.
- **Escritura sin numeración:** se verifica la continuidad del texto entre hojas.
- **Reingreso:** la analista compara contra la versión anterior.
- **Cierre:** las correcciones van al ticket con el formato "DOCUMENTO, ÍTEM: corregir…" y el ticket pasa a Devolución; al regresar bien, pasa a Recepción FIMS.

**Criterios que decide la persona de CGE:** parecido de firmas, a quién pertenece cada informe de buró cuando no hay documento de los socios, cómo maneja el IPM y las placas cada vendor, y cuál es el vendor cuando no hay sello.

---

## 7. Reglas, conflictos y precedentes

| Regla | Nivel |
|---|---|
| Falta un periodo de información financiera | Crítico |
| Falta el buró de un socio con 10 % o más | Crítico |
| Mora mayor a 60 días o demanda como demandado, sin respaldo | Crítico |
| Matrícula que no es del año vigente | Regular |
| Hoja con gastos iniciales en monto, sin porcentaje | Regular |
| Vencimiento de representación que la credencial no respalda | Regular |
| Nombre con un espacio o una letra de más | Regular |
| Año o número de escritura equivocado | Regular |
| Mezcla de mayúsculas y minúsculas | Regular |
| Edad que no corresponde a la fecha de nacimiento | Regular |
| Renta distinta en algún mes | Regular |

**Precedente:** una instrucción de 2025 listaba qué vendor desglosa IPM y placas; varios cambiaron, así que se confirma con el asesor y con las notas de la hoja.

---

## 8. Cálculos

| Concepto | Fórmula |
|---|---|
| Valor con IVA | Precio final − IPM − placas |
| Valor sin IVA | Valor con IVA ÷ 1.13 |
| Renta inicial con IVA | Valor con IVA × % |
| Gastos iniciales con IVA | (Valor sin IVA × % ÷ 1.13 + 180) × 1.13; el 180 es dispositivo (145) más instalación (35). Mínimo: (250 + 180) × 1.13 = 485.90 |
| Pago inicial | Renta inicial + gastos iniciales |
| Opción de compra | Valor sin IVA × % + traspaso de 113 dólares por negocio |
| Cuota mensual | (Renta + seguro + GPS de 18 dólares + cuota de IPM y placas) × 1.13 |
| Flujos | Bien, IPM y placas (solo monto, sin TIR, renta inicial ni opción de compra) y consolidado |

En la cotización, el valor del bien sin IVA incluye IPM y placas; por eso el total entre ese valor no da 1.13.

Ejemplo ficticio: precio final 22,600.00, IPM y placas 600.00, renta inicial 20 %. Valor con IVA: 22,000.00. Valor sin IVA: 19,469.03. Renta inicial: 4,400.00.

---

## 9. Errores

| Frecuencia | Error | Cómo se detecta |
|---|---|---|
| Común | Gastos iniciales del Conoce a tu cliente o de la hoja que no corresponden | Recalcular |
| Común | Falta el parcial o un periodo de información financiera | Conteo de periodos |
| Común | Nombres, años o lugares mal escritos en la solicitud | Cruce contra credencial, escritura y pasaporte |
| Común | Declaraciones que no vienen | Inventario |
| Posible | Buró incompleto o de menos socios | Conteo de informes y páginas |
| Posible | NIT del representante equivocado | Cruce contra el DUI |
| Posible | Vencimiento de representación inventado | Lectura de la credencial |
| Posible | IPM o placas sumados dentro del valor del bien | Recalcular |
| Raro | Informe de buró con el apellido de soltera | Número de DUI |
| Raro | Renta distinta en un mes | Comparación de cuotas |

---

## 10. Relación con `digitador-arrend`

- Coinciden en NIT, DUI, Infored y Equifax, dólares con tipo de cambio 1 e IVA de 13 %.
- El digitador documenta notas de estados financieros de capital variable; CGE no analiza cifras.
- Pendiente para Riesgos: el IPM y las placas quedan fuera del valor del bien, y el gasto inicial mínimo altera el porcentaje efectivo.

---

## 11. Qué automatizar y qué dejar a la persona

| Automatizar | Dejar a la persona |
|---|---|
| Inventario y conteo de periodos e informes | Parecido de firmas |
| Separar precio, IPM y placas y recalcular | Cómo maneja el IPM cada vendor |
| Cruces de la solicitud contra credencial, escritura y pasaporte | Confirmaciones con el asesor |
| Socios desde F-915 y anexo 5 | A quién pertenece un informe sin identificación |
| Verificar mayúsculas y rentas iguales | Vendor sin sello |

---

## 12. Dudas abiertas para CGE

1. ¿Cuál es la lista vigente de vendors y cómo maneja cada uno el IPM y las placas?
2. ¿Desde qué monto aplica el gasto inicial mínimo de 250 dólares?
3. ¿El traspaso de 113 dólares es por negocio o por bien?
4. ¿Se retira del checklist lo que ya no se usa (capacidad de pago, ponderación, saldos promedio)?
5. ¿El F-915 es obligatorio o un respaldo?
