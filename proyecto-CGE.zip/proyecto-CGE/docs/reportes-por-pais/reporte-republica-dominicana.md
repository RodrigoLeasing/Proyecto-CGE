# República Dominicana: reporte técnico y de aprendizaje

**Fecha:** 19 de noviembre de 2026
**Uso:** base de conocimiento del modelo pre clasificador de expedientes de CGE.
**Privacidad:** sin datos de clientes ni de personas; ejemplos numéricos ficticios.

---

## 1. Resumen

1. **Es el país más nuevo y sus reglas todavía se están asentando.** Varios criterios se acordaron con Legal y con abogados del país; pueden cambiar.
2. **El registro mercantil concentra casi todo:** denominación, RNC, fecha de constitución, representante, socios y dirección.
3. **La representación se toma como indefinida,** aunque el registro indique un plazo.
4. **El Conoce a tu cliente siempre ingresa sin visita,** con visto bueno de Riesgos; la visita se hace después de la aprobación.
5. **CGE no es tan exigente aquí como en otros países:** cuando Comercial mezcla fuentes o un documento de un tercero viene incompleto, se deja a Riesgos y a Legal.

---

## 2. Fuentes

| Fuente | Qué aportó |
|---|---|
| Revisión 3: sociedad de responsabilidad limitada, Leasing Financiero en dólares de un equipo compuesto por seis artículos | Requisitos, criterios legales, buró, bien compuesto, propuesta y flujos |
| Excel de orden de documentación y checklist del país | Documentos de persona jurídica y de negocio |

Un solo caso grabado. La matriz de orden no trae columnas de persona individual ni de empresa individual para este país.

---

## 3. Documentos del expediente

| Expediente madre (persona jurídica) | Negocio de Leasing Financiero |
|---|---|
| 1 Información financiera | 1 Hoja de negociación |
| 1.2 Declaraciones de impuestos (DGII) | 2 Solicitud de crédito para firmar o firmada |
| 3 Formulario Conoce a tu cliente | 3 Checklist de seguro; 3.1 licencia (si aplica) |
| 5 Estados de cuenta | 4 Mejora de seguro (si aplica), con el correo de Seguros |
| 6 Carta de buró y TransUnion (sociedad, representante y socios) | 5 Propuesta, en lugar de la cotización Arrend |
| 7 Cédula de identidad / pasaporte del R.L. | 6 Flujo |
| 8 Registro mercantil | 7 Cotización vendor o proforma, una por artículo si el bien es compuesto |
| 9 Estatutos sociales | Anexo del bien compuesto |
| Carta accionaria y anexo de beneficiarios (si aplican) | |
| Asamblea general y contratos de compraventa de cuotas (si aplican) | |
| RNC | |
| Recibo | |

Solo se ofrecen Leasing Financiero y Leasing Operativo, siempre en dólares.

---

## 4. Catálogo de datos: qué documento manda

| Dato | Documento que manda | Se cruza contra |
|---|---|---|
| Denominación social, RNC, fecha de asamblea constitutiva, objeto social | Registro mercantil vigente, de la Cámara de Comercio | Todos los formularios, estados financieros, carta de buró, TransUnion |
| Nombre comercial | Denominación sin la sigla societaria | Solicitud |
| Dirección | Recibo, si la trae; si no, registro mercantil | Conoce a tu cliente, solicitud, checklist de seguro |
| Representante y persona autorizada a firmar | Órganos de gestión del registro mercantil y cédula | Conoce a tu cliente, solicitud, propuesta |
| Vencimiento de la representación | "No aplica" o "Indefinido" | Conoce a tu cliente, solicitud |
| RNC del representante | Su número de cédula (homologado) | Solicitud |
| Socios y porcentajes | Registro mercantil y última asamblea o contrato de compraventa de cuotas | Conoce a tu cliente, solicitud |
| Beneficiarios finales | Anexo 5 o documento equivalente del cliente | Conoce a tu cliente |
| Bien compuesto, artículo por artículo | Cotizaciones vendor | Anexo, hoja, solicitud, propuesta, flujo |
| Monto a financiar | Suma del anexo | Solicitud, propuesta, flujo |
| Condiciones y TIR completa | Hoja de negociación; la TIR la fija el flujo | Conoce a tu cliente, propuesta, flujo |

---

## 5. Orden de revisión

**Orden real:** el del checklist. Para el negocio, la revisora conserva Conoce a tu cliente, cédula y registro mercantil.

**Orden recomendado para la herramienta:**
1. Inventario y verificación del visto bueno de Riesgos por la visita pendiente.
2. Registro mercantil como ancla principal, con cédula y recibo.
3. Estatutos, asambleas y contratos de compraventa en orden cronológico, para la historia de socios.
4. Conoce a tu cliente contra las anclas.
5. Carta de buró y TransUnion; información financiera; estados de cuenta.
6. Cotizaciones vendor contra el anexo, artículo por artículo, y la suma.
7. Hoja, propuesta, flujos y consolidado.
8. Solicitud y checklist de seguro.

**Tiempo:** alrededor de 1 hora para una revisora con experiencia en un caso pequeño; entre 1.5 y 2 horas para una persona nueva.

---

## 6. Estrategias, criterios en vivo, reglas y excepciones

- **Información financiera:** casi siempre auditada; la identifican el comentario del auditor y su sello o firma en la primera página. Dos años cerrados y el interino, sin mes fijo pero al menos hasta junio; la fecha del encabezado debe ser la misma en todos los estados del periodo. Notas y anexos valen como integraciones.
- **Declaraciones:** Riesgos autorizó no exigirlas en ciertos casos con interinos avanzados.
- **Estatutos:** no tienen que ser los de constitución, pero se leen completos, porque pueden decir que el representante ya no lo es.
- **Estados de cuenta:** los bancos cortan a mitad de mes; el mes vale si cubre 30 o 31 días, contados desde el mes de ingreso.
- **Buró:** solo TransUnion, del mes en curso o el anterior; solo moras de entidades financieras; con un 4 o 5 en el historial se pide finiquito o boleta de pago. Telecomunicaciones no cuentan; almacenes, según el caso.
- **Representante extranjero:** no se puede consultar su buró; se pide el del socio mayoritario.
- **Cédula:** las emitidas en 2023 y 2024 con problema de renovación se aceptan vencidas, por comunicado oficial.
- **Carta de buró llenada a mano:** no se exige letra perfecta si los números coinciden.
- **Seguro:** endosado, cotizador (fijo o nivelado) o mejorado; el mejorado exige el correo de Seguros.
- **GPS:** en equipos no se pide; en vehículos, su exclusión exige memo firmado.
- **Beneficiario fiscal:** solo si es del mismo país; un aval puede ser de otro.
- **Teléfonos y correos distintos entre documentos:** se registran todos en FIMS.
- **Errores de terceros:** un recibo sin dirección o un estado de cuenta con corte irregular no se le atribuyen a Comercial.

**Criterios que decide la persona de CGE o Legal:** registros mercantiles emitidos por un abogado, mezcla de fuentes en los socios, parecido de firmas (entre 50 % y 90 %) y todo dato legal que el equipo no haya visto antes, que queda como precedente.

---

## 7. Reglas, conflictos y precedentes

| Regla | Nivel |
|---|---|
| Registro mercantil vencido, incompleto o de otra entidad | Crítico |
| TransUnion con más de un mes de antigüedad | Crítico |
| Mora mayor a 60 días en entidad financiera, sin respaldo | Crítico |
| Conoce a tu cliente sin visita y sin visto bueno de Riesgos | Crítico |
| Seguro mejorado sin el correo de Seguros | Regular |
| Vehículo sin GPS y sin memo | Regular |
| Fecha de asamblea constitutiva equivocada | Regular |
| Tipo de financiamiento equivocado en la propuesta | Regular |
| Anexo que no coincide con las cotizaciones o cuya suma no da el monto | Regular |
| TIR de la hoja distinta a la del flujo | Regular (se corrige la hoja) |
| Moneda de una cotización distinta, sin tipo de cambio | Regular |

**Precedentes de Legal:** representación indefinida; estatutos posteriores a la constitución; registro mercantil emitido por abogado en ciertas zonas; cédulas de 2023 y 2024 vencidas.

Clientes corporativos (ALD y AMS): checklist regional sin información financiera, estados de cuenta, declaraciones ni beneficiarios finales.

---

## 8. Cálculos

| Concepto | Fórmula |
|---|---|
| Valor sin ITBIS | Precio ÷ 1.18 |
| Renta inicial con ITBIS | Precio con ITBIS × % |
| Desembolso | Precio con ITBIS − renta inicial |
| Opción de compra | Valor sin ITBIS × % |
| Gastos iniciales financiados | Valor sin ITBIS × %; flujo aparte, sin renta inicial ni opción de compra, sin quitar impuesto |
| Renta consolidada | Cuota del bien + cuota de gastos |
| Seguro | No se financia; cuota aparte tomada del correo de Seguros |
| Valor residual | (Opción de compra + seguro) × 1.18, cuando no hay GPS |

Ejemplo ficticio: precio con ITBIS 11,800.00, renta inicial 30 %, gastos 2 %, opción de compra 5 %. Valor sin ITBIS: 10,000.00. Renta inicial: 3,540.00. Gastos financiados: 200.00. Opción de compra: 500.00.

---

## 9. Errores

| Frecuencia | Error | Cómo se detecta |
|---|---|---|
| Común | Fechas o plazos equivocados en los documentos del negocio | Cruce contra hoja y registro mercantil |
| Común | Socios tomados de fuentes distintas | Historia de socios |
| Posible | Fecha de asamblea constitutiva equivocada en la solicitud | Cruce contra el registro mercantil |
| Posible | Renta total de la propuesta que no coincide con la suma | Recalcular |
| Posible | Anexo sin unidades o precios unitarios | Lectura |
| Posible | Seguro mejorado sin correo | Inventario |
| Raro | Registro mercantil emitido por un abogado | Lectura; consulta a Legal |
| Raro | Representante extranjero sin buró posible | Nacionalidad |
| Raro | Cédula vencida aceptable | Año de emisión |

---

## 10. Relación con `digitador-arrend`

- Coinciden en RNC, cédula, TransUnion como único buró (la fila de Infornet se omite) e impuesto de 18 %.
- El digitador necesita el tipo de cambio cuando los ingresos están en pesos y el crédito en dólares; CGE solo exige tipo de cambio si una cotización viene en otra moneda.
- Pendiente para Riesgos: los gastos financiados y el seguro fuera del financiamiento cambian la renta que se vacía.

---

## 11. Qué automatizar y qué dejar a la persona

| Automatizar | Dejar a la persona |
|---|---|
| Cruces contra el registro mercantil | Criterios legales nuevos |
| Historia de socios con asambleas y compraventas | Mezcla de fuentes en los socios |
| Cruce del anexo artículo por artículo y su suma | Parecido de firmas |
| Vigencia de TransUnion y lectura del historial | Tipo de entidad en moras no financieras |
| Recalcular flujos y valor residual | Excepciones de cédulas y registros |

---

## 12. Dudas abiertas para CGE

1. ¿Qué cobro explica la diferencia de alrededor de 1.00 en la renta total del caso?
2. ¿Se cobra cuota de endoso cuando el seguro es endosado?
3. ¿Cuál es el cobro de dispositivo y GPS en vehículos?
4. ¿Hay checklist de persona individual para el país?
5. ¿Los precedentes de Legal están escritos en algún documento?
