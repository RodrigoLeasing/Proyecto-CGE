# Panamá: reporte técnico y de aprendizaje

**Fecha:** 19 de noviembre de 2026
**Uso:** base de conocimiento del modelo pre clasificador de expedientes de CGE.
**Privacidad:** sin datos de clientes ni de personas; ejemplos numéricos ficticios.

---

## 1. Resumen

1. **El aviso de operaciones es el documento central.** Da el RUC con su dígito verificador, la actividad y la dirección; no se pide recibo.
2. **El pacto social debe ser el de constitución** y de él salen todas las fechas de constitución.
3. **Se trabaja sobre el total con ITBMS incluido.** La opción de compra se calcula sobre ese total, a diferencia de otros países.
4. **El negocio agrega el formulario de debida diligencia,** uno por negocio.
5. **Fuente con reservas:** la revisora ya trabaja en otra área y no pudo cuadrar los gastos iniciales ni explicar el "bono cliente". Los cálculos de este reporte deben validarse antes de volverse reglas.

---

## 2. Fuentes

| Fuente | Qué aportó |
|---|---|
| Revisión 4: sociedad de una sola accionista, Leasing Financiero en dólares | Requisitos, equivalencias, debida diligencia, cálculos con ITBMS |
| Excel de orden de documentación y checklist RI-PA-FO-01A a 01K | Documentos por tipo de cliente y producto |

Un solo caso grabado: las frecuencias de error son provisionales.

---

## 3. Documentos del expediente

| Persona jurídica | Persona individual | Empresa individual |
|---|---|---|
| 1 Información financiera o declaraciones (según aplique) | 2 Cédula | 1.2 Declaraciones de impuestos |
| 1.2 Declaraciones de impuestos (según aplique) | 3 Constancia de ingresos | 2 Cédula |
| 3 Formulario Conoce a tu cliente | 4 Estados de cuenta | 3 Certificación de ingresos |
| 5 Estados de cuenta | 5 Carta de buró y APC | 4 Estados de cuenta |
| 6 Carta de buró y APC (sociedad, representante y socios) | 6 RUC | 5 Carta de buró y APC |
| 7 Cédula / pasaporte del R.L. | 8 Formulario Conoce a tu cliente | 6 Aviso de operaciones - RUC |
| 8 Aviso de operaciones o certificado de RUC | | 9 Formulario Conoce a tu cliente |
| 9 Pacto social; carta accionaria y anexo 5 si aplican | | |
| Certificación de personería jurídica o poder general | | |

**Negocio de Leasing Financiero:** 1 hoja de negociación; 2 solicitud de crédito para firmar o firmada; 2.1 formulario de debida diligencia; 3 checklist de seguro; 3.1 licencia; 4 mejora de seguro; 5 cotización Arrend; 6 flujo; 7 cotización vendor o proforma. Con cotizador manual se suma la propuesta Arrend.

Productos que el checklist de Panamá tiene ocultos: prendario, inmobiliario, usados, crédito puente y crédito express.

---

## 4. Catálogo de datos: qué documento manda

| Dato | Documento que manda | Se cruza contra |
|---|---|---|
| Razón social, RUC con dígito verificador, actividad | Aviso de operaciones | Conoce a tu cliente, solicitud, debida diligencia, declaraciones, carta de buró |
| Número de aviso de operaciones (distinto del RUC) | Aviso de operaciones | Debida diligencia |
| Dirección de oficina (provincia, distrito, corregimiento, calle) | Aviso de operaciones | Conoce a tu cliente, solicitud, checklist de seguro |
| Fecha de constitución e inicio de operaciones | Pacto social de constitución | Conoce a tu cliente, solicitud, debida diligencia |
| Representante | Cédula (solo el frente) | Conoce a tu cliente, solicitud, carta de buró |
| Representación y plazo | Documento más reciente: personería jurídica, poder o acta de junta; sin plazo es indefinida | Conoce a tu cliente, solicitud |
| Accionistas y beneficiarios finales | Declaración jurada o personería; anexo 5 si hay empresas | Conoce a tu cliente, debida diligencia |
| Directores y dignatarios | Pacto social y actas | Debida diligencia |
| Bien, marca, modelo, año y total | Proforma | Hoja, solicitud, debida diligencia, cotización, flujo |
| Condiciones | Hoja de negociación | Conoce a tu cliente, cotización, flujo |

---

## 5. Orden de revisión

**Orden real:** el del checklist. Para el negocio, la revisora se queda solo con Conoce a tu cliente, aviso de operaciones, cédula y pacto social.

**Orden recomendado para la herramienta:**
1. Inventario.
2. Anclas: aviso de operaciones, pacto social, cédula y personería jurídica.
3. Conoce a tu cliente contra las anclas.
4. Carta de buró y APC, verificando que el RUC consultado sea el correcto.
5. Información financiera, declaraciones y estados de cuenta.
6. Proforma, hoja, cotización y flujo.
7. Solicitud, debida diligencia y checklist de seguro.

---

## 6. Estrategias, criterios en vivo, reglas y excepciones

- **Información financiera:** dos años cerrados y el interino; si la empresa es reciente, no se piden años en que no existía; un interino auditado no existe, así que se acepta con balance general y estado de cuenta. Los contadores suelen adjuntar su identificación.
- **Declaraciones:** anuales; se validan RUC, dígito verificador, razón social y periodo.
- **APC:** de empresa, representante y accionistas; si el representante no es accionista, no se le pide. Funciona como Infornet y TransUnion juntos: moras y demandas; calificación máxima 3.
- **APC "no existe":** en el caso, la consulta se hizo con un RUC al que le faltaba un dígito; se pidió corregir la consulta.
- **Apellido de casada distinto entre cédula y APC:** se acepta si coincide el número de cédula.
- **Correos y teléfonos distintos entre documentos:** se registran ambos.
- **Proforma sin año:** se devuelve; el tipo de vehículo no es obligatorio.
- **Uso comercial:** en Panamá y Costa Rica un vehículo particular puede tener uso comercial (transporte o alquiler), y eso afecta el seguro.
- **Cliente nuevo:** menos de un año con Arrend; después es de cartera.
- **Visita:** si la hizo otra persona, visto bueno o explicación.

**Criterios que decide la persona de CGE:** quién es el vendor cuando la proforma no lo deja claro (se consulta a quien ingresa a FIMS), qué documento de representación es el más reciente y qué hacer con una hipoteca atrasada en el APC.

---

## 7. Reglas, conflictos y precedentes

| Regla | Nivel |
|---|---|
| APC con calificación mayor a 3 o mora sin respaldo | Crítico |
| Falta el aviso de operaciones o el pacto social de constitución | Crítico |
| APC consultado con un RUC incorrecto | Regular |
| Fecha de inicio de operaciones distinta a la del pacto social | Regular |
| RUC y número de aviso de operaciones intercambiados | Regular |
| Uso distinto entre cotización y checklist de seguro | Regular |
| Proforma sin año del bien | Regular |
| Falta el formulario de debida diligencia | Regular |

**Precedentes:** la gerencia del país parametrizó por correo que la fecha de constitución sale siempre del pacto social. La carta de buró es regional, excepto en Honduras.

---

## 8. Cálculos

| Concepto | Fórmula observada |
|---|---|
| Base | Total de la proforma, con ITBMS de 7 % incluido; balboas y dólares a la par |
| Renta inicial | Total × % |
| Opción de compra | Total × % + traspaso de 171.20 (ya con ITBMS) |
| Seguro y GPS | Ya vienen con ITBMS; el GPS de 18 dólares aparece como 19.26 |
| Cuota mensual | Renta + seguro + GPS |
| Flujo | Renta inicial y traspaso ÷ 1.07; la opción de compra no se divide |

Sin resolver: gastos iniciales financiados y "bono cliente".

Ejemplo ficticio: total 20,000.00, renta inicial 5 %, opción de compra 5 %. Renta inicial: 1,000.00. Opción de compra: 1,171.20. Renta inicial del flujo: 934.58.

---

## 9. Errores

| Frecuencia | Error | Cómo se detecta |
|---|---|---|
| Común | Fecha de inicio de operaciones tomada del aviso y no del pacto social | Cruce |
| Común | Uso particular en un documento y comercial en otro | Cruce |
| Posible | APC consultado con RUC incompleto | Comparar el número consultado |
| Posible | RUC confundido con el número de aviso | Cruce |
| Posible | Proforma sin año o sin datos del vendor | Lectura |
| Raro | Gastos iniciales que no cuadran por un bono | Recalcular y escalar |
| Raro | Hipoteca con atraso en un historial ya cancelado | Lectura del APC |

---

## 10. Relación con `digitador-arrend`

- Coinciden en RUC, cédula, APC en lugar de Infornet, tipo de cambio 1, ITBMS de 7 % y que no se pide estado patrimonial.
- El digitador advierte que, si solo hay buró del representante, debe decirse de quién es; CGE exige el de la empresa y los accionistas.
- Pendiente para Riesgos: aclarar el "bono cliente" antes de vaciar gastos iniciales.

---

## 11. Qué automatizar y qué dejar a la persona

| Automatizar | Dejar a la persona |
|---|---|
| Inventario y cruces contra el aviso de operaciones y el pacto social | Certificación del vendor |
| Verificar el RUC consultado en el APC | Documento de representación vigente |
| Detectar RUC y número de aviso intercambiados | Hipotecas y casos de buró ambiguos |
| Recalcular sobre el total con ITBMS | Bono cliente mientras no haya regla |

---

## 12. Dudas abiertas para CGE

1. ¿Qué es el "bono cliente" y cómo se calculan los gastos iniciales financiados?
2. ¿Cuál es el cobro de dispositivo y GPS en Panamá?
3. ¿Se pide comprobante de una hipoteca atrasada en el APC?
4. ¿La propuesta Arrend es obligatoria con cotizador manual?
5. ¿Puede validar estos cálculos el encargado de revisión actual?
