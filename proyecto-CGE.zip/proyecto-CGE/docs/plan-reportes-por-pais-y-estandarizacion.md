# Plan de trabajo: reportes por país, estandarización y entrenamiento del modelo pre clasificador

**Fecha:** 19 de noviembre de 2026
**Alcance:** revisiones grabadas de entrenamiento 8 a 10, el Excel de orden de documentación por país, los checklists por país y la habilidad `digitador-arrend`.
**Entrega final:** después de la revisión 10.

---

## 1. Solicitudes recibidas

1. Un reporte técnico y de aprendizaje por país, en un solo archivo md por país.
2. Las estrategias de los analistas según el momento, el documento y la parte del checklist.
3. La relación con `digitador-arrend` y con el Excel de orden de documentación.
4. Un orden sugerido de revisión y la relación entre documentos.
5. Los errores comunes, posibles y raros.
6. Cómo estandarizar el proceso y cómo lograr que Claude entienda mejor los documentos de proceso.

---

## 2. Orden sugerido para atenderlas

| Paso | Qué se hace | Por qué en este orden | Cuándo |
|---|---|---|---|
| 1 | Guardar cada revisión de entrenamiento en una ficha con campos fijos (sección 4) | Si se escribe directo en los reportes, cada caso nuevo obliga a reescribirlos; la ficha acumula sin perder nada | Con cada revisión, de la 8 a la 10 |
| 2 | Armar el catálogo maestro: documento, datos que contiene, documento que manda en cada dato, regla y país | Es la base común de todos los países; sin él, los reportes por país se repiten y se contradicen | Al recibir la revisión 10 |
| 3 | Escribir el reporte de Guatemala | Es el foco del proyecto, concentra el 75 % de los casos y es el país con más revisiones de entrenamiento | Primero |
| 4 | Escribir los reportes de Honduras, El Salvador, Panamá, Costa Rica y República Dominicana | Honduras, El Salvador y Panamá comparten el formato del Conoce a tu cliente; Costa Rica y República Dominicana tienen más reglas propias | Después de Guatemala |
| 5 | Derivar el orden sugerido de revisión y el mapa de relaciones de cada país | Sale del catálogo maestro; hacerlo antes sería adivinar | Dentro de cada reporte |
| 6 | Consolidar los errores comunes, posibles y raros | Para clasificar por frecuencia se necesitan todos los casos | Dentro de cada reporte, con un consolidado regional |
| 7 | Cruzar con `digitador-arrend` | Se identifica qué conocimiento es compartido y qué debe pasar al proyecto de Riesgos | Sección propia en cada reporte |
| 8 | Propuesta de estandarización para CGE | Se apoya en la evidencia de todos los países y se alinea con el entregable de criterios de CGE | Al final, como documento aparte |

---

## 3. Estructura fija de cada reporte por país

1. **Resumen:** qué hace distinto a este país y los cinco aprendizajes principales.
2. **Fuentes:** revisiones grabadas, checklist, matriz de orden y fecha de cada fuente.
3. **Expediente madre y negocio:** documentos por tipo de cliente (persona individual, empresa individual, persona jurídica) y por producto, tomados del Excel de orden.
4. **Catálogo de datos:** cada dato, el documento que manda, contra qué documentos se cruza y cómo se compara.
5. **Orden sugerido de revisión:** el orden del checklist, el orden real que usan los analistas y el orden recomendado para la herramienta, con la razón de cada diferencia.
6. **Estrategias, criterios en vivo, reglas y excepciones de los analistas:** agrupados por momento (preparación de la carpeta, expediente madre, negocio, cálculos, cierre del ticket), por documento y por parte del checklist. Incluye las decisiones que los analistas tomaron en vivo durante las revisiones y las validaciones que deben quedar en manos de la persona de CGE porque una IA no puede resolverlas con certeza. Por ejemplo, de la revisión 5 (Costa Rica):
   - **Identidad del asesor:** el analista de CGE confirma que el nombre del asesor que figura en el Conoce a tu cliente corresponde a la persona de la selfie. En esa revisión, la selfie era de otro asesor; lo detectó una analista con experiencia porque conoce a los asesores de cada país. La herramienta puede comparar nombres entre documentos, pero no reconocer a una persona en una foto.
   - **Vendor:** el analista certifica el vendor. Un mismo grupo comercial tiene varias razones sociales, la proforma puede traer solo el logotipo y el nombre registrado en FIMS puede no coincidir con el de la proforma; el analista lo deduce por el tipo de bien y lo confirma con el asesor.
7. **Reglas y criterios:** reglas del checklist, criterios de práctica, conflictos entre ambos y precedentes de Legal y Riesgos.
8. **Cálculos:** fórmulas, montos fijos del país y ejemplos ficticios.
9. **Errores:** comunes (vistos en más de un caso), posibles (descritos por los analistas) y raros (vistos una sola vez), con documento, cómo se detecta y nivel.
10. **Relación con `digitador-arrend`:** conocimiento compartido, diferencias de propósito y pendientes para el proyecto de Riesgos.
11. **Qué automatizar y qué dejar a criterio humano.**
12. **Dudas abiertas para CGE.**

---

## 4. Ficha de cada revisión de entrenamiento

Cada revisión se guarda con estos campos, sin datos de clientes:

| Campo | Contenido |
|---|---|
| Identificación | Número de revisión, país, tipo de cliente, producto, nuevo o cartera, con o sin aval, número de negocios |
| Tiempo | Total y por bloque (preparación, expediente madre, negocio, cálculos) |
| Orden real | Secuencia en que el analista revisó los documentos |
| Fuentes por dato | De qué documento sacó cada dato |
| Estrategias | Qué hizo para no perderse, para ir más rápido o para resolver una duda |
| Correcciones | Las que encontró, con documento y apartado; las que se habían pasado en la revisión original |
| Criterios nuevos | Reglas o excepciones que no estaban documentadas |
| Dudas | Lo que el analista no supo resolver |
| Relación con el digitador | Coincidencias o diferencias con `digitador-arrend` |

Estado actual: la revisión 8 (Guatemala) ya está guardada en bodega-revisiones-entrenamiento.md.

---

## 5. Cómo estandarizar el proceso

1. **Parametrizar de dónde sale cada dato.** Una matriz por país con el dato, el documento que manda y los documentos que se cruzan. La pidieron las propias analistas, y la usan sin escribirla: las que tienen experiencia saben de qué documento resumen sacar cada dato, y las nuevas recorren todos.
2. **Un solo formato de notas del revisor.** Hoy cada analista lleva su propio formato. Una plantilla común (hora, país, tipo de cliente, asesor y correcciones con la regla de origen) permite medir y entrenar.
3. **Un solo formato de corrección.** "DOCUMENTO: APARTADO: dice X; debe decir Y, según Z". Así Comercial recibe siempre la misma estructura y la herramienta puede generarla.
4. **Nombres de archivo estándar.** Número del orden de escaneo más el nombre oficial del documento, y la palabra "Respaldo" para todo lo que no está en el checklist.
5. **Catálogos compartidos.** Nomenclatura de productos, montos fijos e IVA por país, vendors agrupados por grupo comercial con sus razones sociales, y asesores por país.
6. **Registro de precedentes.** Cada consulta a Legal o a Riesgos que resuelve un caso nuevo queda escrita como criterio, con fecha y quién la aprobó.
7. **Menos datos llenados a mano.** Los errores están en los documentos que llena Comercial, no en los de terceros. Cada dato que el sistema copie de un documento fuente elimina un error posible.
8. **El FEIC como documento ancla.** Cuando el FEIC viene correcto, el resto del caso se revisa mucho más rápido, porque sirve de fuente para los demás formularios. Revisarlo primero y a fondo es la mejor inversión de tiempo.
9. **Medición continua.** Tiempo por documento, correcciones por tipo y por asesor, y vueltas por caso, con los tickets de Hive como fuente.

---

## 6. Cómo lograr que Claude entienda mejor los documentos de proceso

1. **Reglas atómicas en lugar de párrafos.** Cada regla con su id, la condición, el documento, el país, el producto, la severidad y la fuente. Una oración del checklist que mezcla cinco condiciones se convierte en cinco reglas.
2. **Un ejemplo ficticio por regla.** Un caso que cumple y uno que no. Los ejemplos reducen las interpretaciones más que cualquier explicación.
3. **Glosario de equivalencias por país.** RTU, RTN, NIT y RNC; nombramiento, credencial y personería jurídica; escritura, pacto social y estatutos. Sin el glosario, Claude aplica reglas de un país a otro.
4. **Separar qué se valida de cómo se calcula.** Las fórmulas con variables con nombre y los montos fijos en una tabla aparte, no dentro del texto.
5. **Datos estructurados primero.** El JSON del FEIC y el texto de los PDF antes que la imagen. Cada dato con el número de página de donde salió.
6. **Documentos de proceso en texto con tablas simples.** Los Excel con celdas combinadas, encabezados repetidos o columnas por país se convierten en tablas planas, con versión y fecha.
7. **Marcar lo que es criterio humano.** La comparación de firmas, la identidad del asesor en la selfie, la certificación del vendor, la lectura de tachones, los vistos buenos y las consultas a Legal se etiquetan como "revisión humana": Claude los señala, no los decide.
8. **Casos de entrenamiento con la respuesta del analista.** Cada caso grabado debería venir con las correcciones reales de su ticket; sin esa respuesta no se puede medir si la herramienta acierta.
9. **Una sola fuente por regla.** Si el checklist, el manual y la práctica dicen cosas distintas, la regla registra las tres y cuál manda; Claude no debe elegir por su cuenta.

---

## 7. Lo que necesito con cada revisión

1. La transcripción y el video, con el orden de las partes.
2. Las correcciones reales del ticket de Hive de ese caso.
3. El país, el tipo de cliente, el producto y si es nuevo o de cartera.
4. El tiempo total que tomó la revisión.
