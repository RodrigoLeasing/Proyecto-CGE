#!/usr/bin/env python3
"""Revisa la estructura del repositorio y busca datos que no deben subirse.

NUNCA imprime el dato encontrado: solo archivo, línea y tipo de hallazgo (regla
de privacidad del proyecto).

Qué revisa:
1. Que existan los archivos base y que .gitignore proteja los datos de clientes.
2. Que no haya archivos de tipos prohibidos (grabaciones, transcripciones, PDF,
   capturas, hojas de cálculo) fuera de las carpetas permitidas.
3. Que los textos (md, json, py, yml, html) no traigan números largos, correos,
   rutas de usuario ni nombres de la lista local `scripts/nombres_prohibidos.txt`.
4. Que no queden restos de la redacción obsoleta ("solo señala").
5. Que corra el validador de la habilidad.
6. Que la copia de la habilidad en `.claude/skills` coincida con el plugin.

Uso: python scripts/validar_repo.py
"""
import re
import subprocess
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
BASE = ["CLAUDE.md", "README.md", ".gitignore", ".claude-plugin/marketplace.json",
        "plugins/clasificador-arrend/.claude-plugin/plugin.json",
        "plugins/clasificador-arrend/skills/clasificador-arrend/SKILL.md",
        "casos/README.md", "scripts/sincronizar_habilidad.py",
        ".claude/skills/clasificador-arrend/SKILL.md"]
GITIGNORE_DEBE_TENER = ["casos/*", "*.mp4", "*.vtt", "*.pdf", "*.png", "*.xlsx", "*.zip",
                        "scripts/nombres_prohibidos.txt"]
EXT_PROHIBIDAS = {".mp4", ".mov", ".mkv", ".wav", ".mp3", ".vtt", ".srt", ".pdf", ".docx",
                  ".doc", ".xlsx", ".xlsm", ".xls", ".csv", ".png", ".jpg", ".jpeg", ".gif",
                  ".zip", ".skill"}
EXT_TEXTO = {".md", ".json", ".py", ".yml", ".yaml", ".txt", ".html", ".sh", ".ps1"}
IGNORAR_DIR = {".git", "node_modules", "__pycache__", "casos", "salida", "resultados"}
PATRONES = {
    "número largo (posible documento de identidad o NIT)": re.compile(r"(?<![\d.,])\d{9,13}(?![\d.,])"),
    "correo electrónico": re.compile(r"[\w.+-]+@[\w-]+\.[\w.]+"),
    "ruta de usuario": re.compile(r"(/Users/|C:\\Users\\|/home/(?!claude))"),
    "número de expediente": re.compile(r"(?i)expediente\s*(n[o°.º]|n[úu]mero)\s*[:#]?\s*\d+"),
    "clave o token": re.compile(r"(?i)(sk-ant-|ghp_|github_pat_|AKIA[0-9A-Z]{12})"),
}
OBSOLETOS = {
    "frase obsoleta (la herramienta clasifica, no solo señala)": re.compile(r"(?i)nunca aprueba|no rechaza y no certifica|solo se[ñn]ala"),
    "regla obsoleta (las resoluciones del Comité sí se procesan)": re.compile(r"(?i)no proceses resoluciones|no lo abras"),
}


def archivos():
    for p in sorted(RAIZ.rglob("*")):
        if not p.is_file():
            continue
        if p.relative_to(RAIZ).as_posix() == "scripts/nombres_prohibidos.txt":
            continue  # la lista local no se revisa a sí misma
        partes = set(p.relative_to(RAIZ).parts)
        if partes & IGNORAR_DIR and p.relative_to(RAIZ).as_posix() != "casos/README.md":
            continue
        yield p


def cargar_nombres():
    f = RAIZ / "scripts" / "nombres_prohibidos.txt"
    if not f.exists():
        return None
    nombres = [l.strip() for l in f.read_text(encoding="utf-8").splitlines()
               if l.strip() and not l.startswith("#")]
    return re.compile("|".join(re.escape(n) for n in nombres), re.I) if nombres else None


def main():
    errores, avisos = [], []
    for b in BASE:
        if not (RAIZ / b).exists():
            errores.append(f"falta {b}")
    gi = RAIZ / ".gitignore"
    if gi.exists():
        txt = gi.read_text(encoding="utf-8")
        for g in GITIGNORE_DEBE_TENER:
            if g not in txt:
                errores.append(f".gitignore no protege {g}")
    pat_nombres = cargar_nombres()
    if pat_nombres is None:
        avisos.append("no existe scripts/nombres_prohibidos.txt: no se revisan nombres aquí. "
                      "En GitHub los revisa la verificación automática con el secreto NOMBRES_PROHIBIDOS.")

    for p in archivos():
        rel = p.relative_to(RAIZ).as_posix()
        if p.suffix.lower() in EXT_PROHIBIDAS:
            errores.append(f"{rel}: tipo de archivo que no debe subirse")
            continue
        if p.suffix.lower() not in EXT_TEXTO:
            continue
        es_html = p.suffix.lower() == ".html"
        try:
            lineas = p.read_text(encoding="utf-8").splitlines()
        except UnicodeDecodeError:
            avisos.append(f"{rel}: no se pudo leer como texto")
            continue
        for n, l in enumerate(lineas, 1):
            for nombre, pat in PATRONES.items():
                if es_html and nombre.startswith("número largo"):
                    continue  # el HTML trae constantes numéricas de código
                if rel.endswith("validar_repo.py") or rel.endswith("validar_skill.py"):
                    continue
                if pat.search(l):
                    errores.append(f"{rel}:{n}: posible {nombre}")
            if pat_nombres and pat_nombres.search(l):
                errores.append(f"{rel}:{n}: aparece un nombre de la lista prohibida")
            if not rel.endswith(("validar_repo.py", "validar_skill.py")):
                for nombre, pat in OBSOLETOS.items():
                    if pat.search(l):
                        errores.append(f"{rel}:{n}: {nombre}")

    skill = RAIZ / "plugins/clasificador-arrend/skills/clasificador-arrend/scripts/validar_skill.py"
    if skill.exists():
        r = subprocess.run([sys.executable, str(skill)], capture_output=True, text=True)
        if r.returncode != 0:
            errores.append("validar_skill.py falló:\n" + r.stdout.strip())

    sync = RAIZ / "scripts" / "sincronizar_habilidad.py"
    if sync.exists():
        r = subprocess.run([sys.executable, str(sync), "--verificar"], capture_output=True, text=True)
        if r.returncode != 0:
            errores.append("el espejo .claude/skills no coincide con el plugin:\n" + r.stdout.strip())

    for a in avisos:
        print("AVISO:", a)
    for e in errores:
        print("ERROR:", e)
    if not errores:
        print("Validación correcta: estructura y privacidad sin errores.")
    return 1 if errores else 0


if __name__ == "__main__":
    sys.exit(main())
