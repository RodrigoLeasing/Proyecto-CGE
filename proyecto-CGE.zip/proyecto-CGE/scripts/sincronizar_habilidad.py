#!/usr/bin/env python3
"""Mantiene una copia de la habilidad como habilidad de proyecto.

La fuente única es plugins/clasificador-arrend/skills/clasificador-arrend/.
Claude Code carga solo las habilidades de `.claude/skills/` cuando se abre el
repositorio (incluso en una sesión en la nube), así que esa carpeta es un espejo.

Uso:
    python scripts/sincronizar_habilidad.py             # copia fuente -> espejo
    python scripts/sincronizar_habilidad.py --verificar # falla si difieren

No edites el espejo a mano: se sobrescribe.
"""
import hashlib
import shutil
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
FUENTE = RAIZ / "plugins/clasificador-arrend/skills/clasificador-arrend"
ESPEJO = RAIZ / ".claude/skills/clasificador-arrend"
IGNORAR = {"__pycache__"}


def huellas(base):
    out = {}
    if not base.exists():
        return out
    for p in sorted(base.rglob("*")):
        if p.is_file() and not (set(p.relative_to(base).parts) & IGNORAR) and p.suffix != ".pyc":
            out[p.relative_to(base).as_posix()] = hashlib.sha256(p.read_bytes()).hexdigest()
    return out


def main(argv):
    if not FUENTE.exists():
        print("ERROR: no existe la fuente", FUENTE); return 2
    a, b = huellas(FUENTE), huellas(ESPEJO)
    if "--verificar" in argv:
        faltan = sorted(set(a) - set(b)); sobran = sorted(set(b) - set(a))
        distintos = sorted(k for k in a if k in b and a[k] != b[k])
        if not (faltan or sobran or distintos):
            print("El espejo de la habilidad coincide con la fuente."); return 0
        for k in faltan: print("ERROR: falta en el espejo:", k)
        for k in sobran: print("ERROR: sobra en el espejo:", k)
        for k in distintos: print("ERROR: difiere:", k)
        print("Corrige con: python scripts/sincronizar_habilidad.py"); return 1
    if ESPEJO.exists():
        shutil.rmtree(ESPEJO)
    shutil.copytree(FUENTE, ESPEJO, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    print(f"Espejo actualizado: {len(huellas(ESPEJO))} archivos en {ESPEJO.relative_to(RAIZ)}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
