# Herramienta pre alfa: pre clasificador de expedientes CGE

`preclasificador-cge.html` es la primera versión de la interfaz (un solo archivo
que se abre en el navegador; también se publicó como artefacto de Claude).

Qué hace: carga de documentos, lectura con IA con confianza por campo, visor con
marcas, cruces entre documentos (con vista previa), cálculos con origen de cada
dato, historia accionaria, hallazgos del analista y lista de correcciones.

Estado: **pre alfa.** Solo tiene checklist para Guatemala (persona jurídica) y
Honduras; la clasificación Pasa, No pasa y Revisión y la escala de confianza de
cinco niveles están definidas en la habilidad `clasificador-arrend` y **todavía no
están en la interfaz**. Errores conocidos: ver `docs/reporte-tecnico-preclasificador-cge.md`
(E12 sobre el orden de los nombres y la pérdida del expediente al actualizar).

Los datos del "expediente de prueba" son ficticios. No guardes aquí capturas ni
expedientes reales.
