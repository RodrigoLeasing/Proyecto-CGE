# clasificador-arrend

Plugin de ARREND para el Centro de Gestión de Expedientes (CGE). Su habilidad
central, `clasificador-arrend`, orquesta los documentos de un expediente, los
módulos de revisión, las reglas y los formatos de salida. Clasifica cada término,
cada documento y el expediente como Pasa, No pasa o Revisión, y muestra el nivel
de confianza de cada lectura (Alto, Medio, Bajo, Ilegible o Faltante) junto con
su fuente.

Alcance actual: Guatemala, persona jurídica, con el análisis de escrituras y de la
estructura accionaria como entrega comprometida. Los demás módulos son avance y
los otros países están documentados solo como referencia.

Instalación (dentro de Claude Code):

```
/plugin marketplace add ARL-Desarrollos-WEB/proyecto-CGE
/plugin install clasificador-arrend@arrend-cge
```

Uso: sube un expediente y pide revisarlo. Las reglas están en
`skills/clasificador-arrend/references/` y el generador de la hoja de resultado en
`skills/clasificador-arrend/scripts/render_hoja.py`. No incluyas datos de clientes
en estos archivos.
