# Módulo 3: representación y estructura accionaria (comprometido)

**Alcance:** Guatemala, persona jurídica. Es el módulo que se entrega y se mide.
Hoy se ejecuta desde este archivo; el contrato para extraerlo como habilidad
propia (SH-ESC) está en `contrato_subhabilidades.md`.

## 1. Para qué existe

Leer una escritura larga, revuelta o sin numeración toma horas (hasta 180
páginas) y es donde más se pierde tiempo y más se equivoca una lectura
automática. El módulo responde cuatro preguntas, cada una con su página:

1. ¿La escritura está completa y es de la sociedad que se está revisando?
2. ¿Quiénes son los accionistas **vigentes** y con qué porcentaje?
3. ¿Quién representa a la sociedad, con qué cargo y hasta cuándo?
4. ¿Coincide todo eso con el FEIC, el Conoce a tu cliente y la solicitud?

## 2. Documentos de entrada

`escritura` (constitución), `escritura_mod` (todas las modificaciones),
`carta_accionaria`, `anexo5`, `nombramiento`, `dpi`, `rtu_representante`,
`patente_sociedad` (para confirmar que cada escritura es de esta sociedad) y
`feic_json` o `feic` (para el cruce).

## 3. Reglas de lectura de una escritura

1. **Antes de usar una escritura, confirma de quién es.** Compara la razón social
   que dice con la `patente_sociedad`. Una analista probó una IA que le devolvió
   los accionistas de otra escritura; este control existe por eso. Toda cifra
   que extraigas lleva el id de la escritura y la página.
2. **Lee todas las páginas, por lotes.** Leer solo las primeras deja información
   incompleta y la lectura la completa con suposiciones.
3. **Completitud.** Si las hojas están numeradas, verifica la secuencia. Si no,
   verifica la secuencia de cláusulas ordinales (primera, segunda, … vigésima
   primera, … cuadragésima, …) y la continuidad del texto entre el final de una
   hoja y el inicio de la siguiente. Si vienen revueltas, reconstruye por
   coherencia del texto. Una hoja que falta se reporta con el ordinal anterior y
   el siguiente.
4. **Tipos de acto que cambian la estructura:** constitución, aumento o
   reducción de capital, cesión o compraventa de acciones, cambio de
   denominación, transformación, fusión. Cada uno es un evento de la línea de
   tiempo.
5. **Capital.** Busca capital autorizado, suscrito y pagado, número de acciones
   y valor de cada una. El porcentaje de cada socio es sus acciones entre el
   total de acciones suscritas.
6. **Apellidos.** "SOA" significa "sin otro apellido". Los nombres y apellidos
   extranjeros se leen letra por letra.
7. **Tachones o correcciones a mano** en una escritura firmada, autorizada y
   registrada: se asume válida; es **OBSERVAR** con criterio humano. Legal y
   Riesgos deciden si piden respaldo.
8. **Datos que el FEIC pide de la escritura:** número, fecha, notario, fecha de
   inscripción, país y ciudad de constitución. Si no hay modificaciones, esa
   sección del FEIC va vacía.

## 4. Estructura accionaria vigente: qué fuente manda

| Situación | Fuente de la estructura vigente |
|---|---|
| Los accionistas son personas individuales y no hubo cambios | Escritura de constitución |
| Los accionistas son personas individuales y hubo cambios | Última modificación o carta accionaria, reconstruida desde la constitución |
| Algún accionista es una sociedad | **Anexo 5 de beneficiarios finales** (regla confirmada por CGE en la revisión del prototipo) |
| Una sociedad es dueña final en el último eslabón | Hallazgo: una sociedad nunca queda como dueño final; se pide el desglose |

La estructura que arma la escritura **puede no ser la vigente**. Ejemplo
ficticio: la constitución muestra 50 % y 50 % entre dos personas; una
modificación cede casi todo a una sociedad; la estructura vigente sale del
anexo 5 y puede ser 99 % y 1 %. Calcular solo desde la constitución daría una
estructura equivocada.

## 5. Algoritmo

1. Verifica de quién es cada escritura (regla 1) y ordénalas por fecha.
2. Verifica completitud de cada una (regla 3).
3. Construye la **línea de tiempo**: un evento por acto, con tipo, fecha,
   escritura y página, partes y acciones.
4. Calcula el estado después de cada evento. Una cesión de quien no aparece
   antes como accionista **rompe la cadena**: se señala.
5. Aplica la tabla de la sección 4 para decidir la fuente de la estructura
   vigente.
6. Si hay sociedades socias, exige el `anexo5` y desglosa hasta personas. Los
   beneficiarios de países donde ARREND no opera no llevan buró.
7. Calcula los porcentajes y verifica que sumen 100 %. Una diferencia por
   redondeo evidente (por ejemplo 99.98 y 0.02) es **OBSERVAR**, no error.
8. Compara con el FEIC, el Conoce a tu cliente y la solicitud. **Solo se
   comparan los accionistas con 10 % o más.**
9. Verifica el nombramiento: la persona es la del DPI, el cargo coincide con el
   FEIC, el vencimiento es fecha inicial más plazo, y registro, folio y libro
   coinciden con los del FEIC.
10. Verifica el DPI vigente y que el representante coincide por nombre y número.
11. Verifica que el último cambio de estructura tenga menos de 5 años; si no,
    **OBSERVAR**: confirmar que no hay modificaciones posteriores.
12. Emite hallazgos con las reglas `GT-ESC-*` de `reglas_y_severidad.md`.

## 6. Salida del módulo

`estructura_accionaria.json`:

```json
{
  "escrituras": [{"id": "esc-1", "tipo": "constitucion", "fecha": "AAAA-MM-DD",
                  "paginas": "1-18", "razon_social_coincide": true,
                  "completa": true, "hojas_faltantes": []}],
  "eventos": [{"orden": 1, "tipo": "constitucion", "escritura": "esc-1", "pagina": 8,
               "partes": [{"nombre": "Socio A", "tipo": "persona", "acciones": 100}]}],
  "estructura_vigente": {
    "fuente": "escritura|modificacion|carta_accionaria|anexo5",
    "total_acciones": 200,
    "accionistas": [{"nombre": "Socio A", "tipo": "persona", "acciones": 100, "porcentaje": 50.0,
                     "mayor_o_igual_10": true, "documento": "esc-1", "pagina": 8,
                     "confianza": "Medio", "fuente": "Escritura, pág. 8"}],
    "suma_porcentajes": 100.0
  },
  "beneficiarios_finales": [],
  "representante": {"nombre": "…", "cargo": "…", "vigencia_hasta": "AAAA-MM-DD",
                    "nombramiento_pagina": 3, "dpi_coincide": true,
                    "confianza": "Alto", "fuente": "Nombramiento, pág. 3"},
  "alertas": []
}
```

Los nombres del ejemplo son ficticios. En un caso real, el resultado lleva los
nombres y datos que trae el expediente; **no los guardes en la habilidad ni en
las referencias**.

Cada término del módulo (accionista, porcentaje, cargo, vigencia, número de
escritura) se califica con la escala de `regla_confianza.md` y se clasifica como
Pasa, No pasa o Revisión. Una lectura Bajo o Ilegible de una cifra de acciones
deja la estructura en Revisión; no se calculan porcentajes definitivos sobre una
lectura dudosa.

## 7. Qué queda en Revisión para la persona de CGE

1. Si una escritura con tachones pasa.
2. Cuál es la escritura vigente cuando hay duda de fechas.
3. Si una estructura reconstruida de varias fuentes es la correcta.
4. Si falta una modificación que el expediente no menciona.
5. Si un cargo con otro nombre es el mismo cargo.

La herramienta presenta la línea de tiempo con las páginas y deja estos temas en
Revisión; la persona decide.

## 8. Errores frecuentes del módulo

| Error | Qué hacer |
|---|---|
| Accionistas de otra escritura | Verificar la razón social de cada escritura antes de usarla |
| Estructura de la constitución tomada como vigente | Seguir la tabla de la sección 4 |
| Solo se lee un tramo de la escritura | Leer todas las páginas por lotes |
| Nombres con orden invertido leídos del DPI | Leer nombres y apellidos por separado; aplicar la regla del dato ancla |
| Sociedad como dueña final | Pedir el anexo 5 y desglosar |
| Porcentajes mal calculados por acciones sin valor | Usar acciones suscritas, no capital pagado |
| Letras que se pierden en un formato nuevo | Consultar; no devolver como error de Comercial |
| Escritura sin numeración | Verificar por ordinales y continuidad del texto |

## 9. Medición del módulo

Por caso se registra: tiempo de lectura antes y después, si la estructura
vigente fue confirmada o cambiada por la persona de CGE, y cuántos hallazgos
fueron falsas alarmas. Meta de entrenamiento propuesta: estructura vigente
correcta en 95 % de unos 70 casos; es una propuesta tomada de la experiencia de
Riesgos, **no un compromiso acordado**.
