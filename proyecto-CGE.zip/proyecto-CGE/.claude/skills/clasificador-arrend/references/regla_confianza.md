# Regla de confianza y clasificación

**Es una regla transversal, no un módulo ni un apartado.** Se aplica a todo
término que se lee, en todos los módulos, y se muestra junto a cada término, como
en el apartado de campos del digitador: **término, valor, nivel de confianza y
fuente** (documento y página, o "Sin evidencia en el expediente").

Es una parte central del entregable: con esta regla cada término, cada documento
y el expediente quedan clasificados como **Pasa, No pasa o Revisión**.

## 1. Escala de confianza

| Nivel | Rango | Criterio | Ejemplo |
|---|---|---|---|
| **Alto** | 95 a 100 | Texto copiado y pegado tal cual, o texto e imagen que coinciden | Valor del JSON del FEIC; texto de un PDF generado por sistema |
| **Medio** | 85 a 94 | Imagen legible, o texto copiado con cierta dificultad | DPI escaneado nítido; PDF con texto al que hubo que quitarle saltos o columnas |
| **Bajo** | 50 a 84 | Imagen borrosa, o texto que tuviste que editar y no sabes bien qué es | Escaneo con sombra; texto reconstruido de letras sueltas |
| **Ilegible** | menos de 50 | Parcialmente legible, pero no estás seguro de que sea ese término | Número largo con dígitos tapados |
| **Faltante** | no aplica | El término o el documento no está | Documento obligatorio ausente; página que no viene |

Notas:
- El rango de **Ilegible** se interpretó como "menos de 50" para que no se
  solape con Bajo (50 a 84). Por confirmar con el dueño del proyecto.
- Si se da un puntaje, debe caer dentro del rango de su nivel. Es una
  calificación por criterios, **no un porcentaje de acierto medido**. La
  precisión real se medirá comparando el nivel asignado con la decisión de la
  persona de CGE (sección 7).
- **Ilegible no es lo mismo que Faltante.** Ilegible: el documento existe y no se
  lee con seguridad. Faltante: no existe. Son dos problemas distintos (pedir una
  copia legible o pedir el documento).

## 2. Cómo se asigna el nivel

1. **Parte del origen de la lectura:** JSON o texto copiable del PDF → Alto;
   imagen nítida → Medio; imagen deficiente o texto editado → Bajo.
2. **Sube un nivel** si dos lecturas independientes coinciden (texto del PDF e
   imagen) o si otra zona del mismo documento confirma el valor (por ejemplo, la
   zona legible por máquina de un pasaporte, el sello o la firma).
3. **Baja un nivel** si las dos lecturas difieren, si tuviste que editar el
   texto, si falta un dígito o una letra, o si el valor solo aparece en un
   recorte de página que no puedes ubicar.
4. **Un valor que no puedes citar con página no puede ser Alto.**
5. **Los números largos** (documentos de identidad, registros, escrituras): un
   solo dígito dudoso deja el término en Bajo.
6. **Los nombres de personas:** lee nombres y apellidos por separado; un orden
   distinto al de los demás documentos baja el nivel a Medio como máximo.
7. Nunca subas un nivel porque el valor "debería ser" el esperado. La confianza
   mide la lectura, no si el dato cumple.

## 3. Clasificación

### Término

| Condición | Clasificación |
|---|---|
| Cumple la regla y la confianza es Alto o Medio | **Pasa** |
| Incumple la regla (no coincide, vencido, falta, mal calculado) y la confianza es Alto o Medio | **No pasa** |
| Término obligatorio con confianza Faltante | **No pasa** |
| Confianza Bajo o Ilegible, cualquiera sea el resultado | **Revisión** (con una lectura dudosa no se rechaza ni se aprueba) |
| Término que exige criterio humano (firma, selfie, vendor, tachones) | **Revisión** |
| Regla con nivel OBSERVAR | **Revisión** |

### Documento

Si **algún término no pasa, el documento entero no pasa.** Se indica cuáles
términos no pasan y con qué nivel de confianza. Si ninguno no pasa y alguno está
en Revisión, el documento queda en Revisión. Si todos pasan, el documento pasa.
Un documento obligatorio ausente no pasa.

### Expediente

Se deriva igual: algún documento que no pasa → el expediente **no pasa**; si no,
algún documento en revisión → **Revisión**; si no, **Pasa**.
*(Derivación propuesta; por confirmar con el dueño del proyecto.)*

### Relación con la severidad

| Severidad del hallazgo | Clasificación |
|---|---|
| BLOQUEA | No pasa (el caso no avanza así) |
| CORREGIR | No pasa (Comercial debe corregirlo) |
| OBSERVAR | Revisión |

Si el hallazgo se apoya en una lectura Bajo o Ilegible, pasa a **Revisión**
aunque su severidad sea BLOQUEA o CORREGIR.

### Decisión de la persona de CGE

La clasificación es la decisión de la herramienta. La persona de CGE puede
cambiarla; cada cambio queda registrado con su motivo (`confirmado`,
`falsa_alarma`, `bajado_a_observar`, `subido`). Esos cambios son el dato que
permite medir la precisión.

## 4. Cómo se muestra

Por documento, una fila por término:

| Término | Valor leído | Confianza | Fuente | Clasificación |
|---|---|---|---|---|
| Razón social | Constructora Ejemplo, S.A. | Alto (95 a 100) | Patente de sociedad, pág. 1 | Pasa |
| Número de escritura | 5 | Medio (85 a 94) | Escritura, pág. 1 | Pasa |
| Nombre del representante | Pedro Ejemplo Prueba | Bajo (50 a 84): imagen con sombra | DPI, pág. 1 | Revisión |
| Anexo de beneficiarios | — | Faltante | Sin evidencia en el expediente | No pasa |

Reglas de presentación:
- La fuente es el documento y la página, o "Sin evidencia en el expediente".
- Para Bajo e Ilegible se agrega el motivo en pocas palabras.
- Un término No pasa muestra qué dice y qué debería decir.
- La leyenda de la escala va en la hoja de resultado.

## 5. Qué hacer según el nivel

| Nivel | Acción |
|---|---|
| Alto | Úsalo para clasificar |
| Medio | Úsalo y muestra el nivel; si el término no pasa, recorta el valor de la página para que la persona lo vea |
| Bajo | No lo rechaces ni lo apruebes: Revisión, con el recorte y el motivo |
| Ilegible | Igual que Bajo; si todos los términos obligatorios de un documento son ilegibles, el documento no pasa por GT-INV-02 y se pide una copia legible |
| Faltante | Repórtalo una sola vez; término o documento obligatorio ausente: No pasa |

## 6. Casos de precisión observados

Situaciones y dificultades que enfrentaron los analistas en las revisiones. Cada
una indica cómo calificar la lectura. **Los casos no llevan datos de clientes.**

| Situación | Dónde se vio | Nivel | Clasificación | Qué hacer |
|---|---|---|---|---|
| Archivo JSON del FEIC | Guatemala | Alto | Según la regla | Usarlo como fuente exacta; no pasarlo por la lectura de imagen |
| PDF generado por sistema con texto copiable (hoja, cotización, flujo, recibo digital) | Todos | Alto | Según la regla | Copiar el texto y citar la página |
| Documento de identidad escaneado y nítido | Todos | Medio | Según la regla | Verificar con la zona legible por máquina o con otra zona del mismo documento para subir un nivel |
| Escaneo con sombra, torcido o pixelado (cédulas, recibos, registros) | República Dominicana, Honduras, Guatemala | Bajo | Revisión | Mostrar el recorte; si es todo el documento, pedir una copia legible |
| Recibo borroso o con varias direcciones | El Salvador | Bajo | Revisión | No decidir cuál dirección es; mostrar las dos |
| Recibo sin dirección (por ejemplo, de internet) | República Dominicana | Faltante (la dirección) | Revisión | La dirección sale de otro documento según el país; no se devuelve como error de Comercial |
| Documento de un tercero con corte irregular (banco, registro) | República Dominicana, Guatemala | Alto | Según la regla | No atribuirlo a Comercial salvo la vigencia |
| Nombres con orden distinto al de otros documentos | Guatemala | Medio | Revisión | Comparar como conjunto de palabras; posible lectura invertida (GT-ID-04) |
| Nombres y apellidos extranjeros o poco comunes | Guatemala, El Salvador | Medio, o Bajo si una letra es dudosa | Según la regla o Revisión | Leer letra por letra |
| Tilde ilegible en un documento escaneado ("JOSE" o "JOSÉ") | Guatemala | Medio | Pasa | La tilde no es diferencia |
| "SOA" (sin otro apellido) | Guatemala | Alto | Según la regla | No es un apellido faltante |
| Apellido de casada o de soltera distinto entre buró y documento | El Salvador, Panamá | Alto | Pasa | Identificar a la persona por el número de documento |
| Número de escritura, registro o documento de identidad con un dígito dudoso | Guatemala, Panamá | Bajo | Revisión | Mostrar el recorte; no corregir el dato de Comercial sobre un dígito dudoso |
| RUC o NIT incompleto en una consulta de buró | Panamá | Alto | No pasa | La consulta está mal hecha; es un error del documento, no de la lectura |
| Precio con "Q." o separadores | Guatemala | Alto | Según la regla | Tomar el número desde el primer dígito |
| Cotización escaneada con cifras | Guatemala, Honduras | Medio o Bajo | Según la regla o Revisión | Recalcular antes de clasificar |
| Cotización en otro idioma o varias cotizaciones del mismo bien | Guatemala | Medio | Revisión | La identificación del bien es criterio humano |
| Cotización en moneda extranjera sin tipo de cambio | Guatemala, Costa Rica | Faltante (el tipo de cambio) | No pasa | Reportar una sola vez |
| Letra manuscrita en cartas de buró o formularios | República Dominicana, Guatemala | Bajo | Revisión | Si los números coinciden, la letra imperfecta no es error |
| Firmas y sellos | Todos | Medio | Revisión | Es criterio humano; mostrar recorte lado a lado |
| Firma que el visor del PDF no muestra | República Dominicana | Medio (en la imagen) | Revisión | Renderizar la página; no concluir "falta firma" con la vista del visor |
| Casillas marcadas (uso, persona expuesta) | Todos | Medio | Según la regla | Solo se ven en la imagen; Bajo si la marca es ambigua |
| Escritura de más de 100 páginas, sin numeración, revuelta | Guatemala, Honduras, República Dominicana | Medio o Bajo según la página | Revisión si la reconstrucción es dudosa | Citar página y cláusula; verificar completitud por ordinales |
| Escritura manuscrita o con tachones, firmada y registrada | Guatemala | Bajo | Revisión | Criterio humano; Legal decide si pide respaldo |
| Escritura que parece de otra sociedad | Honduras | Bajo hasta confirmar la razón social | Revisión | Verificar la razón social de cada escritura antes de usarla |
| Formato nuevo de composición accionaria con letras perdidas | Guatemala | Bajo | Revisión | Consultar; no devolver como error de Comercial |
| Informe de buró con páginas duplicadas | Honduras | Alto | Según la regla | Contar las páginas únicas |
| Informe de buró "página 6 de 7" sin la última | El Salvador | Faltante (la página) | No pasa | Pedir el informe completo |
| Informe de buró de otra persona o con otro número | El Salvador, Panamá | Alto | Revisión | Identificar por número de documento |
| Archivos unidos en uno solo (informes, estados de cuenta, respaldos) | Costa Rica, Guatemala | Medio | Revisión | Separar por documento; si no se puede, Revisión |
| Estados de cuenta con dos cuentas mezcladas o corte a mitad de mes | Costa Rica, República Dominicana | Alto | Según la regla | Ordenar por cuenta; contar el periodo completo |
| Notas de la hoja de negociación cortadas por el propio documento | Guatemala | Ilegible | Revisión | Probable defecto del documento; la persona confirma si se devuelve |
| Dato que aparece en otro documento pero no en el que manda | Todos | Alto | No pasa | El documento que manda es el que cuenta |
| Valor extraído de otro documento por error de la herramienta | Honduras | Bajo | Revisión | Todo valor lleva documento y página; sin cita no hay Alto |

## 7. Medición

La precisión de lectura no se declara hasta medirla. Para cada caso se guarda, por
término, el nivel asignado y la decisión de la persona de CGE. Con eso se
calcula, por nivel:

- qué parte de los términos Alto fueron cambiados por la persona (debería ser
  muy baja),
- qué parte de los términos Medio, Bajo e Ilegible terminó confirmada,
- cuántos términos No pasa fueron falsas alarmas.

Mientras no haya suficientes casos medidos, di "nivel asignado por criterios,
sin precisión medida". El objetivo de entrenamiento es calibrar los rangos con
esos datos.

## 8. Ejemplo ficticio

> Documento: DPI. Términos: nombre completo (Medio, imagen legible, pág. 1,
> Revisión: otro orden respecto de los demás documentos), número (Alto, JSON,
> Pasa), fecha de vencimiento (Medio, pág. 2, Pasa), firma (Medio, pág. 1,
> Revisión: criterio humano).
> Clasificación del documento: **Revisión** (ningún término no pasa).
>
> Documento: Anexo de beneficiarios finales. Término obligatorio: Faltante.
> Clasificación del documento: **No pasa**.
> Clasificación del expediente: **No pasa**.
