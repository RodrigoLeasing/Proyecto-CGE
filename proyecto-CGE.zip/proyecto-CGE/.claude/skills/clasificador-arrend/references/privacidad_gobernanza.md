# Privacidad y gobernanza

Hay **dos niveles** de información con reglas distintas: la habilidad y los
resultados de un caso.

## 1. Lo que no se procesa

- **Información de clientes PEP o CPE.** Si el FEIC los marca, el caso se detiene
  y pasa a revisión manual.

## 2. Resoluciones del Comité de Riesgos

**Sí se procesan, con aviso.** Cuando un archivo es una resolución firmada del
Comité, avisa ("este archivo es una resolución del Comité de Riesgos") y
continúa: se lee como documento adicional, se extraen sus términos con su
confianza y no genera hallazgos de checklist, salvo que contradiga a un
documento necesario. El aviso queda en la trazabilidad.

## 3. Nivel 1: la habilidad, sus referencias, ejemplos y aprendizajes

**No** llevan:

- nombres de clientes ni de personas,
- documentos de identidad, NIT ni números de registro,
- números de expediente,
- rutas de usuario ni nombres de carpetas con datos del cliente,
- cifras reales de un cliente.

Los ejemplos usan datos ficticios. Los montos de política (impuesto, cargos
fijos, traspasos) sí pueden estar porque no identifican a nadie.

Los aprendizajes se guardan como estrategias: "cuando ocurre X, se hace Y", nunca
referidos a un cliente.

Mal: "el cliente tal tenía la escritura con tachones".
Bien: "cuando una escritura registrada trae tachones, se marca como revisión
humana".

## 4. Nivel 2: los resultados de un caso

**Sí llevan los datos del cliente.** Sin ellos no se puede decir qué dice cada
documento, qué término no pasa ni qué debe corregir Comercial.

| Resultado | Datos del cliente |
|---|---|
| Hoja de resultado (F1) | Sí: nombres, números, valores leídos y esperados |
| Lista de correcciones (F2) | Sí: lo que dice y lo que debe decir cada documento |
| Extracciones y hallazgos del caso | Sí |
| Trazabilidad del caso (F3) | Sí; vive con el caso |
| Ficha de entrenamiento (F4) | **No:** alimenta los aprendizajes |

Los resultados de un caso:
- se guardan con el caso, nunca en la habilidad ni en sus referencias;
- no se copian a los aprendizajes; si de un caso sale una estrategia, se redacta
  sin datos;
- llevan en el encabezado el nombre del caso y la fecha de revisión.

## 5. Si encuentras un dato donde no debe estar

Si un archivo **de la habilidad** trae un dato de un cliente, reporta el hallazgo
**sin repetir el dato**: archivo y línea, no el contenido. `scripts/validar_skill.py`
hace esto. Los archivos del cliente no se revisan con esa regla: son el material
de trabajo.

## 6. Puntos de gobernanza abiertos (no los des por resueltos)

1. El contenido de los expedientes viaja al proveedor de la inteligencia
   artificial.
2. No hay política de retención de sesiones.
3. Falta la confirmación formal de Sistemas y Riesgos.

Como los resultados llevan datos del cliente, estos tres puntos pesan más.
Cada entrega los recuerda en una línea y `SKILL.md` no debe afirmar lo
contrario.

## 7. Control de acceso

La copia sincronizada de la habilidad la administra claude.ai: al modificarla,
se sube completa con sus carpetas. Los cambios se registran en
`registro_componentes.md`.
