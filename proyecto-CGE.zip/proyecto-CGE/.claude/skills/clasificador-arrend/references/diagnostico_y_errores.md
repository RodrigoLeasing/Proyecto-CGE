# Diagnóstico y errores conocidos

## 1. Protocolo cuando algo falla

1. **Antes de proponer otra hipótesis,** di qué se descartó y por qué.
2. **Si fallan dos intentos seguidos de la misma categoría,** cambia de
   categoría, no de parámetro. No presentes la misma idea con otro nombre.
3. **No uses lenguaje de certeza** si la causa no está confirmada. La certeza se
   reserva para lo verificado, no para lo probado por descarte.
4. **Prueba primero lo más simple:** un documento, un requisito, un cruce.
5. **Registra cada error:** qué ocurrió, cómo se detectó, cómo se corrigió y su
   estado (definitivo, parcial o pendiente).
6. Si el error está en tu propio resultado, reconócelo, corrígelo y sigue; no te
   disculpes en exceso ni te justifiques.

Categorías de falla útiles para cambiar de categoría: lectura (el valor está
mal leído), identificación (el documento es otro), regla (la regla no aplica a
este caso), perfil (país, producto o tipo equivocado), cálculo (fórmula o base)
y datos (el documento está incompleto).

## 2. Estrategias aprendidas de lectura y revisión

Cada una es: cuando ocurre X, se hace Y.

1. Cuando un documento es largo, se leen todas sus páginas por lotes.
2. Cuando la respuesta a una pregunta de presencia (sello, firma) es "No", no se
   muestra ubicación.
3. Cuando una ubicación cae fuera de la página o no tiene tamaño, se descarta.
4. Cuando el PDF trae texto, la ubicación sale del texto; en escaneados es
   aproximada y no es prueba.
5. Cuando un campo no se puede leer, se marca ilegible y no se inventa el valor.
6. Cuando el nombre del archivo identifica el documento, manda el nombre; la
   lectura solo sugiere otro tipo.
7. Cuando un archivo dice "Respaldo", es un documento adicional.
8. Cuando un precio viene con "Q." y punto, se toma el número desde el primer
   dígito.
9. Cuando existe el JSON del FEIC, es la fuente exacta; no se pasa por la lectura.
10. Cuando el FEIC marca PEP o CPE, se detiene el caso.
11. Cuando se comparan textos, mayúsculas y espacios no son error; la puntuación
    de abreviaturas societarias sí.
12. Cuando se comparan accionistas, se comparan como lista, sin importar el
    orden y solo los de 10 % o más contra el FEIC.
13. Cuando el último cambio de estructura tiene más de 5 años, se confirma que no
    hay modificaciones posteriores.
14. Cuando el dato ancla no coincide con ningún otro documento y los demás
    coinciden entre sí, el ancla probablemente está mal leída.
15. Cuando se lee un nombre de un documento de identidad, se leen nombres y
    apellidos por separado.
16. Cuando un nombre en un buró no coincide con el documento (apellido de
    soltera o de casada), se identifica por el número del documento.
17. Cuando un informe dice "página X de Y" y faltan páginas, se pide completo.
18. Cuando falta el buró de un socio con 10 % o más y no hay documento de los
    socios para saber de quién es cada informe, se pide el faltante y la
    identificación de cada informe.
19. Cuando una escritura no trae hojas numeradas, se verifica por ordinales y
    continuidad del texto.
20. Cuando un buró dice que la empresa "no existe", se compara el número
    consultado con el registro tributario.
21. Cuando un documento trae dos números parecidos, cada campo toma el que le
    corresponde.
22. Cuando un dato de contacto difiere entre documentos, se registran ambos.
23. Cuando la cotización no indica el año del bien, se devuelve.
24. Cuando no está claro quién es el vendor, se consulta a quien ingresa a FIMS.
25. Cuando el error está en un documento de un tercero (banco, registro,
    empresa de servicios), no se le atribuye a Comercial salvo la vigencia.
26. Cuando un cliente aparece como demandante, no se pide nada.
27. Cuando aparece un dato legal que el equipo no había visto, se consulta a
    Legal y la respuesta queda como precedente.
28. Cuando la persona de la selfie no es el asesor, se devuelve salvo una nota
    que explique quién visitó y por qué.
29. Cuando la edad no coincide con la fecha de nacimiento, se revisa si el
    cumpleaños cayó entre la visita y la revisión.
30. Cuando los estados de cuenta mezclan dos cuentas, se ordenan por cuenta.
31. Cuando un formulario ya validado sirve de fuente, se usa; cuando trae
    errores, no se usa hasta que se corrija.
32. Cuando un cálculo no cuadra, se recalcula con la fórmula escrita antes de
    devolver el caso.
33. Cuando el caso es un reingreso, se compara todo contra la versión anterior.
34. Cuando los datos del perfil no coinciden con los documentos, se avisa antes
    de seguir.
35. Cuando una IA devuelve accionistas, se verifica que sean de la escritura
    correcta antes de usarlos.
36. Cuando la lectura de un término es Bajo o Ilegible, el término va a Revisión:
    no se rechaza ni se aprueba con una lectura dudosa.
37. Cuando un dato ancla leído con Medio o Bajo difiere de todos los demás
    documentos, se emite un solo hallazgo en Revisión, no una corrección por
    documento.
38. Cuando un término no pasa, el documento entero no pasa: se indica cuál término
    y con qué confianza.

Los casos de precisión de lectura, con su nivel de confianza, están en
`regla_confianza.md`, sección 6.

## 3. Registro de errores del proyecto (resumen)

| Error | Qué ocurrió | Estado |
|---|---|---|
| Nombres de documentos cambiados | La herramienta usó nombres que no eran los oficiales | Definitivo: nombres de la matriz de escaneo |
| La lectura cambiaba el tipo asignado | La IA reasignaba tipos de archivos ya clasificados | Definitivo: solo sugiere |
| Respaldos tratados como del checklist | Archivos "Respaldo" se leían como documentos del checklist | Definitivo |
| Precio con "Q." leído como decimal | Todos los cálculos daban montos mínimos | Definitivo |
| Ubicación fuera de la página | Cajas inventadas para respuestas "No" | Definitivo |
| Lectura parcial de escrituras | Solo se leían las primeras páginas | Parcial |
| País del perfil equivocado | Faltantes falsos e impuesto equivocado | Parcial |
| Archivos duplicados | Documentos y hallazgos duplicados por carga doble | Definitivo |
| Diferencias de espacios como error | Direcciones casi idénticas marcadas | Definitivo |
| Abreviaturas "S.A." contra "Sociedad Anónima" | Marcadas como error | Definitivo |
| FEIC con accionistas de 10 % o más | Salía como discrepancia contra la escritura | Definitivo |
| **Nombres de persona en otro orden** | La lectura del DPI invirtió nombres y apellidos; como es el ancla, todos los demás salieron "no coincide" | **Pendiente:** leer nombres y apellidos por separado, comparar como conjunto y aplicar la regla del dato ancla |
| Lista de correcciones partida en bloques | Límite por total de caracteres | Definitivo: un bloque y límite por línea |
| Fórmulas dentro de las líneas para Comercial | Lenguaje demasiado técnico | Definitivo: fórmula en el detalle |
| IVA calculado sin alerta | Valor imposible no se señalaba | Definitivo |
| La herramienta pierde lo cargado al actualizarse | Cada corrección obliga a cargar y leer de nuevo | Pendiente: guardar el expediente |
| Calculadora no modela variantes | Gastos financiados, seguro aparte, bien sin impuesto, híbrido exento, bien compuesto, impuesto a la primera matrícula | Pendiente |

## 4. Errores posibles y raros

| Frecuencia | Error | Cómo se detecta |
|---|---|---|
| Común | Plazo, TIR, renta inicial o gastos del Conoce a tu cliente distintos a la hoja | Cruce |
| Común | Número, fecha o año de la escritura equivocados | Cruce contra la escritura |
| Común | Nombres o apellidos incompletos | Cruce contra el DPI |
| Común | Documentos faltantes | Inventario |
| Común | Descripción del bien genérica ("vehículo") | Cruce contra la cotización |
| Posible | Firma que no se parece | Revisión humana |
| Posible | Contador distinto al del RTU | Cruce |
| Posible | Mora mayor a 60 días o demanda sin respaldo | Lectura del informe |
| Raro | IVA mal calculado en una cotización de vendor | Recalcular |
| Raro | Letras perdidas en un formato nuevo | Se consulta; no se devuelve |
| Raro | Cotización en otro idioma o moneda sin tipo de cambio | Lectura |
| Raro | Cambio no pedido en un reingreso | Comparación con la versión anterior |

La frecuencia es provisional: Guatemala tiene tres casos grabados y los demás
países, uno o dos.
