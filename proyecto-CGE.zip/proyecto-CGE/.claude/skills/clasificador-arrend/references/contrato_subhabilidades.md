# Contrato de subhabilidades

Hoy cada módulo se ejecuta como referencia desde el orquestador. Este contrato
fija las entradas y salidas para que cualquiera se pueda extraer como habilidad
independiente (`clasificador-arrend:escrituras`, por ejemplo) **sin tocar el
resto**. Un módulo que cumple el contrato se puede cambiar por una versión mejor.

## 1. Esquema de la extracción de un documento

Un archivo por documento en `extracciones/`, guardado al leerlo:

```json
{
  "documento": "dpi",
  "archivo_id": "doc-007",
  "paginas": [1, 2],
  "origen_lectura": "json|texto_pdf|imagen|transcripcion",
  "estado": "leido|ilegible|no_encontrado",
  "campos": [
    {"campo": "nombre_completo", "valor": "…", "pagina": 1,
     "confianza": "Alto|Medio|Bajo|Ilegible|Faltante",
     "puntaje": 90,
     "motivo": "",
     "fuente": "Nombre del documento, pág. 1",
     "caja": {"x": 0.1, "y": 0.2, "ancho": 0.3, "alto": 0.1},
     "nota": ""}
  ]
}
```

- La `confianza` sigue la escala de `regla_confianza.md`: Alto (95 a 100), Medio
  (85 a 94), Bajo (50 a 84), Ilegible (menos de 50) y Faltante.
- `puntaje` es opcional; si se da, debe caer en el rango del nivel. Es una
  calificación por criterios, no un acierto medido.
- `motivo` es obligatorio para Bajo e Ilegible ("imagen con sombra", "dígito
  tapado").
- `fuente` es el documento y la página, o "Sin evidencia en el expediente" cuando
  la confianza es Faltante.
- Un campo ilegible tiene `confianza: "Ilegible"` y **no** lleva valor
  inventado. Un campo que no está tiene `confianza: "Faltante"` y valor vacío.
- `caja` es opcional y aproximada cuando la ubicación viene de una lectura de
  imagen; nunca es prueba. Las respuestas "No" a una pregunta de presencia
  (sello, firma) no llevan caja.
- Los nombres de personas se extraen con `nombres` y `apellidos` por separado,
  además del nombre completo en el orden del documento.

## 2. Esquema de un hallazgo

```json
{
  "id": "h-0001",
  "regla": "GT-ESC-08",
  "modulo": 3,
  "severidad": "BLOQUEA|CORREGIR|OBSERVAR",
  "documento": "feic",
  "pagina": 2,
  "campo": "accionistas",
  "valor_encontrado": "…",
  "valor_esperado": "…",
  "documento_que_manda": "escritura",
  "texto_comercial": "FEIC: accionistas: dice …; debe decir … (según la escritura).",
  "detalle_tecnico": "…",
  "requiere_criterio_humano": false,
  "confianza": "Alto|Medio|Bajo|Ilegible|Faltante",
  "clasificacion": "No pasa|Revisión",
  "origen": "herramienta|analista",
  "alcance": "comprometido|avance",
  "decision_cge": null,
  "estado_reingreso": null
}
```

- `texto_comercial`: una línea, lenguaje simple, sin juicios sobre el asesor.
- `confianza`: la de la lectura en la que se apoya el hallazgo.
- `clasificacion`: se deriva de `severidad` y `confianza` con `regla_confianza.md`
  (BLOQUEA o CORREGIR con Alto, Medio o Faltante → No pasa; OBSERVAR, criterio
  humano o confianza Bajo o Ilegible → Revisión).
- `decision_cge`: `confirmado`, `falsa_alarma`, `bajado_a_observar` o `subido`.
- `estado_reingreso`: `corregido`, `pendiente` o `nuevo`.

## 3. Contrato común de una subhabilidad

Toda subhabilidad:
1. Recibe el perfil, el inventario y las extracciones que necesita; no relee
   documentos que otra ya leyó.
2. Califica la confianza de cada término que lee (escala de
   `regla_confianza.md`) y devuelve hallazgos con el esquema anterior, sin
   duplicar lo faltante.
3. Marca lo que requiere criterio humano; no lo decide.
4. Cita la regla de origen y la página de cada hallazgo.
5. No guarda nombres ni identificadores del cliente en sus referencias; sus
   resultados del caso sí llevan los datos del cliente.
6. Declara su alcance (comprometido o avance).

## 4. Subhabilidades

| Id | Entrada | Salida | Reglas | Referencia | Estado |
|---|---|---|---|---|---|
| SH-INV | Archivos, perfil | `inventario.json`, hallazgos GT-INV | GT-INV-* | `modulos_y_documentos.md` | Definida |
| SH-LEC | Archivos del inventario | `extracciones/*.json` con confianza y fuente por término | R-CONF | `regla_confianza.md`, `diagnostico_y_errores.md` | Definida |
| **SH-ESC** | Escrituras, anexo 5, nombramiento, DPI, RTU, FEIC | `estructura_accionaria.json`, hallazgos GT-ESC y GT-ID | GT-ESC-*, GT-ID-* | `modulo_escrituras.md` | **Prioridad 1** |
| SH-CRU | Extracciones de todos los documentos | Hallazgos GT-PER y GT-ID | GT-PER-*, GT-ID-* | `catalogo_datos_gt.md` | Definida |
| SH-BUR | Cartas e informes de buró | Hallazgos GT-BUR | GT-BUR-* | `reglas_y_severidad.md` | Definida |
| SH-FIN | Información financiera, declaraciones, estados de cuenta | Hallazgos GT-FIN y GT-CTA | GT-FIN-*, GT-CTA-* | `reglas_y_severidad.md` | Definida |
| SH-CAL | Hoja, cotización, flujo, vendor | `calculos.json`, hallazgos GT-CAL | GT-CAL-* | `calculos.md` | Definida |
| SH-NEG | Hoja, solicitud, seguro, bien | Hallazgos GT-NEG | GT-NEG-* | `reglas_y_severidad.md` | Definida |
| SH-REI | Versión anterior y versión nueva | Hallazgos GT-REI y tres listas | GT-REI-* | `modo reingreso` en `SKILL.md` | Definida |
| SH-CON | Todos los hallazgos y términos | `hallazgos.json` depurado, clasificación de términos, documentos y expediente | Regla del dato ancla, R-CONF, R-CLAS | `reglas_y_severidad.md` | Definida |
| SH-INF | `hallazgos.json`, perfil | F1 a F4 | Ninguna | `formatos_salida.md` | Definida con `render_hoja.py` |

## 5. Cómo extraer un módulo como habilidad propia

1. Crea la carpeta con su `SKILL.md` (frontmatter con nombre y descripción) y las
   referencias que usa.
2. Copia en su `SKILL.md` solo: entradas, salidas del contrato, reglas y límites.
3. En el orquestador, cambia la fila de la sección 11 del `SKILL.md` para
   enrutar a la habilidad.
4. Ejecuta `casos_prueba.md` contra la versión nueva y compara los resultados.
5. Registra la versión en `registro_componentes.md`.

## 6. Orden de construcción propuesto

1. SH-ESC (comprometido).
2. SH-LEC con lectura de nombres separados y regla del dato ancla.
3. SH-CRU con el catálogo de datos.
4. SH-REI, porque el reingreso es lo que más se repite.
5. SH-BUR, SH-FIN, SH-CAL y SH-NEG.
