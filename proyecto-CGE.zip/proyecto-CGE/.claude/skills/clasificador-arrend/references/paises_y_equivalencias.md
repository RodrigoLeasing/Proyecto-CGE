# Países y equivalencias (referencia; solo Guatemala tiene checklist activo)

**Regla:** si el caso no es de Guatemala, no apliques el checklist de Guatemala.
Di "checklist no cargado: revisión manual" y haz solo los cruces entre
documentos. Esta referencia sirve para entender los documentos de otros países,
no para aplicar reglas. Cada país tiene detrás un solo caso grabado, salvo
Guatemala y El Salvador, así que su conocimiento es provisional.

Nicaragua: CGE no opera ahí (el checklist existe pero no hay revisiones).

## 1. Equivalencias de documentos

| Función | Guatemala | El Salvador | Honduras | Panamá | Costa Rica | República Dominicana |
|---|---|---|---|---|---|---|
| Registro tributario de la empresa | RTU | NIT y tarjeta de IVA | RTN | RUC (con dígito verificador) | Cédula jurídica | RNC |
| Identificación de la persona | DPI | DUI | DNI / IDEH | Cédula | Cédula / DIMEX | Cédula |
| Documento de la empresa | Patentes de comercio y de sociedad | Matrícula (anual) | Permiso de operaciones | Aviso de operaciones | Patente o permiso de salud o sanitario | Registro mercantil |
| Escritura | Escritura | Escritura | Escritura (incluye nombramiento) | Pacto social (constitución) | Personería jurídica | Estatutos sociales |
| Nombramiento | Nombramiento | Credencial | Dentro de la escritura | Personería jurídica, poder o acta | Personería jurídica | Órganos de gestión del registro mercantil |
| Socios | Escritura o carta accionaria | F-915 o carta accionaria | Última escritura | Declaración jurada o personería | Declaración jurada | Registro mercantil y asambleas |
| Buró | Infornet y TransUnion | Infored y Equifax | Infornet y TransUnion (sin carta de buró) | APC | Credid | TransUnion |
| Autorización de consulta | Carta de buró | Carta de buró | No aplica | Carta de buró | Autorización SUGEF y Credid | Carta de buró |
| Dirección | Recibo | Recibo | Recibo (el checklist menciona el permiso) | Aviso de operaciones | Informe de visita | Recibo; si no trae dirección, registro mercantil |
| Declaraciones | IVA e ISR | 3 mensuales | Una anual | Anuales | Anual (utilidades) | DGII (puede no exigirse) |
| FEIC | Sí | No | No | No | No | No |
| Impuesto | IVA 12 % | IVA 13 % | ISV 15 % | ITBMS 7 % | IVA 13 % | ITBIS 18 % |
| Moneda | Quetzales y dólares | Dólares | Lempiras | Balboas = dólares | Colones y dólares | Dólares |
| Estado patrimonial | Sí (persona individual) | Sí | No | No | No (orden patronal) | — |

## 2. Particularidades por país

**El Salvador.** Todo en mayúsculas. Los socios que son empresas exigen anexo 5.
El impuesto a la primera matrícula y las placas se separan del bien. Gasto
inicial mínimo. Credencial sin plazo: representación indefinida; la fecha que
vale es la del registro de comercio. Beneficiarios de países donde ARREND no
opera: no se piden sus burós. La capacidad de pago, ponderación y saldos
promedio del checklist ya no se usan.

**Honduras.** Sin FEIC ni carta de buró. Escrituras largas y dispersas; manda la
última. Seguro endosado frecuente. Cuatro vueltas de correcciones observadas en
un caso.

**Panamá.** El aviso de operaciones trae dos números distintos (RUC y número de
aviso). La fecha de constitución sale del pacto social. Formulario de debida
diligencia por negocio. Se trabaja sobre el total con impuesto.

**Costa Rica.** Sin recibo. El bien se cotiza sin impuesto. Gastos iniciales
siempre financiados. 4x2 o 4x4 y combustible definen el tipo en el checklist de
seguro. Deudor mancomunado nunca vacío ("No aplica"). Recibe más personas
individuales que empresas. El checklist recibido tiene notas de edición sin
aplicar.

**República Dominicana.** Criterios acordados con Legal. Representación
indefinida. Conoce a tu cliente sin visita, con visto bueno de Riesgos. Cédulas
de 2023 y 2024 vencidas se aceptan por comunicado oficial. Propuesta en lugar de
cotización Arrend. Solo se ofrecen leasing financiero y operativo, en dólares.

## 3. Montos de política (por confirmar con CGE)

| País | Cargo de dispositivo y GPS | GPS mensual | Traspaso con opción de compra |
|---|---|---|---|
| Guatemala | 1,386.00 sin IVA (1,552.32 con IVA); 180 dólares | 139.00 | 1,835.00 |
| Honduras | 4,950.00 sin impuesto (5,692.50 con impuesto) | 486.00 | L2,875 o 115 dólares |
| El Salvador | 180 dólares sin IVA (145 dispositivo y 35 instalación); mínimo 250 más 180 | 18 dólares | 113 dólares por negocio |
| Panamá | Por confirmar | 18 dólares (19.26 con impuesto) | 171.20 dólares |
| Costa Rica | 180 dólares (105,768 colones con impuesto, según la guía de CGE) | 18 dólares | Sin costo fijo |
| República Dominicana | Por confirmar | Por confirmar | Sin costo fijo |

En la tabla de impuestos de la guía de CGE, las monedas de Costa Rica y Panamá
aparecen intercambiadas: no la tomes como fuente de moneda.

## 4. Relación con `digitador-arrend`

| Tema | `clasificador-arrend` | `digitador-arrend` |
|---|---|---|
| Propósito | Forma, completitud y coincidencia | Vaciado y política de crédito |
| Fuente de las condiciones | Hoja de negociación | Cotización Arrend para los montos |
| Tipo de cambio | Solo verifica la moneda | Obligatorio en el vaciado |
| Buró por país | Registra qué buró corresponde | Define en qué fila va cada buró |

Los dos coinciden en: no aplicar reglas de Guatemala a otro país, guardar cada
extracción en disco, leer las casillas solo en imagen, detectar siempre el aval,
usar la versión firmada o la más reciente cuando hay dos, y que la renta con
impuestos es (renta + seguro + GPS) × (1 + impuesto del país).
