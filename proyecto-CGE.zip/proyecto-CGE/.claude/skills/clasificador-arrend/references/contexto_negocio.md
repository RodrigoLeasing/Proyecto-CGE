# Contexto de negocio

## 1. Quién es quién

- **ARREND:** arrendadora con operación regional (Guatemala, El Salvador,
  Honduras, Nicaragua, Costa Rica, Panamá y República Dominicana). Ofrece
  leasing financiero, operativo y otros productos.
- **CGE (Centro de Gestión de Expedientes):** revisa la forma de cada
  expediente antes de que pase a Riesgos y a FIMS. Valida que los documentos
  estén, sean legibles y vigentes, y que los datos coincidan entre sí. **No
  analiza cifras ni decide el crédito.**
- **Comercial:** asesores y back office que arman y corrigen el expediente.
- **Riesgos:** analiza capacidad de pago y decide con los comités. También lee
  estatutos, socios y beneficiarios finales.
- **Legal:** responde las dudas de documentos legales; sus respuestas se
  guardan como precedentes.
- **Encargado de revisión (CGE):** resuelve los cálculos que no cuadran.
- **Sistemas y BI:** dueños de la plataforma de automatización.

## 2. Flujo de un ticket

1. Comercial sube los documentos a SharePoint, por país y cliente.
2. Llega un ticket en Hive; se asigna al revisor.
3. El revisor descarga cliente y negocio, crea la carpeta de trabajo (cliente,
   año, mes y las carpetas del expediente madre y del negocio en Escáner Ventas)
   y renombra cada archivo con el número del orden de escaneo.
4. Revisa el expediente madre y después el negocio; los cálculos van al final.
5. Si hay errores, los registra en el ticket (una subtarea por error) y lo
   devuelve a Comercial.
6. Al regresar, el revisor compara contra la versión anterior para confirmar que
   no cambió nada más.
7. Si todo está bien, el caso pasa a Recepción FIMS (cotizador manual) o a
   Recepción FLOW (cotización web). Los casos de Junta Directiva se ingresan a
   FIMS solo después de aprobarse y vuelven a CGE para una última revisión.

## 3. Sistemas

Hive (tickets), SharePoint (carpetas de ventas), Escáner Ventas (carpetas de
trabajo; lenta desde fuera de la oficina), FIMS (registro final), FLOW
(cotizador web).

## 4. Dónde se pierde el tiempo (observado)

| Causa | Efecto |
|---|---|
| Comercial sube sin orden ni nombres estándar | Ordenar, renombrar y unir archivos |
| Expedientes incompletos | Varias vueltas |
| Corregir lo pedido y romper otra cosa | Reprocesos de hasta 4 a 8 vueltas |
| Escrituras largas, revueltas o sin numeración | Lectura de hasta 180 páginas |
| Cada analista usa su formato de notas | No se puede medir |
| Cálculos manuales | Alarmas falsas |

## 5. Tiempos y volumen declarados

- Persona jurídica con un negocio: alrededor de 2 horas 30 minutos en
  Guatemala; entre 1.5 y 2 horas en otros países; cada negocio adicional, entre
  20 y 25 minutos.
- Un revisor atendió 108 negocios en un mes.
- Línea base reportada en la reunión del prototipo: en un mes, 327 expedientes
  y 410 inconsistencias. Falta el tiempo promedio por expediente.
- Guatemala concentra cerca del 75 % de los casos.
- Respuesta de Comercial a una devolución: de una hora a un día; en el peor caso
  una semana, o semanas si el cliente no entrega el documento.

## 6. Cliente nuevo y de cartera

Cliente nuevo: menos de un año con ARREND. Desde el año cumplido es de cartera,
aunque no haya tenido más negocios. Los clientes corporativos (multinacionales,
ingenios, flotillas) tienen un checklist regional propio sin información
financiera, estados de cuenta, declaraciones ni beneficiarios finales; si
cotizan en bolsa, tampoco FEIC.

## 7. Qué no es CGE

No concede ni niega crédito, no interpreta cifras financieras, no decide si una
firma es auténtica y no reemplaza la revisión de Legal ni de Riesgos.
