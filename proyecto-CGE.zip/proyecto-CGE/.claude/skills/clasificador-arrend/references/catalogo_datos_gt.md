# Catálogo de datos: qué documento manda (Guatemala, persona jurídica)

Cada dato tiene **un** documento que manda. Los demás documentos se comparan
contra él. Si el documento que manda no está o es ilegible, el dato queda sin
verificar y se dice así; no se promueve a otro documento por conveniencia.

| Dato | Documento que manda | Se cruza contra | Cómo se compara |
|---|---|---|---|
| Razón social | `patente_sociedad` | FEIC, Conoce a tu cliente, solicitud, cotización, estados financieros, declaraciones, estados de cuenta, buró | Idéntica; "S.A." con puntos equivale a "Sociedad Anónima"; "SA" sin puntos se corrige |
| Nombre comercial | `patente_comercio` | FEIC, Conoce a tu cliente, solicitud | Idéntico |
| NIT de la empresa | `rtu_empresa` (vigencia de 12 meses) | FEIC, solicitud, declaraciones, estados financieros, carta de buró | Mismos dígitos |
| Actividad económica | `rtu_empresa` | FEIC, Conoce a tu cliente | Textual en el FEIC; en el Conoce a tu cliente basta que tenga relación |
| Contador | `rtu_empresa` | Estados financieros | Nombre y NIT; su firma no se valida |
| Dirección | `recibo` (emisión de 2 meses o menos) | FEIC, Conoce a tu cliente, solicitud, checklist de seguro | Idéntica, hasta los paréntesis |
| Nombre, número, nacimiento, estado civil, nacionalidad del representante | `dpi` vigente | FEIC, Conoce a tu cliente, nombramiento, solicitud, carta de buró | Nombre idéntico; estado civil según el DPI |
| NIT del representante | `rtu_representante` | FEIC | Mismos dígitos |
| Cargo, plazo y vencimiento de la representación; registro, folio y libro | `nombramiento` | FEIC, Conoce a tu cliente, solicitud | Vencimiento = fecha inicial más el plazo |
| Número, fecha y notario de la escritura; fecha de inscripción | `escritura` (primera hoja) | FEIC, solicitud | Mismos datos; las mayúsculas no importan si el nombre está bien escrito |
| Registro, folio y libro de la sociedad | `patente_sociedad` | FEIC | Mismos dígitos |
| Accionistas y porcentajes | `escritura` y `escritura_mod` si son personas; `anexo5` si son empresas | FEIC (solo 10 % o más), Conoce a tu cliente, solicitud | Mismos nombres; porcentaje = acciones de cada uno entre el total |
| Beneficiarios finales | `anexo5` | Conoce a tu cliente | Hasta llegar a personas individuales |
| Bien: tipo, marca, línea, año | `tarjeta_circulacion` en usados; `cotizacion_vendor` en nuevos | Hoja, Conoce a tu cliente, solicitud, cotización, flujo, checklist de seguro | Idéntico; debe describir el bien completo |
| Renta inicial, plazo, TIR, opción de compra, gastos iniciales, moneda | `hoja_negociacion` | Conoce a tu cliente, solicitud, cotización, flujo | Mismo número; si la TIR difiere del flujo, se corrige la hoja |
| Precio | `cotizacion_vendor` | FEIC, Conoce a tu cliente, solicitud, cotización | Mismo monto |
| Monto solicitado | `cotizacion_vendor` (total) | Solicitud | Mismo monto, aunque la diferencia sea de un centavo |
| Vendor y ejecutivo vendor | `cotizacion_vendor` | Hoja, Conoce a tu cliente, solicitud, cotización | Idéntico; la certificación es humana |
| Asesor | `hoja_negociacion` | Todos los documentos del negocio y el Conoce a tu cliente | El mismo en todos; si otro hizo la visita, nota que lo explique |
| Número de cotización | `cotizacion_arrend` | Flujo | Idéntico |
| Código de producto | `feic` (identificador) | Hoja | Debe corresponder al producto y a la moneda |

## Reglas de comparación

1. **Nombres de personas:** compara nombres y apellidos por separado y como
   conjunto de palabras. Las mismas palabras en otro orden no son un error de
   Comercial: es **OBSERVAR** y puede ser una lectura invertida.
2. **Mayúsculas y tildes:** no son error por sí solas. La puntuación de las
   abreviaturas societarias sí.
3. **Espacios de más o de menos:** no son error cuando solo cambian espacios
   entre palabras; un espacio dentro de un nombre (una letra separada) sí.
4. **Teléfonos:** 8 dígitos. **Correos:** bien escritos; no se validan contra
   otro documento. Si difieren entre documentos, se registran ambos.
5. **Edad:** año actual menos año de nacimiento. Diferencia de un año por
   cumpleaños reciente: **OBSERVAR**. Más de un año: **CORREGIR**.
6. **Montos:** compáralos sin símbolo de moneda ni separadores. Un precio escrito
   con "Q." no es un decimal.
7. **Dato ancla:** si el ancla difiere de todos los demás documentos y estos
   coinciden entre sí, no emitas una corrección por documento (principio 5 del
   `SKILL.md`).
8. **Cadena de accionistas:** una sociedad nunca queda como dueño final.
