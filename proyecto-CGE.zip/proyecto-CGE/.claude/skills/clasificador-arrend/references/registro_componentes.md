# Registro de componentes (versión 0.2, 19-nov-2026)

Fuente única de los identificadores del clasificador. Si un id cambia, cambia
aquí primero. Los nombres oficiales de los documentos salen del Excel de orden
de documentación para ingreso a Escáner Ventas (Guatemala, persona jurídica) y
**no se cambian sin justificación escrita**. La lista oficial por país sigue
pendiente de confirmar con CGE.

## 1. Documentos

| Id | Nombre oficial | Módulo | Es ancla de |
|---|---|---|---|
| `info_financiera` | Información financiera | 4 | periodos, firmas, contador |
| `declaraciones` | Declaraciones de impuestos | 4 | periodos |
| `feic` | FEIC | 2 | ninguno: se valida contra las anclas |
| `feic_json` | Archivo JSON del FEIC | 2 | fuente exacta de los campos del FEIC |
| `conoce_cliente` | Formulario Conoce a tu cliente | 2 | se valida contra las anclas y la hoja |
| `estados_cuenta` | Estados de cuenta | 6 | titular, cuenta, periodos |
| `carta_buro` | Carta de buró | 5 | autorización del cliente |
| `infornet` | Infornet | 5 | mora y demandas |
| `transunion` | TransUnion | 5 | mora y demandas |
| `dpi` | DPI / pasaporte del R.L. | 3 | nombre, número, nacimiento, estado civil, nacionalidad |
| `patente_comercio` | Patente de comercio | 2 | nombre comercial |
| `patente_sociedad` | Patente de sociedad | 2 | razón social, registro, folio y libro |
| `escritura` | Escritura (constitución) | 3 | número, fecha, notario, accionistas iniciales |
| `escritura_mod` | Escritura: modificaciones | 3 | cambios de capital, socios, nombre |
| `carta_accionaria` | Carta accionaria | 3 | accionistas cuando cambiaron |
| `anexo5` | Anexo de beneficiarios finales | 3 | estructura vigente si un socio es empresa |
| `nombramiento` | Nombramiento | 3 | cargo, plazo, registro, folio y libro |
| `rtu_empresa` | RTU de la empresa | 2 | NIT, actividad, contador |
| `rtu_representante` | RTU del representante | 3 | NIT del representante |
| `recibo` | Recibo de servicios | 2 | dirección |
| `hoja_negociacion` | Hoja de negociación | 1 | condiciones del negocio |
| `solicitud_credito` | Solicitud de crédito | 1 | se valida contra las anclas |
| `solicitud_aval` | Solicitud de crédito del aval | 7 | se valida contra las anclas del aval |
| `checklist_seguro` | Checklist de seguro | 1 | uso, usuario |
| `mejora_seguro` | Mejora de seguro | 1 | cuota de seguro |
| `cotizacion_arrend` | Cotización Arrend | 1 | cuotas, renta inicial |
| `flujo` | Flujo | 1 | TIR, opción de compra |
| `cotizacion_vendor` | Cotización vendor | 1 | bien, precio, vendor |
| `avaluo` | Avalúo | 1 | usados |
| `tarjeta_circulacion` | Tarjeta de circulación o título | 1 | bien usado |
| `visto_bueno` | Visto bueno o memo | 1 | excepciones |
| `respaldo` | Respaldo | — | documento adicional, no del checklist |

## 2. Módulos

| N.° | Módulo | Alcance | Equivale en Riesgos |
|---|---|---|---|
| 1 | Objeto de financiamiento | Avance | 1. Objeto financiamiento |
| 2 | Perfil del cliente | Avance | 2. Perfil del cliente |
| 3 | Representación y estructura accionaria | **Comprometido** | 2. Perfil del cliente |
| 4 | Información financiera | Avance | 5. Estados Financieros |
| 5 | Burós | Avance | 6. Burós |
| 6 | Estados de cuenta | Avance | 7. Capacidad de pago |
| 7 | Aval o beneficiario fiscal | Avance | dentro del perfil y la capacidad de pago |

## 3. Productos

Códigos que trae el FEIC: LFNLQ y LFNLD (leasing financiero en quetzales o
dólares), LOPQ y LOPD (operativo), LBKQ y LBKD (leaseback), LFMBQ y LFMBD
(inmobiliario), PNLQ y PNLD (prendario), FNLQ y FNLD (fiduciario), FB2BQ y
FB2BD (fiduciario back to back), DFCRQ (factoraje con recurso). Otros órdenes
de documentos por producto: Arrendautos (prendario), crédito express, crédito
puente, cambio de beneficio fiscal.

## 4. Subhabilidades

| Id | Nombre | Estado |
|---|---|---|
| SH-INV | Inventario y clasificación | Definida; se ejecuta desde `modulos_y_documentos.md` |
| SH-LEC | Lectura y extracción | Definida; lectura con IA en la herramienta pre alfa |
| SH-ESC | Escrituras y estructura accionaria | **Prioridad 1**; se ejecuta desde `modulo_escrituras.md` |
| SH-CRU | Cruces entre documentos | Definida; existe en la herramienta pre alfa |
| SH-BUR | Burós | Definida |
| SH-FIN | Información financiera y estados de cuenta | Definida |
| SH-CAL | Cálculos | Definida; existe en la herramienta pre alfa |
| SH-NEG | Negocio (hoja, solicitud, seguro, bien) | Definida |
| SH-REI | Reingresos | Definida; sin herramienta todavía |
| SH-CON | Consolidación, severidad y clasificación (Pasa, No pasa, Revisión) | Definida |
| SH-INF | Informe y formatos | Definida; `scripts/render_hoja.py` |

## 5. Referencias

| Archivo | Cuándo se lee |
|---|---|
| `contexto_negocio.md` | Al empezar un caso o ante dudas del proceso |
| `regla_confianza.md` | Siempre que se lee un término o se clasifica |
| `modulos_y_documentos.md` | Al inventariar |
| `modulo_escrituras.md` | Módulo 3 |
| `catalogo_datos_gt.md` | Cruces |
| `reglas_y_severidad.md` | Hallazgos |
| `calculos.md` | Cálculos |
| `criterio_humano.md` | Dudas sobre qué decide una persona |
| `paises_y_equivalencias.md` | Casos de otros países |
| `formatos_salida.md` | Entrega |
| `contrato_subhabilidades.md` | Esquemas de datos y extracción de módulos |
| `diagnostico_y_errores.md` | Fallas |
| `privacidad_gobernanza.md` | Datos sensibles |
| `casos_prueba.md` | Comprobaciones |

## 6. Formatos de salida

| Id | Formato | Dónde |
|---|---|---|
| F1 | Hoja de resultado del expediente | `formatos_salida.md`, `assets/plantilla_hoja_resultado.md` |
| F2 | Lista de correcciones para el ticket | `formatos_salida.md` |
| F3 | Trazabilidad del caso | `formatos_salida.md` |
| F4 | Ficha de entrenamiento | `formatos_salida.md` |

## 6.1 Reglas transversales

No son módulos ni apartados: se aplican a todos los módulos.

| Id | Regla | Archivo |
|---|---|---|
| R-CONF | Escala de confianza de cinco niveles y fuente de cada término | `regla_confianza.md` |
| R-CLAS | Clasificación Pasa, No pasa o Revisión de término, documento y expediente | `regla_confianza.md` |

## 7. Historial de versiones

| Versión | Fecha | Cambio |
|---|---|---|
| 0.1 | 2026-11-19 | Primera versión del orquestador |
| 0.2 | 2026-11-19 | La herramienta clasifica (Pasa, No pasa, Revisión) y rechaza lo que no cumple; regla transversal de confianza con escala de cinco niveles; las resoluciones del Comité se procesan con aviso; los resultados del caso llevan datos del cliente |

## 8. Pendientes de confirmación con CGE

1. Lista oficial de nombres de documentos por país.
2. Versión y vigencia de cada checklist.
3. Los tres puntos de gobernanza abiertos.
4. Rango de "Ilegible": se interpretó como menos de 50 (se había escrito "mayor o igual a 50", que se solapa con Bajo).
5. Clasificación del expediente derivada de la de sus documentos (algún documento no pasa → no pasa).
6. PEP y CPE: siguen deteniendo el caso (no se cambió); las resoluciones del Comité sí se procesan.
7. Las Instrucciones del proyecto (secciones 3, 4 y 5) todavía describen una herramienta que no clasifica y que no procesa las resoluciones del Comité: hay que actualizarlas.
