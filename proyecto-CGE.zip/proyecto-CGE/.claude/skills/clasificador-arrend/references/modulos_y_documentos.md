# Módulos y documentos: necesarios, según el caso y no necesarios

Base: Guatemala, persona jurídica. Sirve para el inventario (fase 2) y para que
ningún módulo pida un documento que no necesita.

- **Necesario:** sin él el módulo no se puede revisar; si falta, el caso no pasa.
- **Según el caso:** solo se pide si se cumple la condición.
- **No necesario:** no se pide. Si llega, se guarda como respaldo y no genera
  hallazgos, salvo que contradiga a un documento necesario.

La lista de "no necesarios" sale de lo que dijeron los analistas en las
grabaciones. **Antes de dejar de pedir algo con ella, la aprueban los jefes de
CGE.**

## Módulo 1. Objeto de financiamiento (avance)

| Necesario | Según el caso | No necesario |
|---|---|---|
| Hoja de negociación | Mejora de seguro con el correo de Seguros: si el seguro es mejorado | Capacidad de pago, ponderación y saldos promedio (El Salvador): ya no se usan |
| Solicitud de crédito (firmada en clientes nuevos) | Licencia de conducir: si aplica | Propuesta Arrend en leasing financiero de Costa Rica: ya no se exige |
| Checklist de seguro | Avalúo, tarjeta de circulación o título, consulta de multas e impuesto de circulación: en usados (la consulta de multas no aplica si el activo es de ARREND) | Flujo de efectivo u otros anexos del vendor |
| Cotización Arrend | Visto bueno o memo: usados, vehículo sin GPS, precio distinto al avalúo | Imágenes o catálogos del bien |
| Flujo | Anexo del bien compuesto, firmado: varios artículos, blindaje o accesorios | Correos sin archivo adjunto |
| Cotización vendor o proforma, una por cada parte del bien | Tipo de cambio: cotización en otra moneda | |
| | Análisis individual: solo persona individual | |
| | Nota de seguro endosado: si no hay seguro con ARREND | |

Leasing operativo: propuesta Arrend en lugar de cotización Arrend; flujo firmado
por asesor y gerente de operativo; visto bueno por combustible de proveedores si
aplica.

## Módulo 2. Perfil del cliente (avance)

| Necesario | Según el caso | No necesario |
|---|---|---|
| FEIC, con su archivo JSON | Segundo recibo: si la planta está en otra dirección | Constancias de actividad |
| Formulario Conoce a tu cliente, con fotos, selfie del asesor y firmas | Nota de quién hizo la visita: si no fue el asesor | Folletos o presentaciones de la empresa |
| Patente de comercio | | Sellos o comprobantes de pago de trámites |
| Patente de sociedad | | |
| RTU de la empresa | | |
| Recibo de servicios (2 meses o menos) | | |

## Módulo 3. Representación y estructura accionaria (comprometido)

| Necesario | Según el caso | No necesario |
|---|---|---|
| DPI o pasaporte del representante, vigente | Modificaciones de la escritura: si las hubo | DPI o cédulas de los socios |
| Nombramiento vigente | Carta accionaria: si cambiaron los accionistas | Actas que no cambian socios ni representante |
| RTU del representante | Anexo 5 de beneficiarios finales: si algún accionista es una empresa | Poderes de personas que no firman este negocio |
| Escritura de constitución, completa | | |

## Módulo 4. Información financiera (avance)

| Necesario | Según el caso | No necesario |
|---|---|---|
| Balance general y estado de resultados de dos años cerrados al 31 de diciembre | Dictamen del auditor: si son auditados | Integraciones de los años cerrados |
| Parcial del año en curso, con integraciones | Declaraciones: se eximen en clientes de cartera según el plazo que confirme CGE | Flujo de efectivo y estados adicionales |
| Declaraciones: tres meses de IVA e ISR trimestral | Años anteriores a la existencia de la empresa: no se piden | Información financiera del representante o de los socios |

Clientes corporativos: no se pide este módulo.

## Módulo 5. Burós (avance)

| Necesario | Según el caso | No necesario |
|---|---|---|
| Carta de buró firmada, con lugar y fecha | Finiquito o constancia de pago: mora de más de 60 días | Informes de socios con menos de 10 % |
| Infornet y TransUnion de la sociedad | Desistimiento: demanda ejecutiva o sumaria como demandado | Cartas de buró adicionales de socios |
| Infornet y TransUnion del representante | Visto bueno de la Gerencia de Riesgos: si no hay respaldo | Demandas donde el cliente es el demandante |
| Infornet y TransUnion de cada socio con 10 % o más | | Moras de telecomunicaciones o servicios |

## Módulo 6. Estados de cuenta (avance)

| Necesario | Según el caso | No necesario |
|---|---|---|
| Últimos tres meses cerrados anteriores al ingreso | Firma y sello del banco: si se emiten en agencia | Meses anteriores a los tres pedidos |
| | Series separadas por cuenta: si hay varias | Estados de cuenta del representante o de los socios |

Clientes corporativos: no se pide este módulo.

## Módulo 7. Aval o beneficiario fiscal (avance)

| Figura | Necesario | No necesario |
|---|---|---|
| Aval | Módulos 2 a 6 completos del aval y su solicitud de crédito de aval | Nada se omite; por confirmar si debe traer Conoce a tu cliente |
| Beneficiario fiscal | Módulos 2, 3 y 5 y el memo o solicitud de cambio si aplica | Información financiera, declaraciones, estados de cuenta y Conoce a tu cliente |

El beneficiario fiscal debe ser del mismo país; el aval puede ser de otro.

## Otros tipos de cliente (Guatemala)

| Tipo | Documentos |
|---|---|
| Persona individual en relación de dependencia | FEIC, estado patrimonial, DPI, constancia de ingresos, estados de cuenta, carta de buró e Infornet - TransUnion, RTU, recibo de servicios, formulario Conoce a tu cliente |
| Persona individual con servicios profesionales | FEIC, estado patrimonial, declaraciones, DPI, certificación de ingresos, estados de cuenta, buró, RTU, recibo, Conoce a tu cliente |
| Empresa individual | FEIC, estado patrimonial, declaraciones, DPI, certificación de ingresos, información financiera (si aplica), estados de cuenta, buró, patente de comercio, RTU, recibo, Conoce a tu cliente |
| Copropiedad | Información financiera o estados patrimoniales de cada copropietario, declaraciones, FEIC de la copropiedad y de cada copropietario |

## Orden de escaneo de la persona jurídica (Guatemala)

1 información financiera; 1.2 declaraciones; 2 FEIC (2.1 su archivo JSON);
3 Conoce a tu cliente; 5 estados de cuenta; 6 carta de buró e Infornet -
TransUnion; 7 DPI / pasaporte del R.L.; 8 patente de comercio; 9 patente de
sociedad; 10 escritura (10.1 carta accionaria; 10.2 anexo de beneficiarios;
10.3 otro); 11 nombramiento; 12 RTU; 13 recibo.

Negocio de leasing financiero: 1 hoja de negociación; 2 solicitud de crédito
para firmar; 3 checklist de seguro; 3.1 licencia; 4 mejora de seguro; 5
cotización Arrend; 6 flujo; 7 cotización vendor. Usado: se agrega 7 avalúo,
factura o memo de activo y 8 visto bueno del vehículo (no aplica con memo de
venta).
