# Casos de prueba (datos ficticios)

Sirven para comprobar el orquestador y cada módulo antes y después de un cambio.
Todos los nombres, números y montos son inventados. Cada caso dice qué debe
pasar; si el resultado difiere, hay un error que registrar.

## C1. Estructura vigente que no sale de la constitución

**Entrada:** constitución con dos socios personas, 100 acciones cada uno (200 en
total). Una modificación cede 199 acciones a una sociedad. El expediente trae el
anexo 5 con dos personas como beneficiarias finales (99 % y 1 %). El FEIC lista
a las dos personas del anexo.

**Debe pasar:** la fuente de la estructura vigente es `anexo5`; accionistas con
99 % y 1 %; el FEIC compara solo al de 99 % (10 % o más) y coincide; sin hallazgo
de GT-ESC-08.

**No debe pasar:** que la estructura salga 50 % y 50 %.

## C2. Falta el anexo 5

**Entrada:** igual que C1, sin anexo 5.

**Debe pasar:** hallazgo GT-ESC-07 (CORREGIR) y la estructura vigente marcada
como no verificable; no se inventa un desglose.

## C3. Dato ancla mal leído

**Entrada:** el DPI se lee como "Apellido1 Apellido2 Nombre1 Nombre2" y los
otros cinco documentos traen "Nombre1 Nombre2 Apellido1 Apellido2".

**Debe pasar:** un solo hallazgo OBSERVAR GT-ID-04 ("mismas palabras en otro
orden, posible lectura invertida del dato ancla") y **ninguna** corrección de
GT-ID-03 por documento.

## C4. Escritura de otra sociedad

**Entrada:** el expediente trae dos escrituras; una es de otra razón social.

**Debe pasar:** la escritura ajena no se usa para la estructura; hallazgo
GT-INV-03 o GT-ESC-17 según el caso; la línea de tiempo solo trae la correcta.

## C5. Escritura sin numeración con una hoja faltante

**Entrada:** 40 cláusulas, falta la "vigésima segunda".

**Debe pasar:** GT-ESC-01 con el texto "falta la hoja entre la vigésima primera y
la vigésima tercera"; el módulo no calcula porcentajes como definitivos.

## C6. Porcentaje por redondeo

**Entrada:** 4,999 y 1 acciones; el FEIC dice 99 % y 1 %.

**Debe pasar:** GT-ESC-05 (OBSERVAR) o ningún hallazgo; nunca CORREGIR.

## C7. Reingreso con un cambio no pedido

**Entrada:** versión anterior con una corrección pedida (número de escritura) y
una versión nueva que la corrige pero cambia el teléfono de cobros.

**Debe pasar:** tres listas: corregido (número de escritura), pendiente (vacía) y
nuevo (GT-REI-01, OBSERVAR: el asesor confirma si el teléfono es nuevo).

## C8. Vehículo híbrido con blindaje

**Entrada:** precio del vehículo híbrido 360,000.00; blindaje con IVA 250,000.00;
renta inicial de 5 % de cada parte.

**Debe pasar:** el vehículo no se divide entre 1.12; el blindaje sí (223,214.29);
el blindaje no lleva opción de compra; el flujo consolidado suma ambos.

## C9. Mora en el buró

**Entrada:** una mora de 90 días sin respaldo.

**Debe pasar:** GT-BUR-04 BLOQUEA con el texto fijo "requiere desistimiento,
finiquito o constancia de pago, o visto bueno de la Gerencia de Riesgos".

## C10. Compuerta

**Entrada:** el JSON del FEIC trae persona expuesta políticamente = sí.

**Debe pasar:** el caso se detiene; no se lee ningún otro documento; la entrega
dice "revisión manual".

## C11. Perfil que no coincide

**Entrada:** perfil "Guatemala", documentos de El Salvador (DUI y matrícula).

**Debe pasar:** aviso antes de revisar; sin checklist aplicado; solo cruces.

## C12. Datos del cliente en la habilidad

**Entrada:** se pide guardar el resultado de un caso real (nombres, números) dentro
de la habilidad o de una referencia.

**Debe pasar:** no se guarda ahí. Se ofrece guardar la estrategia sin datos. El
resultado del caso sí lleva los datos del cliente y se guarda con el caso.

## C13. Resolución del Comité de Riesgos

**Entrada:** un archivo es una resolución firmada del Comité de Riesgos.

**Debe pasar:** la herramienta avisa que lo es y **lo procesa**: lo lee como
documento adicional, extrae sus términos con su confianza y no genera hallazgos
de checklist. El aviso queda en la trazabilidad.

**No debe pasar:** que se niegue a leerlo.

## C14. Lectura dudosa no se rechaza

**Entrada:** el número de escritura del FEIC dice 5; en la escritura, escaneada
con sombra, se lee un dígito que podría ser 5 o 6.

**Debe pasar:** el término de la escritura es **Bajo**; la clasificación es
**Revisión**, no No pasa ni Pasa; se muestra el recorte y el motivo.

## C15. Un término que no pasa, el documento no pasa

**Entrada:** un FEIC con 25 términos que pasan y uno con diferencia clara, leído
con confianza Alto.

**Debe pasar:** el término es No pasa; el **documento entero es No pasa**; la hoja
indica cuál término y con qué confianza; el expediente es No pasa.

## C16. Ilegible no es faltante

**Entrada:** dos documentos: uno que existe pero con los dígitos del número
tapados, y un anexo que no está.

**Debe pasar:** el primero tiene confianza Ilegible y clasificación Revisión; el
segundo, Faltante ("Sin evidencia en el expediente") y No pasa. Cada uno se
menciona una sola vez.

## C17. Clasificación del expediente

**Entrada:** cinco documentos: tres Pasa, uno Revisión, uno sin términos que no
pasan.

**Debe pasar:** el expediente es **Revisión**. Si uno de los cinco es No pasa, el
expediente es **No pasa**. Si todos Pasa, **Pasa**.

## C18. Escala de confianza

**Entrada:** un valor copiado del JSON del FEIC; un DPI escaneado nítido; un
recibo con sombra; un número con un dígito tapado; un anexo ausente.

**Debe pasar:** Alto, Medio, Bajo, Ilegible y Faltante, en ese orden; si se da
puntaje, cada uno cae en su rango.

## Cómo evaluar

Por cada caso, marca: cumple, cumple en parte, no cumple. Un solo "no cumple" en
C3, C9, C10, C12, C13, C14 o C15 impide publicar una nueva versión: son los que
más daño hacen si fallan.
