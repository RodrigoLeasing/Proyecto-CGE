# Cálculos

Los montos que se registran en el sistema van **sin IVA**. Antes de devolver un
monto que no cuadra, recalcula con estas fórmulas: hubo alarmas falsas por
cálculos manuales equivocados.

## 1. Guatemala (avance)

| Concepto | Fórmula |
|---|---|
| Valor sin IVA | Precio ÷ 1.12. Si el vehículo es usado de 2024 o anterior, o híbrido, el precio ya es el valor sin IVA |
| Renta inicial con IVA | Valor sin IVA × % × 1.12 |
| Gastos iniciales con IVA | Valor sin IVA × % + cargo de dispositivo y GPS × 1.12 |
| Pago inicial | Renta inicial + gastos iniciales + traspaso inicial en usados |
| Opción de compra | Valor sin IVA × % + traspaso |
| Cuota mensual con IVA | (Renta + seguro + GPS mensual) × 1.12 |
| Desembolso | Valor sin IVA − renta inicial sin IVA |
| Flujo | Todo sin IVA; renta inicial del flujo = renta inicial con IVA ÷ 1.12 |

Montos de política, **por confirmar su vigencia con CGE**:

| Concepto | Monto |
|---|---|
| Cargo de dispositivo y GPS sin IVA | 1,386.00 en quetzales (180 dólares en dólares) |
| Cargo de dispositivo y GPS con IVA | 1,552.32 quetzales o 201.60 dólares |
| GPS mensual | 139.00 |
| Traspaso inicial en usados y traspaso de la opción de compra | 1,835.00 (vehículos y motos; 238.50 dólares en dólares) |
| IVA | 12 % |

El cambio del GPS mensual requiere visto bueno de la junta directiva.

## 2. Variantes en Guatemala

- **Vehículo híbrido:** exento. El precio es el valor sin IVA; el blindaje y los
  accesorios sí llevan IVA.
- **Usado de 2024 o anterior:** el precio no lleva IVA; la renta inicial lleva
  IVA agregado. Un desembolso que "no cuadra" suele ser por no aplicar este IVA.
- **Bien compuesto** (vehículo más blindaje o accesorios): cada parte tiene su
  cotización vendor y su flujo; el blindaje no lleva opción de compra; el flujo
  consolidado suma ambos. Si la renta inicial viene como monto con una nota,
  verifica el porcentaje con la nota.
- **Green Fleet (vehículos 100 % eléctricos):** IVA sobre la renta de 0 % antes de
  2027, 2.4 % en 2027, 4.8 % en 2028, 7.2 % en 2029, 9.6 % en 2030, 10.8 % en 2031
  y 12 % desde 2032. El cargo de CRM es mensual y el POS (1.25 %) aplica sobre
  renta, CRM, seguro y GPS solo si se cobra.
- **Cotizador web con cobros de POS:** el CRM no se cobra en la opción de compra;
  seguro y traspaso van sin IVA.
- **Crédito puente:** abono a capital más intereses más IVA; se suma en vertical y
  horizontal. De 1 a 3 centavos de diferencia se dejan pasar (los detecta FIMS);
  desde un quetzal se corrige.
- **Seguro:** el mejorado tiene su cuota en el correo de Seguros; puede venir
  depreciado por año. Si es igual todos los años y el plazo es de 36 meses,
  verifica que no cambie.
- **Cotizaciones de vendor:** a veces el IVA viene mal calculado (diferencias de
  unos pocos quetzales); se corrige la cotización, no el flujo.

## 3. Tolerancias

| Caso | Tolerancia |
|---|---|
| Redondeo de un monto | Un centavo, hasta 0.02 al comparar |
| Monto solicitado contra precio | Ninguna: un centavo de diferencia se corrige |
| Crédito puente | Hasta 3 centavos |
| Porcentajes de accionistas | Redondeo evidente es OBSERVAR |

## 4. Señales de dato mal leído

- Si el IVA implícito (total ÷ valor del bien − 1) no es 0 ni el del país,
  revisa los montos leídos o el perfil.
- Si todas las diferencias guardan la misma proporción (por ejemplo 1.13 ÷
  1.12), el país del perfil está mal.
- Un precio escrito con el símbolo de moneda y punto ("Q.") no es un decimal:
  toma el número desde el primer dígito.

## 5. Ejemplo ficticio

Valor sin IVA 100,000.00; renta inicial 10 %; gastos iniciales 1.7 %; opción de
compra 1 %; usado.

- Renta inicial con IVA: 100,000.00 × 0.10 × 1.12 = 11,200.00.
- Gastos iniciales con IVA: 1,700.00 + 1,552.32 = 3,252.32.
- Pago inicial: 11,200.00 + 3,252.32 + 1,835.00 = 16,287.32.
- Opción de compra: 1,000.00 + 1,835.00 = 2,835.00.

## 6. Otros países (informativo; no hay checklist activo)

| País | IVA | Particularidad |
|---|---|---|
| Honduras | 15 % | Bono vendor dentro de los gastos iniciales; GPS mensual y traspaso propios |
| El Salvador | 13 % | Se resta el impuesto a la primera matrícula y las placas antes de calcular; flujo aparte para ellos; gasto inicial mínimo |
| Panamá | 7 % | Se trabaja sobre el total con impuesto; la opción de compra se calcula sobre ese total |
| Costa Rica | 13 % solo sobre seguro, GPS y cargo | El bien se cotiza sin impuesto; gastos iniciales siempre financiados en flujo aparte |
| República Dominicana | 18 % | Gastos financiados en flujo aparte; el seguro no se financia; valor residual con impuesto |

Detalle y montos en `paises_y_equivalencias.md`.
