# Formatos de salida

Todos los entregables van en Markdown salvo que el usuario pida otro formato.
`scripts/render_hoja.py` genera F1, F2 y F3 desde el JSON del caso, para que el
formato sea siempre el mismo.

Reglas comunes:
- **Los resultados del caso llevan los datos del cliente** (nombres, números,
  valores leídos y esperados). Ver `privacidad_gobernanza.md`, nivel 2. La
  excepción es la ficha de entrenamiento (F4), que va sin datos.
- Cada término se muestra con **valor, nivel de confianza y fuente**
  (`regla_confianza.md`).
- La clasificación es **Pasa, No pasa o Revisión**. La persona de CGE puede
  cambiarla y el cambio se registra.
- Sin analogías ni etiquetas de certeza del asesor ("seguro", "probable").

## F1. Hoja de resultado del expediente

Secciones, en este orden:

1. **Encabezado:** nombre del caso, fecha de revisión, versión de la
   herramienta, hora de inicio y de fin.
2. **Perfil:** país, producto, tipo de cliente, condición, número de negocios,
   aval (sí, quién; o "No presentó aval, revisado en…").
3. **Alcance aplicado:** módulos comprometidos y de avance.
4. **Checklist aplicado:** nombre, versión y fecha; si falta, "vigencia por
   confirmar con CGE".
5. **Clasificación del expediente:** una de tres frases fijas (ver abajo).
6. **Resumen en números:** documentos y términos por clasificación, y hallazgos
   por severidad.
7. **Documentos:** por documento, su estado en el inventario, su clasificación y
   los términos que no pasan con su nivel de confianza.
8. **Términos por documento:** una fila por término con valor leído, confianza,
   fuente y clasificación.
9. **Escala de confianza:** la leyenda con los rangos.
10. **Hallazgos:** por severidad, con regla, documento, página, término, valor
    encontrado, valor esperado, documento que manda, confianza y clasificación.
11. **Estructura accionaria vigente:** accionistas con fuente, confianza y página.
12. **Revisión humana:** lo que debe decidir la persona de CGE.
13. **Gobernanza:** los tres puntos abiertos, en una línea.

Clasificación del expediente (frases fijas):

| Condición | Frase |
|---|---|
| Algún documento no pasa | "NO PASA. Hay documentos con términos que no pasan." |
| Ningún documento no pasa y alguno en Revisión | "REVISIÓN. Ningún término no pasa, pero hay términos que la persona de CGE debe revisar." |
| Todos los documentos pasan | "PASA. Todos los términos verificados pasan." |

Siempre se agrega: "La persona de CGE puede cambiar esta clasificación; cada
cambio queda registrado con su motivo." y "Un término que no pasa hace que el
documento entero no pase."

## F2. Lista de correcciones para el ticket

- Solo entran los términos que **no pasan** (BLOQUEA o CORREGIR con lectura Alto o
  Medio, o Faltante). Los términos en **Revisión** no se devuelven a Comercial:
  los resuelve la persona de CGE.
- Una línea por error: `DOCUMENTO: apartado: dice X; debe decir Y (según Z)`.
- Agrupada por documento, en lenguaje simple, sin juicios sobre el asesor. La
  línea lleva los datos reales del cliente porque Comercial debe saber qué corregir.
- **Un solo bloque.** No se parte por el total de caracteres. Cada línea tiene un
  máximo (por defecto 250 caracteres; ajustable); si lo supera, se recorta con
  "…" y el detalle completo queda en la hoja de resultado.
- Las decisiones `falsa_alarma` y `bajado_a_observar` no entran.
- Lo faltante se menciona **una sola vez**.
- En la segunda revisión se entregan **tres listas**: corregido, pendiente y
  nuevo.
- El nivel de confianza no va en esta lista: se queda en la hoja de resultado.

Ejemplo (datos ficticios):

```
FEIC: número de escritura: dice 4; debe decir 5 (según la escritura, primera hoja).
FORMULARIO CONOCE A TU CLIENTE: gastos iniciales: dice 30 %; debe decir 1.7 % (según la hoja de negociación).
CARTA DE BURÓ: no indica lugar; debe indicar lugar y fecha.
```

## F3. Trazabilidad del caso

`trazabilidad.json`, por expediente. Lleva los datos del cliente y vive con el
caso:

| Campo | Contenido |
|---|---|
| `perfil` | País, producto, tipo de cliente, condición, número de negocios y aval |
| `checklist` | Nombre, versión y fecha |
| `alcance` | Módulos comprometidos y de avance |
| `inventario` | Un registro por documento |
| `terminos` | Cada término con valor, página, confianza, fuente y clasificación |
| `clasificacion_documentos` | Clasificación de cada documento |
| `clasificacion_expediente` | Pasa, No pasa o Revisión |
| `hallazgos` | Cada uno con su regla de origen y su confianza |
| `estructura_accionaria` | Resumen y fuente |
| `aval` | Sí o no, y dónde se buscó |
| `avisos` | Por ejemplo, "resolución del Comité procesada" |
| `tiempos` | Inicio, fin y duración; tiempo por módulo si se midió |
| `decisiones_cge` | Qué cambió la persona de CGE respecto de lo clasificado |
| `criterios_activos` | Criterios flexibles aprobados y por quién |
| `version_herramienta` | Versión del orquestador |

`decisiones_cge` y la confianza de cada término son la base para medir la
precisión y calibrar la escala.

## F4. Ficha de entrenamiento

Para cada revisión grabada. **Va sin datos de clientes**, porque alimenta los
aprendizajes:

| Campo | Contenido |
|---|---|
| Identificación | Revisión, país, tipo, producto, nuevo o cartera, aval, número de negocios |
| Tiempo | Total y por bloque |
| Orden real | Secuencia en que el analista revisó |
| Fuentes por dato | De qué documento sacó cada dato |
| Estrategias | Qué hizo para no perderse o ir más rápido |
| Correcciones | Las encontradas, con documento y apartado, sin valores |
| Dificultades de lectura | Qué documentos o términos fueron difíciles de leer y por qué |
| Criterios nuevos | Reglas o excepciones no documentadas |
| Dudas | Lo que no supo resolver |
| Relación con el digitador | Coincidencias y diferencias |

Una revisión de entrenamiento sin las correcciones reales de su ticket no sirve
para medir la detección: pídelas.
