# Criterio humano: lo que decide la persona de CGE

La herramienta **no decide estos temas**: los clasifica como **Revisión** y deja
la evidencia para que la persona decida. Márcalos como revisión humana
(`requiere_criterio_humano: true`, nivel OBSERVAR) y no los conviertas en
corrección ni en visto bueno.

| Tema | Por qué no se automatiza | Qué entrega la herramienta |
|---|---|---|
| Parecido de la firma con el DPI | Es una comparación visual con tolerancia (los analistas pasan firmas con un parecido de entre 50 % y 90 %) | Recorte de la firma y del DPI uno junto al otro |
| Identidad del asesor en la selfie | Reconocer a una persona en una foto no es verificable con certeza; las analistas con experiencia conocen a los asesores | Nombre del asesor del documento, foto y nombre del visitante |
| Certificación del vendor | Un grupo comercial tiene varias razones sociales; la cotización puede traer solo un logotipo o un sello | Los nombres de cada documento y el sello, si lo hay |
| Tachones o correcciones en una escritura registrada | Legal y Riesgos deciden si piden respaldo | Página y recorte |
| Empresa que no aparece en el buró | Puede no existir en el registro o el analista puede buscarla de otra forma | El informe y el número consultado |
| Identificación del bien en cotizaciones en otro idioma o varias cotizaciones | Requiere entender el producto | Las cotizaciones y la descripción del negocio |
| Motivo de un visto bueno o memo | Es una decisión de otra área | El documento |
| Excepciones de Legal (registro mercantil emitido por abogado, cédulas vencidas por comunicado) | Son precedentes que se registran, no reglas | El documento y el precedente, si existe |
| Estructura reconstruida de varias fuentes | Una fuente mezclada puede ocultar un cambio | La línea de tiempo con páginas |
| Si falta una modificación que el expediente no menciona | No se puede saber qué no se ve | La alerta de antigüedad |
| Dato mal leído probable (nombres en otro orden) | Podría ser un error real | Ambos valores y la página |

## Cómo registrar la decisión

Cada hallazgo se cierra con una decisión de la persona:

| Decisión | Efecto |
|---|---|
| `confirmado` | Pasa a la lista de correcciones |
| `falsa_alarma` | Sale de la lista y se cuenta para medir falsas alarmas |
| `bajado_a_observar` | Se muestra pero no se devuelve |
| `subido` | Cambia a CORREGIR o BLOQUEA |

Esa decisión es el dato más valioso para medir la detección y calibrar la
escala de confianza: guárdala siempre.

La persona de CGE también puede cambiar cualquier otra clasificación de la
herramienta (Pasa, No pasa o Revisión); el cambio se registra igual.

## Criterios flexibles de los analistas

Son prácticas que los analistas aplican y que no están en el checklist oficial.
Se registran **aparte** del checklist, desactivados, con campo "Aprobado por".
Solo se activan con aprobación de la jefatura de CGE. Una excepción aprobada
para un caso no se convierte en regla.
