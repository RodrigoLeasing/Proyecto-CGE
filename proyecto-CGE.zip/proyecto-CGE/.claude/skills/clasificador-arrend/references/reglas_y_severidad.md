# Reglas y severidad (Guatemala, persona jurídica)

Cada regla es atómica: una condición, un nivel, un documento. El id no cambia.

**Fuente:**
- **CL** = checklist oficial.
- **PA** = práctica observada en analistas.
- **PR** = precedente de Legal o Riesgos.
- **PP** = propuesta del proyecto; **por confirmar con CGE** antes de tratarla
  como regla firme.

**Alcance:** las reglas del módulo 3 son comprometidas. Las demás son avance.

**Relación con la clasificación** (`regla_confianza.md`): BLOQUEA y CORREGIR son
**No pasa**; OBSERVAR es **Revisión**. Si el hallazgo se apoya en una lectura
Bajo o Ilegible, pasa a **Revisión**. Un término que no pasa hace que el
documento entero no pase.

**Formato de un hallazgo para Comercial:** `DOCUMENTO: apartado: dice X; debe
decir Y (según Z)`. Una línea. Sin juicios sobre el asesor.

## Inventario (SH-INV)

| Id | Condición | Nivel | Fuente |
|---|---|---|---|
| GT-INV-01 | Falta un documento obligatorio del checklist | BLOQUEA | CL |
| GT-INV-02 | Documento ilegible, borroso, torcido o con páginas faltantes (todos sus términos obligatorios Ilegibles, o páginas Faltantes) | CORREGIR (pide una copia legible) | PA |
| GT-INV-03 | Documento que pertenece a otra entidad o persona | CORREGIR | PP |
| GT-INV-04 | Documento duplicado o dos versiones del mismo formulario | OBSERVAR (usa la firmada o la más reciente y lista las diferencias) | PA |

## Representación y estructura accionaria (SH-ESC, comprometido)

| Id | Condición | Nivel | Fuente |
|---|---|---|---|
| GT-ESC-01 | Escritura incompleta: falta una hoja o cláusula | CORREGIR | PA |
| GT-ESC-02 | Escritura ilegible | CORREGIR | PA |
| GT-ESC-03 | Una modificación mencionada no está en el expediente | CORREGIR | PA |
| GT-ESC-04 | Los porcentajes no suman 100 % y no es redondeo | CORREGIR | PA |
| GT-ESC-05 | Diferencia de redondeo evidente en los porcentajes | OBSERVAR | PA |
| GT-ESC-06 | Cesión de acciones de quien no aparece antes como accionista | CORREGIR | PA |
| GT-ESC-07 | Accionista que es sociedad y no hay anexo 5, o el último eslabón es una sociedad | CORREGIR | PR |
| GT-ESC-08 | Accionistas del FEIC (10 % o más) distintos a la estructura vigente | CORREGIR | CL |
| GT-ESC-09 | Último cambio de estructura de hace más de 5 años | OBSERVAR (confirmar que no hay modificaciones posteriores) | PP |
| GT-ESC-10 | Número, fecha, notario o fecha de inscripción de la escritura distintos en FEIC o solicitud | CORREGIR | PA |
| GT-ESC-11 | Tachones o correcciones a mano en una escritura firmada y registrada | OBSERVAR (criterio humano) | PA |
| GT-ESC-12 | Representante del FEIC o del Conoce a tu cliente distinto al del nombramiento | CORREGIR | PA |
| GT-ESC-13 | Cargo distinto al del nombramiento | CORREGIR | PA |
| GT-ESC-14 | Vencimiento de la representación distinto de fecha inicial más plazo | CORREGIR | PA |
| GT-ESC-15 | Registro, folio o libro del nombramiento distintos | CORREGIR | PA |
| GT-ESC-16 | Nombramiento vencido | BLOQUEA | PP |
| GT-ESC-17 | La escritura no corresponde a la razón social de la patente | BLOQUEA | PP |

## Identidad (SH-CRU)

| Id | Condición | Nivel | Fuente |
|---|---|---|---|
| GT-ID-01 | DPI vencido a la fecha de ingreso, aunque sea por un día | BLOQUEA | CL |
| GT-ID-02 | DPI al que le falta un lado o con datos ilegibles | CORREGIR | PA |
| GT-ID-03 | Nombre del representante distinto entre documentos | CORREGIR (aplica la regla del dato ancla) | PA |
| GT-ID-04 | Mismas palabras del nombre en otro orden | OBSERVAR (posible lectura invertida) | PP |
| GT-ID-05 | NIT del representante distinto al RTU | CORREGIR | PA |
| GT-ID-06 | Edad distinta por más de un año | CORREGIR | PA |
| GT-ID-07 | Edad distinta por un año, con cumpleaños reciente | OBSERVAR | PA |
| GT-ID-08 | Casilla de persona expuesta políticamente o cliente con perfil especial vacía | CORREGIR | CL |
| GT-ID-09 | PEP o CPE marcados como sí | DETENER el caso (compuerta) | Proyecto |

## Perfil del cliente (SH-CRU)

| Id | Condición | Nivel | Fuente |
|---|---|---|---|
| GT-PER-01 | Razón social distinta a la patente de sociedad (incluida la puntuación) | CORREGIR | CL |
| GT-PER-02 | Dirección distinta a la del recibo | CORREGIR | CL |
| GT-PER-03 | Recibo con más de 2 meses de emisión | CORREGIR | CL |
| GT-PER-04 | NIT de la empresa distinto al RTU | CORREGIR | CL |
| GT-PER-05 | Registro, folio o libro de la sociedad distintos | CORREGIR | PA |
| GT-PER-06 | Teléfono sin 8 dígitos o correo mal escrito | CORREGIR | PA |
| GT-PER-07 | Actividad sin relación con la del RTU | OBSERVAR (criterio humano) | PA |
| GT-PER-08 | Asesor distinto entre documentos | CORREGIR | PA |
| GT-PER-09 | Vendor distinto entre documentos | OBSERVAR (certifica la persona de CGE) | PA |
| GT-PER-10 | Selfie de una persona distinta al asesor, sin nota | OBSERVAR (criterio humano) | PA |
| GT-PER-11 | Menos de las fotos mínimas más la selfie | CORREGIR (mínimo por confirmar: 3 o 5) | PA |
| GT-PER-12 | Conoce a tu cliente sin firma del supervisor | BLOQUEA (por confirmar si basta la del asesor) | CL |
| GT-PER-13 | Condiciones del Conoce a tu cliente distintas a la hoja | CORREGIR | PA |
| GT-PER-14 | Uso comercial o particular que no corresponde al bien | CORREGIR | PA |

## Burós (SH-BUR)

| Id | Condición | Nivel | Fuente |
|---|---|---|---|
| GT-BUR-01 | Falta la carta de buró | BLOQUEA | CL |
| GT-BUR-02 | Falta el informe de la sociedad, del representante o de un socio con 10 % o más | BLOQUEA | CL |
| GT-BUR-03 | Carta sin lugar o sin fecha, o sin firma | CORREGIR | PA |
| GT-BUR-04 | Mora de más de 60 días sin respaldo | BLOQUEA (texto fijo, ver abajo) | PR |
| GT-BUR-05 | Demanda ejecutiva o sumaria como demandado, sin respaldo | BLOQUEA (texto fijo) | PR |
| GT-BUR-06 | Informe que no es del mes en curso ni del anterior | CORREGIR | PA |
| GT-BUR-07 | Informe incompleto ("página 6 de 7") | CORREGIR | PA |
| GT-BUR-08 | La empresa no aparece en el informe | OBSERVAR (criterio humano) | PA |
| GT-BUR-09 | Buró de otra razón social o de otro NIT | OBSERVAR (no se usa para calificar; se reporta) | PA |

Texto fijo de BLOQUEA por mora o demanda: "requiere desistimiento, finiquito o
constancia de pago, o visto bueno de la Gerencia de Riesgos".

No son hallazgo: demanda donde el cliente es el demandante; mora de menos de 60
días; informes de socios con menos de 10 %; informes en otro orden.

## Información financiera y estados de cuenta (SH-FIN)

| Id | Condición | Nivel | Fuente |
|---|---|---|---|
| GT-FIN-01 | Falta un periodo (dos años cerrados al 31 de diciembre o el parcial con integraciones) | BLOQUEA | CL |
| GT-FIN-02 | Fechas del parcial distintas entre los estados | CORREGIR | PA |
| GT-FIN-03 | Falta firma del representante o firma y sello del contador | CORREGIR | CL |
| GT-FIN-04 | Nombre de la empresa distinto en alguna página | CORREGIR | PA |
| GT-FIN-05 | Contador distinto al del RTU | CORREGIR | PA |
| GT-FIN-06 | Declaración que no corresponde a los periodos o al plazo (un mes y 15 días) | CORREGIR | PA |
| GT-CTA-01 | Menos de tres meses cerrados anteriores al ingreso | CORREGIR | CL |
| GT-CTA-02 | El número de cuenta cambia dentro de una serie | OBSERVAR | PA |

## Negocio (SH-NEG y SH-CAL)

| Id | Condición | Nivel | Fuente |
|---|---|---|---|
| GT-NEG-01 | Código de producto del FEIC distinto al producto o a la moneda | CORREGIR | PA |
| GT-NEG-02 | Monto solicitado distinto al precio, aunque sea por un centavo | CORREGIR | PA |
| GT-NEG-03 | TIR de la hoja distinta a la del flujo | CORREGIR (se corrige la hoja) | PA |
| GT-NEG-04 | Vehículo sin GPS y sin visto bueno del jefe de activos | CORREGIR | PA |
| GT-NEG-05 | Descripción del bien incompleta o genérica | CORREGIR | PA |
| GT-NEG-06 | Seguro mejorado sin el correo de Seguros | CORREGIR | PA |
| GT-NEG-07 | Bien con accesorios o blindaje que no se describe completo en todos los documentos | CORREGIR | PA |
| GT-NEG-08 | Renta distinta en algún mes | CORREGIR | PA |
| GT-NEG-09 | Notas de la hoja cortadas, ilegibles o que no explican un cálculo | CORREGIR | PA |
| GT-NEG-10 | Usado: precio del avalúo distinto al de la cotización, sin visto bueno | CORREGIR | PA |
| GT-CAL-01 | Un monto no cuadra con la fórmula, fuera de tolerancia | CORREGIR | PA |
| GT-CAL-02 | Crédito puente: diferencia de un quetzal o más | CORREGIR | PA |
| GT-CAL-03 | Diferencia de hasta 1 a 3 centavos en crédito puente, o de un centavo por redondeo | Sin hallazgo | PA |

## Reingreso (SH-REI)

| Id | Condición | Nivel | Fuente |
|---|---|---|---|
| GT-REI-01 | Un dato cambió respecto de la versión anterior y no se pidió | OBSERVAR (el asesor confirma si es nuevo o un error) | PA |
| GT-REI-02 | Una corrección pedida no se hizo | CORREGIR (pendiente) | PA |
| GT-REI-03 | Apareció un error nuevo | CORREGIR (nuevo) | PA |

## Conflictos entre checklist y práctica

1. Firma en el Conoce a tu cliente: el checklist pide asesor y supervisor; hay
   revisores que aceptan una.
2. Fotos mínimas: tres o cinco.
3. Cliente de cartera: un año para la definición y más de dos para eximir
   declaraciones.
4. Aval sin Conoce a tu cliente: sin criterio confirmado.

Cuando haya conflicto, aplica el checklist oficial y registra la práctica como
criterio flexible desactivado hasta que lo apruebe la jefatura de CGE.
