#!/usr/bin/env python3
"""Valida la estructura del orquestador y busca datos que no deben guardarse.

Revisa: encabezado del SKILL.md, que todas las referencias citadas existan,
tamaño del SKILL.md, y patrones de datos sensibles. NUNCA imprime el dato
encontrado: solo archivo y línea (regla de privacidad del proyecto).

Uso: python validar_skill.py [carpeta_de_la_habilidad]
"""
import re
import sys
from pathlib import Path

RAIZ = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent.parent
PATRONES = {
    "número largo (posible documento de identidad o NIT)": re.compile(r"(?<![\d.,])\d{9,13}(?![\d.,])"),
    "correo electrónico": re.compile(r"[\w.+-]+@[\w-]+\.[\w.]+"),
    "ruta de usuario": re.compile(r"(/Users/|/home/(?!claude)|C:\\Users\\)"),
    "número de expediente": re.compile(r"(?i)expediente\s*(n[o°.º]|n[úu]mero)\s*[:#]?\s*\d+"),
    "etiqueta de certeza del asesor en documento": re.compile(r"\[(Seguro|Probable|Suposición)\]"),
}
OBSOLETOS = {
    "frase obsoleta (la herramienta clasifica, no solo señala)": re.compile(r"(?i)nunca aprueba|no rechaza y no certifica|solo se[ñn]ala"),
    "nivel de confianza obsoleto (ahora es Faltante)": re.compile(r"No encontrado"),
    "regla obsoleta (las resoluciones del Comité sí se procesan)": re.compile(r"(?i)no lo abras|no proceses resoluciones"),
}
EXTENSIONES = {".md", ".json", ".py"}


def main():
    errores, avisos = [], []
    skill = RAIZ / "SKILL.md"
    if not skill.exists():
        print("FALTA SKILL.md"); return 1
    texto = skill.read_text(encoding="utf-8")
    m = re.match(r"^---\nname: ([\w-]+)\ndescription: (.+?)\n---\n", texto, re.S)
    if not m:
        errores.append("SKILL.md: encabezado inválido (se espera name y description)")
    else:
        if m.group(1) != "clasificador-arrend":
            errores.append("SKILL.md: el nombre no es clasificador-arrend")
        if len(m.group(2)) > 1024:
            avisos.append("SKILL.md: la descripción supera 1024 caracteres")
    lineas = texto.count("\n")
    if lineas > 500:
        avisos.append(f"SKILL.md: {lineas} líneas (ideal: menos de 500)")

    citados = set(re.findall(r"`((?:references|assets|scripts)/[\w./-]+)`", texto))
    citados |= {f"references/{n}" for n in re.findall(r"`([\w]+\.md)`", texto)
                if (RAIZ / "references" / n).exists()}
    for c in sorted(citados):
        if not (RAIZ / c).exists():
            errores.append(f"SKILL.md cita {c} y no existe")
    for archivo in sorted((RAIZ / "references").glob("*.md")):
        if archivo.name not in texto:
            avisos.append(f"{archivo.name} no está citada en SKILL.md")

    for archivo in sorted(RAIZ.rglob("*")):
        if archivo.suffix not in EXTENSIONES or "__pycache__" in archivo.parts:
            continue
        if archivo.name == "validar_skill.py":
            continue
        for n, linea in enumerate(archivo.read_text(encoding="utf-8").splitlines(), 1):
            for nombre, pat in PATRONES.items():
                if pat.search(linea):
                    errores.append(f"{archivo.relative_to(RAIZ)}:{n}: posible {nombre}")
            if archivo.name != "validar_skill.py":
                for nombre, pat in OBSOLETOS.items():
                    if pat.search(linea):
                        errores.append(f"{archivo.relative_to(RAIZ)}:{n}: {nombre}")

    for a in avisos:
        print("AVISO:", a)
    for e in errores:
        print("ERROR:", e)
    if not errores:
        print("Validación correcta: estructura y privacidad sin errores.")
    return 1 if errores else 0


if __name__ == "__main__":
    sys.exit(main())
