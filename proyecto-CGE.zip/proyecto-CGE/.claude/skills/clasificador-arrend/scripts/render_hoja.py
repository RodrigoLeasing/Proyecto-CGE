#!/usr/bin/env python3
"""Clasifica un caso y genera la hoja de resultado (F1), la lista de correcciones
(F2) y la trazabilidad (F3) a partir de un JSON de caso.

Uso:
    python render_hoja.py caso.json [carpeta_salida] [--limite 250]

Reglas (references/regla_confianza.md):
- Un término que no pasa hace que el documento entero no pase.
- Con confianza Bajo o Ilegible no se rechaza ni se aprueba: Revisión.
- Faltante en un término o documento obligatorio: No pasa.
- Expediente: algún documento No pasa -> No pasa; si no, alguno en Revisión ->
  Revisión; si no, Pasa.
La persona de CGE puede cambiar cualquier clasificación; el cambio se registra
en `decision_cge`.
"""
import json
import sys
from collections import OrderedDict
from pathlib import Path

NIVELES = ["BLOQUEA", "CORREGIR", "OBSERVAR"]
NOMBRE_NIVEL = {"BLOQUEA": "Crítico (BLOQUEA)", "CORREGIR": "Regular (CORREGIR)",
                "OBSERVAR": "Revisión (OBSERVAR)"}
ETIQUETAS = {"pais": "País", "producto": "Producto", "tipo_cliente": "Tipo de cliente",
             "condicion": "Condición", "negocios": "Número de negocios", "aval": "Aval"}
PASA, NO_PASA, REVISION = "Pasa", "No pasa", "Revisión"

# Rangos de la escala de confianza (regla_confianza.md). Ilegible: menos de 50.
RANGOS = OrderedDict([("Alto", (95, 100)), ("Medio", (85, 94)), ("Bajo", (50, 84)),
                      ("Ilegible", (0, 49)), ("Faltante", None)])
LEYENDA = [("Alto", "95 a 100", "Texto copiado y pegado, o texto e imagen que coinciden"),
           ("Medio", "85 a 94", "Imagen legible, o texto copiado con cierta dificultad"),
           ("Bajo", "50 a 84", "Imagen borrosa, o texto editado del que no se está seguro"),
           ("Ilegible", "menos de 50", "Parcialmente legible; no hay seguridad de que sea ese término"),
           ("Faltante", "—", "El término o el documento no está")]
ESTADOS = {
    NO_PASA: "NO PASA. Hay documentos con términos que no pasan.",
    REVISION: "REVISIÓN. Ningún término no pasa, pero hay términos que la persona de CGE debe revisar.",
    PASA: "PASA. Todos los términos verificados pasan.",
}
PIE_ESTADO = ("La persona de CGE puede cambiar esta clasificación; cada cambio queda registrado "
              "con su motivo. Un término que no pasa hace que el documento entero no pase.")
GOBERNANZA = ("El contenido de los expedientes viaja al proveedor de la inteligencia artificial, "
              "no hay política de retención de sesiones y falta la confirmación formal de "
              "Sistemas y Riesgos.")


def recortar(texto, limite):
    texto = " ".join(texto.split())
    if len(texto) <= limite:
        return texto
    corte = texto[: limite - 1]
    i = corte.rfind(" ")
    return (corte[:i] if i > limite * 0.6 else corte) + "…"


def validar_confianza(t):
    """Devuelve un texto de error si el nivel o el puntaje son inválidos."""
    c = t.get("confianza")
    if c not in RANGOS:
        return f"confianza inválida: {c!r}"
    p = t.get("puntaje")
    if p is not None and RANGOS[c] is not None and not (RANGOS[c][0] <= p <= RANGOS[c][1]):
        return f"puntaje {p} fuera del rango de {c}"
    if c in ("Bajo", "Ilegible") and not t.get("motivo"):
        return f"falta el motivo para {c}"
    return None


def vigentes(hallazgos):
    """Aplica las decisiones de la persona de CGE a los hallazgos."""
    out = []
    for h in hallazgos:
        d = h.get("decision_cge")
        if d == "falsa_alarma":
            continue
        h = dict(h)
        if d == "bajado_a_observar":
            h["severidad"] = "OBSERVAR"
        out.append(h)
    return out


def clasificar_hallazgo(h):
    """No pasa solo con una lectura confiable; con duda o criterio humano, Revisión."""
    if h.get("decision_cge") == "subido":
        return NO_PASA
    if h.get("severidad") == "OBSERVAR" or h.get("requiere_criterio_humano"):
        return REVISION
    if h.get("confianza") in ("Bajo", "Ilegible"):
        return REVISION
    return NO_PASA


def clasificar_termino(t, hallazgos):
    """Clasificación de un término según sus hallazgos y su confianza."""
    propios = [clasificar_hallazgo(h) for h in hallazgos
               if h.get("documento") == t.get("documento") and h.get("campo") == t.get("campo")]
    if NO_PASA in propios:
        return NO_PASA
    if REVISION in propios:
        return REVISION
    c = t.get("confianza")
    if c == "Faltante":
        return NO_PASA
    if c in ("Bajo", "Ilegible"):
        return REVISION
    return PASA


def peor(clases):
    clases = list(clases)
    if NO_PASA in clases:
        return NO_PASA
    if REVISION in clases:
        return REVISION
    return PASA


def clasificar_caso(caso):
    """Devuelve (terminos clasificados, documentos clasificados, expediente, hallazgos vigentes)."""
    hs = vigentes(caso.get("hallazgos", []))
    terminos = []
    for t in caso.get("terminos", []):
        t = dict(t)
        t["clasificacion"] = clasificar_termino(t, hs)
        terminos.append(t)
    documentos = OrderedDict()
    for i in caso.get("inventario", []):
        estado = i.get("estado")
        if estado in ("no aplica", "respaldo"):
            continue
        documentos.setdefault(i["documento"], [])
        if estado == "faltante":
            documentos[i["documento"]].append(NO_PASA)
    for t in terminos:
        documentos.setdefault(t["documento"], []).append(t["clasificacion"])
    for h in hs:
        if h.get("documento"):
            documentos.setdefault(h["documento"], []).append(clasificar_hallazgo(h))
    docs = OrderedDict((d, peor(c) if c else PASA) for d, c in documentos.items())
    exp = peor(docs.values()) if docs else PASA
    return terminos, docs, exp, hs


def lista_correcciones(hs, limite):
    """F2: solo lo que no pasa, una línea por error, agrupada por documento."""
    grupos = OrderedDict()
    for h in hs:
        if clasificar_hallazgo(h) != NO_PASA or not h.get("texto_comercial"):
            continue
        grupos.setdefault(h.get("documento", "Documento"), []).append(
            recortar(h["texto_comercial"], limite))
    lineas = []
    for doc in sorted(grupos):
        lineas.extend(grupos[doc])
    return lineas


def tres_listas(hs, limite):
    out = OrderedDict((k, []) for k in ("corregido", "pendiente", "nuevo"))
    for h in hs:
        e = h.get("estado_reingreso")
        if e in out and h.get("texto_comercial"):
            out[e].append(recortar(h["texto_comercial"], limite))
    return out


def tabla(filas, cabecera):
    if not filas:
        return "Sin elementos."
    out = ["| " + " | ".join(cabecera) + " |", "|" + "---|" * len(cabecera)]
    for f in filas:
        out.append("| " + " | ".join(str(x) if x not in (None, "") else "—" for x in f) + " |")
    return "\n".join(out)


def etiqueta_confianza(t):
    c = t.get("confianza", "—")
    r = RANGOS.get(c)
    txt = c if not r else f"{c} ({r[0]} a {r[1]})" if c != "Ilegible" else f"{c} (menos de 50)"
    if t.get("motivo"):
        txt += f": {t['motivo']}"
    return txt


def hoja(caso, limite):
    terminos, docs, exp, hs = clasificar_caso(caso)
    c = caso.get("caso", {})
    p = caso.get("perfil", {})
    ck = caso.get("checklist", {})
    al = caso.get("alcance", {})
    ck_txt = ck.get("nombre", "Checklist no cargado: revisión manual")
    if ck.get("version") or ck.get("fecha"):
        ck_txt += f". Versión {ck.get('version') or 'sin dato'}, fecha {ck.get('fecha') or 'sin dato'}."
    else:
        ck_txt += ". Vigencia por confirmar con CGE."
    conteo_docs = {k: sum(1 for v in docs.values() if v == k) for k in (NO_PASA, REVISION, PASA)}
    conteo_term = {k: sum(1 for t in terminos if t["clasificacion"] == k) for k in (NO_PASA, REVISION, PASA)}
    conteo_sev = {n: sum(1 for h in hs if h.get("severidad") == n) for n in NIVELES}

    L = ["# Hoja de resultado del expediente\n",
         f"**Caso:** {c.get('nombre', '')}",
         f"**Fecha de revisión:** {c.get('fecha', '')}",
         f"**Hora de inicio y fin:** {c.get('inicio', '—')} a {c.get('fin', '—')}\n",
         "## Perfil\n",
         tabla([[ETIQUETAS.get(k, k.replace("_", " ").capitalize()), v] for k, v in p.items()],
               ["Campo", "Valor"]),
         "\n## Alcance aplicado\n",
         f"- Comprometido (módulos): {', '.join(al.get('comprometido', [])) or '—'}",
         f"- Avance, no comprometido (módulos): {', '.join(al.get('avance', [])) or '—'}",
         "\n## Checklist aplicado\n", ck_txt]
    if caso.get("avisos"):
        L += ["\n## Avisos\n"] + [f"- {a}" for a in caso["avisos"]]
    L += ["\n## Clasificación del expediente\n", f"**{ESTADOS[exp]}**\n", PIE_ESTADO,
          "\n## Resumen\n",
          tabla([["Documentos", conteo_docs[PASA], conteo_docs[REVISION], conteo_docs[NO_PASA]],
                 ["Términos", conteo_term[PASA], conteo_term[REVISION], conteo_term[NO_PASA]]],
                ["Concepto", "Pasa", "Revisión", "No pasa"]),
          "",
          tabla([[NOMBRE_NIVEL[n], conteo_sev[n]] for n in NIVELES], ["Hallazgos por severidad", "Cantidad"]),
          "\n## Documentos\n"]
    estados_inv = {i["documento"]: i.get("estado") for i in caso.get("inventario", [])}
    filas = []
    for d, clase in docs.items():
        malos = [f"{t['campo']} ({t.get('confianza')})" for t in terminos
                 if t["documento"] == d and t["clasificacion"] == NO_PASA]
        if estados_inv.get(d) == "faltante":
            malos = ["documento faltante"] + malos
        filas.append([d, estados_inv.get(d, "presente"), clase, "; ".join(malos) or "—"])
    for i in caso.get("inventario", []):
        if i.get("estado") in ("no aplica", "respaldo"):
            filas.append([i["documento"], i["estado"], "No se evalúa", "—"])
    L.append(tabla(filas, ["Documento", "Inventario", "Clasificación", "Términos que no pasan (confianza)"]))
    L.append("\n## Términos por documento\n")
    for d in docs:
        ts = [t for t in terminos if t["documento"] == d]
        if not ts:
            continue
        L.append(f"### {d}\n")
        L.append(tabla([[t["campo"], t.get("valor"), etiqueta_confianza(t),
                         t.get("fuente") or ("Sin evidencia en el expediente" if t.get("confianza") == "Faltante" else ""),
                         t["clasificacion"]] for t in ts],
                       ["Término", "Valor leído", "Confianza", "Fuente", "Clasificación"]))
        L.append("")
    L.append("## Escala de confianza\n")
    L.append(tabla([[a, b, c2] for a, b, c2 in LEYENDA], ["Nivel", "Rango", "Criterio"]))
    L.append("\nEl puntaje, cuando se da, es una calificación por criterios y no un acierto medido.")
    L.append("\n## Hallazgos\n")
    for n in NIVELES:
        grupo = [h for h in hs if h.get("severidad") == n]
        L.append(f"### {NOMBRE_NIVEL[n]}\n")
        L.append(tabla([[h.get("regla"), h.get("documento"), h.get("pagina"), h.get("campo"),
                         h.get("valor_encontrado"), h.get("valor_esperado"), h.get("documento_que_manda"),
                         h.get("confianza"), clasificar_hallazgo(h),
                         "Avance" if h.get("alcance") == "avance" else "Comprometido"] for h in grupo],
                       ["Regla", "Documento", "Página", "Término", "Encontrado", "Esperado",
                        "Manda", "Confianza", "Clasificación", "Alcance"]))
        L.append("")
    est = caso.get("estructura_accionaria")
    L.append("## Estructura accionaria vigente\n")
    if est:
        L.append(f"Fuente: {est.get('fuente', '—')}\n")
        L.append(tabla([[a.get("nombre"), a.get("porcentaje"), a.get("confianza"), a.get("fuente") or a.get("pagina")]
                        for a in est.get("accionistas", [])],
                       ["Accionista", "Porcentaje", "Confianza", "Fuente"]))
    else:
        L.append("No se verificó.")
    L.append("\n## Revisión humana\n")
    rh = [h for h in hs if h.get("requiere_criterio_humano") or clasificar_hallazgo(h) == REVISION]
    if rh:
        for h in rh:
            L.append(f"- {h.get('documento')}, página {h.get('pagina') or '—'}, {h.get('campo')}: "
                     f"{h.get('detalle_tecnico') or h.get('campo')}")
    else:
        L.append("Sin temas pendientes de revisión.")
    L += ["\n## Gobernanza\n", GOBERNANZA]
    return "\n".join(L) + "\n"


def trazabilidad(caso):
    terminos, docs, exp, hs = clasificar_caso(caso)
    return {
        "perfil": caso.get("perfil", {}),
        "checklist": caso.get("checklist", {}),
        "alcance": caso.get("alcance", {}),
        "inventario": caso.get("inventario", []),
        "terminos": terminos,
        "clasificacion_documentos": docs,
        "clasificacion_expediente": exp,
        "hallazgos": [dict(h, clasificacion=clasificar_hallazgo(h)) for h in hs],
        "estructura_accionaria": caso.get("estructura_accionaria"),
        "avisos": caso.get("avisos", []),
        "tiempos": {k: caso.get("caso", {}).get(k) for k in ("inicio", "fin")},
        "decisiones_cge": [{"id": h.get("id"), "regla": h.get("regla"), "decision": h.get("decision_cge")}
                           for h in caso.get("hallazgos", []) if h.get("decision_cge")],
        "criterios_activos": caso.get("criterios_activos", []),
        "version_herramienta": caso.get("version", "0.2"),
    }


def main(argv):
    limite = 250
    args = []
    i = 1
    while i < len(argv):
        if argv[i] == "--limite":
            limite = int(argv[i + 1]); i += 2
        else:
            args.append(argv[i]); i += 1
    if not args:
        print(__doc__); return 2
    caso = json.loads(Path(args[0]).read_text(encoding="utf-8"))
    errores = [f"{t.get('documento')} / {t.get('campo')}: {e}"
               for t in caso.get("terminos", []) if (e := validar_confianza(t))]
    if errores:
        print("Corrige la confianza de estos términos antes de generar la hoja:")
        for e in errores:
            print(" -", e)
        return 1
    salida = Path(args[1] if len(args) > 1 else ".")
    salida.mkdir(parents=True, exist_ok=True)
    _, _, exp, hs = clasificar_caso(caso)
    (salida / "hoja_resultado.md").write_text(hoja(caso, limite), encoding="utf-8")
    partes = ["# Correcciones para el ticket\n"]
    tl = tres_listas(hs, limite)
    if any(tl.values()):
        for k, v in tl.items():
            partes.append(f"## {k.capitalize()}\n")
            partes.extend(v or ["Sin elementos."])
            partes.append("")
    else:
        partes.extend(lista_correcciones(hs, limite) or ["No hay correcciones para Comercial con las decisiones actuales."])
    (salida / "correcciones.md").write_text("\n".join(partes) + "\n", encoding="utf-8")
    (salida / "trazabilidad.json").write_text(
        json.dumps(trazabilidad(caso), ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Clasificación del expediente: {exp}")
    print(f"Generado en {salida}: hoja_resultado.md, correcciones.md, trazabilidad.json")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
