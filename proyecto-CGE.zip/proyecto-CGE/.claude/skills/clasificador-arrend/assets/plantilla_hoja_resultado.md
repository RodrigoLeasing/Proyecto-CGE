# Hoja de resultado del expediente

**Caso:** {{nombre_caso}}
**Fecha de revisión:** {{fecha}}
**Versión de la herramienta:** {{version}}

## Perfil

{{perfil}}

## Alcance aplicado

{{alcance}}

## Checklist aplicado

{{checklist}}

## Clasificación del expediente

{{clasificacion}}

## Resumen

{{resumen}}

## Documentos

{{documentos}}

## Términos por documento

{{terminos}}

## Escala de confianza

{{escala}}

## Hallazgos

{{hallazgos}}

## Estructura accionaria vigente

{{estructura}}

## Revisión humana

{{revision_humana}}

## Gobernanza

El contenido de los expedientes viaja al proveedor de la inteligencia artificial, no hay política de retención de sesiones y falta la confirmación formal de Sistemas y Riesgos.
