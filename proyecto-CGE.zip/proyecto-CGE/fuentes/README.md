# Fuentes

Material de referencia que sirvió para construir las reglas. **Sin datos de
clientes.**

- `checklists/`: extracción a texto de los Excel de checklists por país y del
  Excel de orden de documentación para ingreso a Escáner Ventas. Los originales
  siguen en SharePoint; si cambian, se vuelve a extraer y se registra la fecha.
- Las versiones y la vigencia de estos checklists **no están confirmadas con
  CGE**. El checklist de Costa Rica trae notas de edición sin aplicar.

Lo que **no** va al repositorio (está en `.gitignore`): grabaciones de las
revisiones, sus transcripciones, capturas de pantalla y expedientes. Esas fuentes
traen nombres y datos de clientes; permanecen en SharePoint. Lo aprendido de
ellas está resumido, sin datos, en `docs/`.
