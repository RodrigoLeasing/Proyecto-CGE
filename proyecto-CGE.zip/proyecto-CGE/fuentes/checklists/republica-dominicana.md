# Republica dominicana

Extracción a texto del archivo de Excel original (el original sigue en SharePoint). No incluye datos de clientes.


## Check List ALD
- CLIENTE:
- EXPEDIENTE MADRE
- No se solicitara Formulario de Beneficiarios Finales para clientes ALD, empresas que coticen en bolsa debidamente documentado y empresas de Directores.
- Fotocopia de recibo de agua, teléfono, internet o luz actualizado, este documento se omite para clientes ALD, Multinacionales e ingenios de toda la Región, toda vez que compartan la búsqueda en Google Earth, reporte de visita  e información de la solicitud del crédito.
- RNC actualizado (no mayor a 30 días) de la persona y empresa, según aplique.
- No se solicitaran estados de cuenta monetarios y de ahorro para clientes ALD, Multinacionales e Ingenios para toda la Región de Centroamérica.
- Formulario Conoce a Tu Cliente (este formulario incluye Check list ambiental y protocolo), debe incluir fotografías recientes, ubicación,  firmado  por el asesor y jefe superior. Para una persona jurídica las fotografías deben de reflejar el ingreso a la empresa y cuando aplique áreas administrativas, si cuenta con bodegas, área de producción, parqueo de vehículos,(validar que la ubicación coincida con la dirección reportada en la solicitud) Cuando el formulario no se encuentre en formato vigente se debe realizar la actualización. Debe tener como evidencia la Selfi del Asesor en las oficinas del cliente, queda PROHIBIDO solicitar fotos al cliente vía WhatsApp, vía correo electrónico, bajarlas de internet, o bien copiar las que se encuentren en años anteriores en el expediente del cliente. Debe ser realizado por el Asesor Responsable del Negocio.
- Fotocopia de Cedula legible de la persona o del Representante Legal según corresponda y, si es extranjero fotocopia de pasaporte (solo primera hoja).
- Se omite carta de consentimiento para investigación de buro financiero, si la solicitud de crédito incluye texto para consultas en buro de crédito.
- Finiquitos o Constancias de Pago, en caso de morosidad o demanda o desistimiento según sea el caso.
- NOTA: Confrontar firmas de solicitud de crédito, con firma en cedula, y firma en contrato.
- PERSONA JURIDICA
- Acta de Asamblea General Ordinaria que designa al representante y estatutos sociales
- Copia del Registro Mercantil Todas sus paginas (este se renueva cada dos años)
- No se solicitaran declaraciones de impuestos para clientes ALD, Multinacionales e Ingenios para toda le Región de Centroamérica y República Dominicana.
- Estados Financieros de los últimos dos periodos cerrados y parciales, para clientes ALD, Multinacionales e Ingenios para toda le Región de Centroamérica se omite esta información toda vez que el cliente confirme que cotiza en bolsa  y/o la información financiera sea pública, y para los clientes que no tengan información pública se deberá evaluar en conjunto con el área de Riesgos.
- Para Junta Directiva presentar Flujo de Fondos Proyectado en el caso de proyectos y/o situación financiera débil de la empresa, se omite esta información toda vez que el cliente confirme que cotiza en bolsa  y/o la información financiera sea pública, y para los clientes que no tengan información pública se deberá evaluar en conjunto con el área de Riesgos.
- EXPEDIENTE DE NEGOCIACION
- Hoja de negociación debidamente llena.
- Solicitud de Crédito firmada.
- Checklist de Seguros completo firmado.
- Mejora de seguro si aplica.
- Cotización Arrend firmada.
- Flujo de rendimientos del Negocio.
- Cotización Vendor con el detalle del bien.
- Otros:
- NOMBRE DE ASESOR RESPONSABLE:
- NOMBRE DE QUIEN ENTREGA EXPEDIENTE:
- INFORMACION PARA CGE
- RECIBIDO POR: | FIRMA:
- FECHA: | HORA:
- NOTA: Solo se recibirán los expedientes que vengan con la papelería completa.
