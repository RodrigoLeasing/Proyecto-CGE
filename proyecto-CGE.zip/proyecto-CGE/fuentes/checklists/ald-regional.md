# Ald regional

Extracción a texto del archivo de Excel original (el original sigue en SharePoint). No incluye datos de clientes.


## RI-GT-FO-01A
- CLIENTE:
- EXPEDIENTE MADRE
- Formulario FEIC, este formulario se excluye si cliente cotiza en bolsa
- No se solicitara Formulario de Beneficiarios Finales para clientes ALD, empresas que coticen en bolsa debidamente documentado y empresas de Directores.
- Fotocopia de recibo de agua o luz actualizado (No más de 2 meses de antigüedad. Este debe coincidir con la dirección del FEIC). Este documento se omite para clientes ALD, Multinacionales e ingenios de toda la Región, toda vez que compartan la búsqueda en Google Earth, reporte de visita  e información de la solicitud del crédito.
- RTU actualizado del año en curso de la persona y empresa, según aplique.
- No se solicitaran estados de cuenta monetarios y de ahorro para clientes ALD, Multinacionales e Ingenios para toda la Región de Centroamérica.
- Formulario Conoce a Tu Cliente (este formulario incluye Check list ambiental y protocolo), debe incluir fotografías recientes, ubicación,  firmado  por el asesor y subgerente o gerente comercial.
- Fotocopia de DPI legible de la persona o del Representante Legal según corresponda (Cuando el DPI este vencido presentar constancia emitida por RENAP de proceso de renovación) y, si es extranjero fotocopia de pasaporte (solo primera hoja).
- Se omite carta de consentimiento para investigación de buro financiero, si la solicitud de crédito incluye texto para consultas en buro de crédito.
- Finiquitos o Constancias de Pago, en caso de morosidad o demanda o desistimiento según sea el caso.
- NOTA: Confrontar firmas de solicitud de crédito, con firma en ID, y firma en contrato.
- PERSONA JURIDICA
- Nombramiento vigente del Representante Legal y facultades.
- Escritura de constitución y modificaciones si hubiere o puntos de acta del libro de accionistas.
- Patente de Comercio y de Sociedad.
- No se solicitaran declaraciones de impuestos para clientes ALD, Multinacionales e Ingenios para toda le Región de Centroamérica.
- Estados Financieros de los últimos dos periodos cerrados y parciales, para clientes ALD, Multinacionales e Ingenios para toda le Región de Centroamérica se omite esta información toda vez que el cliente confirme que cotiza en bolsa  y/o la información financiera sea pública, y para los clientes que no tengan información pública se deberá evaluar en conjunto con el área de Riesgos.
- Para Junta Directiva presentar Flujo de Fondos Proyectado en el caso de proyectos y/o situación financiera débil de la empresa, se omite esta información toda vez que el cliente confirme que cotiza en bolsa  y/o la información financiera sea pública, y para los clientes que no tengan información pública se deberá evaluar en conjunto con el área de Riesgos.
- NOTA: Confrontar firmas de solicitud de crédito, con firma en ID, y firma en contrato.
- EXPEDIENTE DE NEGOCIACION
- Hoja de negociación debidamente llena.
- Solicitud de Crédito firmada.
- Checklist de Seguros completo firmado.
- Mejora de seguro si aplica.
- Cotización Arrend firmada.
- Flujo de rendimientos del Negocio.
- Cotización Vendor con el detalle del bien.
- Otros:
- NOMBRE DE ASESOR RESPONSABLE:
- NOMBRE DE QUIEN ENTREGA EXPEDIENTE:
- INFORMACION PARA CGE
- RECIBIDO POR: | FIRMA:
- FECHA: | HORA:
- NOTA: Solo se recibirán los expedientes que vengan con la papelería completa.
