# Casos

Esta carpeta está **ignorada por git**: todo lo que hay aquí, excepto este archivo,
queda fuera del repositorio (ver `.gitignore`). Es solo para trabajo temporal con
expedientes y resultados de casos, que **llevan datos del cliente**.

En una sesión de Claude Code en la nube, esos archivos no deben salir de la sesión:
no los copies a otras carpetas del repositorio, no los agregues con `git add` y no los
pegues en documentos de `docs/` ni en las referencias de la habilidad.

Qué política de retención aplica a los archivos que entran a una sesión en la nube
no está confirmado con Sistemas. Hasta confirmarlo, prefiere casos ficticios o los
resúmenes sin datos de `docs/`.

Estructura sugerida por caso, sin datos del cliente en el nombre de la carpeta:

```
casos/
└── 2026-11-20_0930/
    ├── expediente/
    └── resultado/       hoja_resultado.md, correcciones.md, trazabilidad.json
```
